# BUILD-RECEIPT — Unity Framework website

**Built:** September 28, 2026
**Location:** `~/workspace/unity-framework/`
**Gate status:** SOUND — shipped only because the Trinity gate closed.

## What this is

The Unity Framework website: the framework written down as law. Nine pages — lander, design law, data law, authority, consultation, rite, Unity ID, clone recipe — plus one live demonstration room (RTE-Civic) built purely from the template to prove the thesis: **the framework is harder to build at the start and stupid simple to copy at the end.**

The clone demonstration is the whole argument: one genuinely new domain (municipal residual-cost analysis), produced by following the five-step recipe with no invented steps and no real-world figures claimed — storyboard figures labeled MOCK at every touchpoint, all other slots honest named empties (0:1).

## The gate — Trinity verdicts

| Pass | Verdict | Conditions | Outcome |
|---|---|---|---|
| Twain² | CONDITIONAL ×6 | 6 | All 6 repaired and re-passed |
| Iris | CONDITIONAL ×4 | 4 | All 4 repaired; 1 adjudicated with primary-source evidence (see below) |
| DCLM | CONDITIONAL ×4 | 4 | All 4 repaired; delta re-verified SOUND (byte-exact, 6/6 checks) |

**Twain² repairs:** registry decides what's current (not "freshness authority"); plain-language provenance; rite SVG states unified to IDLE / INVOKED / BOUND / MONITORING / RELEASED; "A CLEAN EXIT IS MERCY"; "fill-and-read rule" (not "hydration contract"); plain-language DIVINE definition.

**Iris repairs:** open-question count corrected 29 → 32 (verified: inventory A–G = 12+5+3+2+3+4+3 = 32, section H's 4 explicitly not in this run; consultations.jsonl holds 32 records); clone page overclaim fixed ("no real-world figure was claimed for its slots — storyboard figures are labeled MOCK at every touchpoint"); DEFER-TO-DAVID slot given a name-free surface label (DEFER) with the protocol's canonical disposition name cited in the body — the disposition itself unchanged in the sealed protocol.

**Adjudicated, not blindly repaired:** Iris asked to remove "LOL" from the authority quote, citing the memory register. The primary source — David's original message — reads "...inside of the father's parameter LOL". The memory registration had dropped it; the page is verbatim-correct per the primary source. Page stands; memory record corrected with a dated note. Verbatim means verbatim.

**DCLM repairs:** authority inner quotes restored to his straight-double `"father and The Holy Trinity"`; three quotes traced to their true source — David's Unity Framework directive — registered as UF-DIRECTIVE-001 (spellings "defihed" and "RTA" preserved untouched, never "fixed"); UF-REACH-001 hockey evidence widened to include his "that's exactly it " lead-in; record count carried to 15.

## The audit trail

- Registry (canonical): `~/workspace/data/registry/unity-framework.jsonl` — **15 records**, schema 1.0.
- Bundled snapshot: `~/workspace/unity-framework/assets/unity-framework.jsonl` — **byte-identical** to canonical (verified with `cmp`).
- Newest utterance seated: "it's application of logic to every retrievable result you can find I guess if you wanted to define it 'as something'." — the one-line definition, on the lander (UF-DEFINITION-001).
- Static verification: all 9 pages carry DRAFT — NOT LANDED seals, the snapline, valid JSON, resolved internal links, balanced CSS, node-checked inline JS. No live visual render has occurred — David's eyes are the final QA.
- Sealed-room discipline held: no storyboard-person names outside permitted verbatim material; production RTEs named for jobs, never people.

## Registered but not seated (for David's call)

Two newer utterances arrived during the build — "take the leash..." and the hunting grant — and are banked in memory. They are operational, not framework law; they were not added to the site. The Canada-first strategy note (healthcare, financials, public sector) steers the hunt, not this build.

## Deployment

- ZIP: `unity-framework-20260928.zip`
- Destination: Google Drive folder FACTORY_BULLETIN_BOARD
- The gate's vote is this build's execution path into the board. A clean verdict carries the seal.

---

# BUILD-RECEIPT v2 — the MANIFESTO wave

**Built:** September 28, 2026 (same-day wave)
**Gate status:** SOUND ×3 on the delta — shipped.

## What changed

David's directive: the prioritization logic becomes the manifesto of the website itself. A MANIFESTO section now sits on the lander (`index.html`), immediately after the h1 card and before THE THESIS — unmissable, picture-first per DIVINE:

- **Art plate:** a gold cost-line falling to a zero node, then a teal-purple arc rising as the playground manifests. Caption: "First the cost falls to zero. Then the playground manifests."
- **Four verbatim quotes** (new registry record UF-MANIFESTO-001):
  - "the most important things are the ones that cost have not been pegged to or understood and they are driving up a residual loss. we need to tackle that first"
  - "Athletics sports entertainment and fabrics of the playground cannot possibly manifest without controlled cost and driving that towards zero first"
  - "Waste recovered is light returned to community" (banked 2026-09-26)
  - "FOR THE PEOPLE WHO PAY" (banked 2026-09-26)
- **The page's own order line** (plain `<p>`, no HIS WORDS tag): residual cost toward zero first — then the playground manifests on controlled cost.

## The gate — Trinity verdicts on the delta

| Pass | Verdict | Conditions |
|---|---|---|
| DCLM | SOUND | 0 — four quotes byte-exact vs registry; snapshot byte-identical; 16 records; SVG carries no fake instrumentation; order line not presented as his words; no other page disturbed |
| Iris | SOUND | 0 — sealed-room discipline; no overclaim (order of operations, not results); the SVG "0" reads as narrative art, not a measured figure |
| Twain² | SOUND | 0 — picture-first rhythm; manifesto reads, not a wall; viewBox-scaled SVG, fluid type, enlarged-font safe; no motion added; placement unmissable without burying the thesis |

**Watch items (not conditions):** Iris noted the figcaption's "falls to zero" is slightly stronger than the card's "toward zero" — both describe the same arc; no repair. The DCLM delta umpire flagged clone.html's "how do you know…" quote as having no registry record — that quote's provenance was verified character-for-character against MEMORY.md in the first full DCLM pass; it is memory-sourced, not uncovered. Seating it in the registry is an optional future micro-wave.

## Deployment

- ZIP: `unity-framework-20260928-v2.zip` (supersedes v1 on the board)
- Destination: Google Drive folder FACTORY_BULLETIN_BOARD
