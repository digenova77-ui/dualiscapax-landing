
# SWARM WORK-CLAIM IDEMPOTENCY — ED-SPEC-20260929-SWARM-CLAIMS-V1
## David's mandate (Sept 28, 2026): "make sure they have a hashing algorithm system that ensures no bots forms are reworking the same work or destined to do the same thing"

## The system

Every swarm run claims its work BEFORE doing it, by hash. Same hash = same work = the second swarm stands down.

**Claim hash:** `SHA-256(pipe_id + "|" + scope + "|" + vintage_window + "|" + work_kind)`
- `pipe_id`: the registry pipe (e.g., `A1`, `B5`)
- `scope`: the bounded scope of this run (e.g., `ontario-municipal-water`, `board- Thames-Valley`)
- `vintage_window`: the data vintage or time window (e.g., `2026-Q3`, `2026-09-29-week`)
- `work_kind`: `data-fill` | `page-build` | `verdict` | `research` | `refinement`

**The registry:** `hidden_files/swarm-work-claims.jsonl` — one JSON object per line:
```json
{"claim_hash":"<sha256>","pipe_id":"A1","scope":"...","vintage_window":"...","work_kind":"data-fill","claimed_by":"<swarm/run id>","claimed_at":"<UTC>","status":"claimed|complete|released","result_ref":"<path or verdict id>"}
```

**The protocol (every swarm run, every time):**
1. Compute the claim hash for the intended work.
2. Search the registry for the hash. If `claimed` or `complete` → STAND DOWN, log the skip, do nothing else. (A completed claim is never reworked; a claimed-but-incomplete claim is respected until released or timed out.)
3. If absent → append a `claimed` line, do the work, then update to `complete` with `result_ref` (or `released` on failure).
4. Claims older than 7 days with status `claimed` (never completed) may be reclaimed by a new run — stale claims don't block forever. The reclaim appends a new line referencing the stale one.

**Near-duplicates** ("destined to do the same thing"): the hash catches exact duplicates. Near-duplicates — two pipes whose scopes overlap (e.g., A29 municipal finance vs B12 residual-law per municipality) — are caught by SCOPE REVIEW: before a new pipe's first run, its scope is checked against the registry's scopes; overlaps are resolved by narrowing scope or merging pipes, recorded in the registry. The registry is the map; the hash is the lock.

**Standing law:** no swarm does unclaimed work. No work is done twice. The hash is the proof.
