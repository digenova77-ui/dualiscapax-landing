# VALIDATION BATCH 2 — Reference Material (2026-09-29)

**Reference-only. Read-only. No vote, no decision, no seal, and no approval is
requested.** This batch is assembled solely as material for independent
validation by an outside agency.

## What this is

Copies of internal working documents from the RTE wave program (goal
`goal_0ea76fbf0d9f`), gathered so a reviewer can read and check them on their
own terms. Nothing in this batch asks the reviewer to do anything — there is no
decision to take, no execution to perform, nothing to sign off.

## Contents

- `pilot-slice-wave3-evidence-packet-20260929.md` / `pilot-slice-wave3-verdict-20260929.md`
- `pilot-slice-wave4-evidence-packet-20260929.md` / `pilot-slice-wave4-verdict-20260929.md`
- `pilot-slice-wave5-evidence-packet-20260929.md` / `pilot-slice-wave5-verdict-20260929.md`
- `pilot-slice-wave6-evidence-packet-20260929.md` / `pilot-slice-wave6-verdict-20260929.md`
- `pilot-slice-wave7-evidence-packet-20260929.md` / `pilot-slice-wave7-verdict-20260929.md`
- `pilot-slice-wave8-evidence-packet-20260929.md` / `pilot-slice-wave8-verdict-20260929.md`
- `pilot-slice-wave9-evidence-packet-20260929.md` / `pilot-slice-wave9-verdict-20260929.md`
  (Waves 3–9 evidence packets + verdicts)
- `ed-base3d-r1-verdict-20260929.md` through `ed-base3d-r5-verdict-20260929.md`
  (Base 3D rounds R1–R5 verdicts)
- `design-trinity-gate-law-20260929.md` (Design Trinity-Gate Law)
- `swarm-work-claim-idempotency-20260929.md`
  (Claim-scope standing convention, ED-SPEC-20260929-SWARM-CLAIMS-V1)
- `swarm-work-claims.jsonl` (live claim registry, copied as-is incl. comments)
- `MANIFEST.sha256` (SHA-256 of every file in this batch)

Nothing expected was absent at assembly time: every file listed above was
present and copied.

## How to verify integrity

After unzipping, from the batch root run:

    sha256sum -c MANIFEST.sha256

Every line should report `OK`.

## A note on verdicts

Any verdict, opinion, or finding the reviewer reaches on this material is a
**second set of eyes, not a higher court**. It does not override, ratify, or
replace any internal ruling; it stands as independent observation.

## Posture

DRAFT posture throughout. No seal. No deployment. No production writes.
Nothing in this batch is authorized for execution.
