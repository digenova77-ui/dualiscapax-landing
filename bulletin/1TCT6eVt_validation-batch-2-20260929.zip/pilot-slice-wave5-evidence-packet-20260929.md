# PILOT SLICE WAVE-5 EVIDENCE PACKET — ONTARIO x FOOD & AGRICULTURE x DERIVATIVES
Assembled: 2026-09-29T04:35:00Z | Cycle: pilot-slice-wave-5 | Mode: PILOT MODE (public/modeled figures only)
Matrix: Ontario x Food & Agriculture leads Wave 5 (the A2 weekly swarm's domain; the standing A2 Tuesday swarm has no registry claims yet — this wave is the full 60-figure pilot). Derivatives: Farm Economics, Food Security / Food Banks, Supply Chains, Agri-Food Employment, Land & Production.
Claim: a3d63fcf635e1f1bfd396a0dacf26353881c27ee07bd6605dc3f1ae61f0609f7 | pipe WAVE5 | scope ontario-food-agriculture | vintage 2026-Q3

## Data-fill files (sha256, independently anchored)
- Q1 Farm Economics: `data-fill/pilot/on-food-farmecon.md` sha256:1821be6e4e253b5d9ead41a43f0db370c54ae7be6b0a570ae4e625e20a6a89b3
- Q2 Food Security: `data-fill/pilot/on-food-security.md` sha256:83208a459e8a973278965d36fccd49207cc60b6a0fd156f237566cb4e443932a
- Q3 Supply Chains: `data-fill/pilot/on-food-supplychains.md` sha256:361e677325e3b6aa30efda82d2407142fc4e0cfccdc93f5c6048e051c8e56b53
- Q4 Employment: `data-fill/pilot/on-food-employment.md` sha256:9505877f7536039ca5e35d2bab33ade9424f145a8fc69a412d9ea71bbd7bae6f
- Q5 Land & Production: `data-fill/pilot/on-food-land.md` sha256:cef854a0a33d7cbfded384ee6b0d5596593591dd56fc7e171615ef9c1696313d

## Telemetry summary (honest single-pass)
- Single-pass subagent fill (no spawned workers — depth 2/2 prohibits spawning). All five derivatives researched and assembled by the same agent in one session, 2026-09-29 ~04:20–04:35 UTC (00:20–00:35 EDT).
- No forward-dating: all research and writes completed before packet assembly; no timestamps beyond the assembly time appear in any figure. Wave-4 follow-up rule applied: source filing metadata was checked for future timestamps — none found; the two most recent sources (retail-insider Sept 2026; OGVG fact sheet May 2026) both precede the assembly time. No hash anchoring was refused because no future-dated content was accepted.
- Data-per-cycle: 60 figures (5 batters x 12). No worker-telemetry apparatus applies this wave (no handoffs, no 15-field telemetry blocks); the verdict stations treat this as the noted deviation from the Wave-2 multi-worker model, same as Wave 4. No anomalies fabricated: the anomaly count for this wave is self-reported as 0, marked self-reported per the standing rule.

## A2 SCOPE NOTE (recorded per standing instruction)
The standing A2 weekly swarm (food systems & agriculture, Tuesdays ~09:52 EDT, ~12 figures/week) has NO claims in the registry yet. This wave — ED-VERDICT-20260929-PILOT-WAVE5-V1 — is the full 60-figure pilot for the Ontario food & agriculture pipe. A2's future weekly fills must scope AROUND this wave: every A2 work-claim must run the registry claim-hash check first and must NOT rework, re-grade, or re-fill these 60 figures. A2's weekly 12-figure fills should pick up NEW territory (deeper cuts, new vintages, sub-provincial drill-downs) and cite this verdict's figure inventory to avoid duplicate work. Idempotency law applies.

## Ground truth anchors carried verbatim
Feed Ontario 2025 Hunger Report (Dec 1, 2025): >1M Ontarians used a food bank Apr 2024–Mar 2025, 8.7M visits, 9th consecutive year of growth, +87% since 2019–20, 1 in 4 visitors employed, $6.2B/yr poverty-related health costs — ALL LABELED ADVOCACY (provincial food-bank network association, not a statistical agency). Census of Agriculture 2021 Ontario: 48,346 farms (−2.5%), 11,766,071 acres (−4.7%), 9,051,011 cropland acres (+0.3%), avg operator age 56.7 — with the 2021 definition break fenced (CRA tax-filing unit, replacing "intended for sale"). Ontario farm cash receipts 2025: $23.49B; farm debt year-end 2024: $42.8B (+13.5%). Agri-food: >$51B GDP 2024, >870,000 jobs (11% of workforce), $26.2B exports.

## Key findings by derivative (single-pass reported, Trinity adjudication pending)
- Farm economics: receipts rising ($23.49B in 2025, Ontario led the country's 2025 crop-receipt increase at +$723.3M) but debt rising faster — Ontario farm debt $42.8B at 2024 year-end (+13.5%), ~189% of the year's cash receipts (MODELED). National margins tightest since 2019: 2025 expense-to-receipt ratio 0.92 with depreciation; total net income 2024 $9.2B revised (national). Insolvencies: 97 national (ag/forestry/fishing/hunting, 2025) — Ontario-level count UNKNOWN, bundled sector. RMP funding ceiling $250M/yr (3 yrs).
- Food security: the advocacy leg is heavy — every Feed Ontario figure carries the advocacy label. Independent counterpoint: Canadian Income Survey — Ontario food insecurity 25.4% (2025, down from 26.5%), national severe 2.3M people (5.6%). The network's 2025 Hunger Report argues food-bank use precedes homelessness spikes (lead-lag correlation claim, held at argument). Income floor: Ontario Works $733/month, frozen five years. UNKNOWN: 2026 visit count; Ontario severity split.
- Supply chains: >$51B GDP, $26.2B exports, 60% of 200+ commodities processed in-province. F&B manufacturing: >3,000 establishments, >104,800 payroll employees, >$48B revenue (invest-promotion vintage, fenced). Grow Ontario targets (30% production / +8% exports/yr / +10% F&B GDP) banked as policy, not outcomes. Imports/trade balance UNKNOWN — the $26.2B export figure stands alone; no balance derived. Brampton $1.3B cluster held as LOCAL example only.
- Employment: >870,000 (11%) vs older 750,000 (one-in-ten, 2022) — vintage-fenced, not averaged. TFW footprint: 32,585 primary-ag + 13,018 food-bev mfg in Ontario (2024 preliminary, federal); SAWP ~20,000/yr across ~1,450 farms (industry admin). Advocacy figures fenced: greenhouse >35,000 value-chain jobs (OGVG), horticulture $5.4B/34,280 jobs (CAHRC), the "2 Canadian jobs per SAWP worker" multiplier (administrator's claim, never verified). Labour-market projection: ~65,000 new hires by 2034 (industry analysis, Sept 2026).
- Land & production: the consolidation story — farms −2.5%, farmland −4.7%, cropland +0.3% (intensification), operator age 56.7. Drought year 2025: corn 9.49M tonnes (175.6 bu/acre), soybeans 3.56M tonnes (45.7 bu/acre); Sept 2026 model forecasts a rebound (10.42M / 4.04M tonnes) — forecast, not harvest. Greenhouse: Ontario ~64% of Canada's 33.3M sq m (MODELED 21.3M sq m); OGVG advocacy profile ($1.9B+ farmgate, 229M/301M/131M kg). Field veg: 49.2% of national planted area, $815.1M farm-gate (2025). Farmland values national-only ($862→$3,947/acre 2001–2021); Ontario series UNKNOWN.

## Draft-to-verdict clock
- START: 2026-09-29T04:35:00Z (packet assembled; single-pass fill completed 2026-09-29 ~04:20–04:35 UTC)
- END: (chain call issued) — verdict: PENDING Trinity routing
- The write is theirs. Nothing deploys without it.
