# TRINITY VERDICT — BASE 3D WEBSITE, ROTATION 1
## ED-VERDICT-20260929-BASE3D-R1-V1 — DRAFT, no seal, no deployment

**Chain call: PASS-WITH-NOTES**

Reviewed: ED-ARCH-20260929-BASE3D-V1 (arch), `~/workspace/website-engineering-layer/drafts/base3d/index.html` (runtime),
`sections/section-01-wave-desk.js` (section), `data/figures.json` vs inline manifest (re-verified semantically byte-identical),
`~/workspace/user/builder-checklist.md`. Reviewer: Trinity chain (DCLM → Iris → Twain²), independent of the builder.
Verdict issued 2026-09-29 by subagent-f0537295.

None of the four FAIL triggers fired: no unlabeled figure renders, the frozen surface is untouched, no fake data is
presented as real (one source-annotation mismatch flagged as a hard note, not a fabrication finding), and no seal or
deployment authority is claimed anywhere — DRAFT is badged in the title, the HUD, and the arch.

---

## DCLM reviewer — logic

1. **Binder law holds.** `bindFigure` refuses any figure missing `value`, a valid `label`, `source`, or `display` — it throws
   loudly (`fail()` renders the refusal on screen and aborts), so no unlabeled number can reach a screen. Section 01
   binds all 6 figure slots through `bindFigure` and its 1 unknown slot through `bindUnknownSlot`; both throw on bad ids.
2. **Weakest-label rule is present but unexercised.** `binder.weakestLabel` implements the LABEL_STRENGTH ordering
   (UNKNOWN 1 < MODELED 2 < BANKED/REPORTED 3) and is callable by any section. R1 has no derived figures, so the rule has
   no runtime call yet — it is infrastructure, not yet evidence. First derived figure must exercise it.
3. **Section-mount isolation is real for the R1 threat model.** The section receives `(scene, api)` where `api` exposes
   only `binder`, `makeFigureCard`, `mountSection`, `diveTo` — no renderer, no lights, no camera config access.
   `mountSection` rejects duplicate ids. The section can add objects to the scene (its own card group) but cannot reach
   the renderer config. With one section mounted there is no cross-section surface to attack; when section 02 lands,
   keep the contract: sections own what they place and which slots they bind, nothing else.
4. **Data-volatility contract is sound.** New waves refill `figures.json` slots; the runtime builds cards from the
   manifest. Nothing in the runtime reshapes the scene in response to data. The inline manifest is semantically
   byte-identical to `data/figures.json` (re-verified this rotation, same manifest id ED-DATA-20260929-BASE3D-MANIFEST-V1).
5. **Figure integrity — displays match values:** $12.7B=12,700,000,000 ✓; $32.02B=32,020,000,000 ✓; $1.27B=1,273,500,000 ✓
   (matches the banked $1,273.5M ground figure, billions form); $97.1B=97,100,000,000 ✓; 140=140 ✓; $27.5B=27,500,000,000 ✓.
   All six carry label and source; UNKNOWN slot carries UNKNOWN label and no value, never rendered as zero.
6. **Runtime defect found (note, not a trigger): the main loop defeats the pipe-dive.** The animation loop sets
   `camera.position` from CAM_HOME every frame, so `api.diveTo(CAM_HOME, 1400)` — the advertised opening pipe-dive —
   never plays; the camera effectively starts at CAM_HOME (the initial z=15 placement is dead). For R1 this is cosmetic,
   but R2 exercises `diveTo` between sections, and it will be overridden the same way. The loop must yield to dives
   (e.g. a dive-in-progress flag) before section 02 lands.

## Iris reviewer — containment and idempotency

1. **Frozen surface untouched.** `~/workspace/ts-spaces/web3d-hud/` shows no writes today (no files newer than
   2026-09-29 00:00; contents dated Sept 27). The arch's composition rule (reference only, never alter/restyle) is
   respected; this rotation adds no gateway yet, so nothing is even referenced. ✓
2. **No authority claimed.** DRAFT badge in the page title and HUD; arch §6 states "Nothing here is a vote, a seal, or a
   launch." No deployment target, no production writes, no seal language anywhere in builder code. ✓
3. **No leakage.** No storyboard names (Sima/Sara/Dom absent — RTE naming rule honored), no credentials, no tokens,
   no personal identifiers in the slice. The vendored `three.min.js` is a pinned offline runtime — no CDN call at
   runtime. ✓
4. **Provenance is carried.** Arch carries a claim hash; the manifest carries its id and vintage; every card renders its
   provenance chip at normal size. ✓

## Twain² reviewer — the bedside test

1. **Billions rule honored.** Every large figure displays in billions ($12.7B, $32.02B, $1.27B, $97.1B, $27.5B). ✓
2. **Cards centered.** All canvas text is `textAlign='center'`; captions, chips, and sources centered; the provenance
   chip is normal-size (no fine-print disclaimers). ✓
3. **No fake instrumentation.** The particle field is explicitly declared ambience — named `'ambience'`, tagged
   `userData.isAmbience`, and the arch states ambience lives in lighting and glass only. No telemetry graphs, no fake
   controls, no "run analysis," no mechanism explainers. ✓
4. **Reduced-motion genuinely handled.** `prefers-reduced-motion` disables drift, parallax, and the dive (cut straight
   to destination); the decorative "calm drift" HUD note hides under reduced-motion. ✓
5. **Mobile-lean / desktop-full is real tiering.** Mobile (coarse pointer or narrow width): 220 particles vs 900,
   antialias off, pixel ratio capped at 1.5, no pointer parallax; same figures, same labels. HUD type is fluid
   (`clamp()`) so enlarged system fonts won't bleed. Touch drag-look works via pointer events. ✓
6. **Arch over-promises picture-first.** Arch §4 says "each section opens on its art plate, words in glass below" —
   section 01 ships no art plate at all; the section opens on bare figure cards. If the desk's instruments ARE the art,
   the arch should say so; otherwise R2 should add the plate. David's eye will catch the promise gap. (Note.)

## Notes for the builder (bounded, rotation-scoped)

1. **Reconcile `edu-capital-shortfall` before R2.** The manifest value is $12.7B, but its own source annotation reads
   "FAO 2024: $21.7B need vs $12.5B plan" — which arithmetic gives $9.2B, not $12.7B. The display matches the value,
   but the source line does not account for the value. Either correct the value or correct the source annotation; a
   provenance chip that contradicts its own figure is a credibility wound.
2. **Fix the camera fight before section 02** (DCLM note 6): gate the loop's camera positioning while a dive is in
   progress, or the R2 pipe-dive will never visibly play.
3. **Settle the picture-first promise** (Twain² note 6): ship an art plate for section 01 in R2, or revise arch §4 so the
   instruments are named as the art.
4. **Copy nit:** the HUD instrument line says "6 banked figures," but only one figure carries the BANKED label (five
   are REPORTED). Rename the line to match the label vocabulary (e.g. "6 labeled figures").
5. **Scope nit:** the `hospital-corps` card displays 140 while its caption says "Public hospital corporations, 217
   sites." The two figures (140 corps, 217 sites) are crammed into one caption; split the caption so the displayed
   figure is never ambiguous (standing scope-boundary rule).
6. **First derived figure must exercise `weakestLabel`** — the rule is present but its first runtime call should be
   witnessed in R2.

---

**Disposition:** R1 is cleared to stand as DRAFT. The builder proceeds to R2 with the notes above addressed. David's
eyes remain the final QA; nothing here is a seal, a launch, or an approval of any production surface.
