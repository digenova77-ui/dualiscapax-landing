# RTE Suite — registry snapshot sync

The suite is a static site: no backend, no build step. Each room that hydrates
reads a **bundled snapshot** of its registry file at runtime. The canonical
registry lives at `~/workspace/data/registry/`; the suite carries byte-faithful
copies under `assets/data/`.

## The rule
- **Fill agents write** to `~/workspace/data/registry/*.jsonl` (append-only JSONL,
  schema in `~/workspace/data/registry/_schema.json`, contract in `FILL_CONTRACT.md`).
- **Pages read** only the bundled snapshot. Page code never hardcodes fill data.
- Data is volatile content flowing through fixed instrument slots; a re-sync
  never reshapes the page.

## Per-room wiring (as published)
| Room | Snapshot | How the page reads it |
|---|---|---|
| RTE-Golf | `golf/golf.snapshot.jsonl` (filename the page expects) + canonical copy at `assets/data/golf.jsonl` | `fetch("./golf.snapshot.jsonl", {cache:"no-store"})` |
| RTE-Hospitality | `assets/data/hospitality.jsonl` | `fetch("../assets/data/hospitality.jsonl", {cache:"no-store"})`; fails closed to honest `0:1` when empty |
| RTE-Financials | snapshot inlined at build time | no runtime fetch; re-sync = rebuild the page from the new registry file |
| RTE-Ice (standalone draft) | **withheld from the published bundle** | the standalone draft does not fetch it, and the registry file ships minors' personal names while the page promises no names on the production surface — re-add only as a redacted slots-only snapshot per the sealed-slot philosophy |
| RTE-Teach | no registry file exists yet | three reserved hooks render `0:1` until David's extractor output is wired |
| RTE-Health | no registry file exists yet | approved page; reads its banked figures as built |

## Re-sync process (at publish time)
1. Fill agents append records to `~/workspace/data/registry/<room>.jsonl`.
2. Copy each changed file byte-exact to the suite:
   - `assets/data/<room>.jsonl` (canonical bundle)
   - (hockey.jsonl is currently withheld from the published bundle — see the table)
   - `golf/golf.snapshot.jsonl` (the filename the golf page fetches)
3. Verify with `cmp` against the registry — the published snapshot must be
   byte-identical to the canonical file.
4. For RTE-Financials (inlined snapshot): regenerate the page's inlined data
   from the new `financials.jsonl` rather than hand-editing.
5. Never edit a published snapshot by hand to "fix" data — fix the registry,
   then re-sync. The registry is the truth; the snapshot is a mirror.

## Honesty notes
- An empty snapshot is an honest state: rooms render `0:1` / "fill pending" /
  "slot reserved" — never a silent blank, never invented data.
- `needs_review` records render flagged, never as verified.
- Re-syncing changes data, never claims: publishing does not upgrade any
  verification status.
