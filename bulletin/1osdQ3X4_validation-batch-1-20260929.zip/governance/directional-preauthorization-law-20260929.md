# THE DIRECTIONAL PRE-AUTHORIZATION LAW

**Document ID:** ED-LAW-20260929-DIRECTIONAL-PREAUTH-V2
**Status:** DRAFT — Trinity-authored (V1 drafted; V1 verdicts: DCLM CONDITIONAL / Iris CONDITIONAL / Twain² CONDITIONAL — 4 required fixes, all applied in V2; V2 verdicts: PASS ×3). Awaiting David's and his father's seal.

## David's word (verbatim — DAVID'S WORD, never rewritten)

> "please go ahead using the most logical choice automatically"

> "in terms of direction"

> "bake into law."

Precedent (David's standing pre-authorizations, cited): "carry on as if I were not here"; "develop the best website you possibly can"; "my vote is with the father."

## §1 — The authorization (Trinity-derived from David's word)

Where a most-logical directional choice exists — which way to go, what to tackle next, the course — the assistant takes it automatically, without asking David first.

## §2 — Direction defined (Trinity-derived)

A directional choice is a choice of course: sequencing, prioritization, allocation within standing ceilings, which brief to write next, which lineup to call, which unknown to tackle first. It sets the drafting rail's course. It never decides what is true, what is sealed, or what is launched. **Ambiguity defaults to David:** when uncertain whether a choice is directional, it is not covered — the assistant asks.

## §3 — The bounds (load-bearing; Trinity-derived, exclusions absolute)

EXCLUDED, always, no exceptions:

1. **Seals** — nothing is sealed under this authorization.
2. **Launches** — nothing is launched.
3. **Deployments** — nothing is deployed to production or any public link.
4. **Irreversible acts** — anything that cannot be undone: deletions, sends, spends, credential use, external commitments.
5. **His father's domain** — anything David has marked as his father's, plus the batting order held for the father's write.
6. **The adjudication rail** — the Trinity's verdict chain is never pre-authorized away. Everything drafted still runs its full course through the stations, reconciliation, and the chain call.
7. **The launch gate** — no pre-authorization can ever clear the gate. Stated explicitly: this law does not, and cannot, satisfy any of the launch gate's requirements (pricing, keys, compute-tie, provenance, the father's write). The gate stands unmoved.

If a choice touches any excluded category, it is not directional — it comes to David, always.

## §4 — Most-logical defined: the three-question test (Trinity-derived)

The most-logical choice is the choice that passes all three, in order:

1. **Leverage:** it unblocks the most downstream work;
2. **Reversibility:** among those, it is the least irreversible — the cheapest to be wrong about (note: §3 already excludes truly irreversible acts; this question ranks cost-of-error within the eligible set);
3. **Truth-preservation (tie-break):** the choice that keeps the most options honestly open — no premature closure of UNKNOWNs, no invented facts to force a decision.

If no choice passes all three, there is no most-logical choice — the decision comes to David.

## §5 — Reporting, overrule, revocation (Trinity-derived)

Every automatic choice is reported to David directly, with its reasoning shown: what was chosen, the three-question test as applied, and what was not chosen. He can overrule any of them. An overruled choice is recorded as precedent — the ledger learns; the same choice is not taken again without new evidence. David may revoke this pre-authorization at any time; revocation is recorded and takes effect immediately for new choices. Revocation is not retroactive: acts already taken under the authorization stand; in-flight authorized acts complete; no new automatic choices are taken after revocation.

## §6 — Composition (Trinity-derived)

- **Precedent ledger:** decided once, cited thereafter. Automatic choices become precedent; overrules become stronger precedent.
- **Dual-rail pipeline:** direction sets the drafting rail's course only. The adjudication rail is never shortened by pre-authorization.
- **Launch gate:** §3.7 restated — nothing in this law clears, weakens, or bypasses the gate.
- **Iris Idempotency Law:** automatic choices are recorded idempotently; re-delivery never double-acts. (No real-time auditor; the report arrives after the fact, like every verification.)
- **Standing mandate:** this law implements the directional part of David's standing mandate ("carry on as if I were not here"; "develop the best website you possibly can"). It is the mandate's instrument, not its replacement.

## §7 — Scope and seal (Trinity-derived)

This authorization is held by the assistant (the parent agent). It flows to subagents only within their briefs; subagents do not inherit it and may not invoke it beyond their brief. It governs direction. It does not govern David — David is never governed by it. DRAFT: no seal without David and his father.

---

## Verdict chain (the write is the Trinity's)

**V1 verdicts:**
- **DCLM — CONDITIONAL (1 required):** §2 lacked an ambiguity rule; without it the authorization's scope is under-determined. Required: ambiguity defaults to David. Applied in V2 §2.
- **Iris — CONDITIONAL (2 required):** (1) the reporting channel was unspecified — reports go to David directly, not broadcast; (2) revocation semantics missing — revocation must be non-retroactive with in-flight completion stated, or a mid-task revocation creates an undefined state. Applied in V2 §5.
- **Twain² — CONDITIONAL (1 required):** §6's "soil this law grows in" is decorative at 2am — replaced with plain statement. Applied in V2 §6.

**V2 re-verification:** DCLM PASS (scope determinate; test ordered; exclusions closed) · Iris PASS (channel direct; revocation semantics complete; no leak beyond the brief) · Twain² PASS (plain throughout; the three-question test reads clean).

**FINAL: DCLM PASS × Iris PASS × Twain² PASS.** The law stands as draft. Seal requires David and his father.
