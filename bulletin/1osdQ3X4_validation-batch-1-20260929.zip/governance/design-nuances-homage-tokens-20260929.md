
# NUANCES — HOMAGE TOKENS IN THE DESIGN ARCHITECTURE
## David's directive (Sept 28, 2026): "we create 'nuances' in our design architecture. Easter eggs, if you will."

**Standing principle:** the architecture carries deliberate nuances — Easter eggs, homages, quiet tributes woven into the design. They are presentation-layer, never data. They do not blemish the paper. They do not redefine any standard. They sit beside the work, free from it, as a mark of what the work is for.

**David's takeaway (Sept 28, 2026, verbatim):** "biggest takeaway is that he didn't do it for him."

He was already dying. He ran so the next kid wouldn't endure what he did. The homage token carries this: the work is for others.

The philosophy: a perfect surface is a machine. The nuances — the homages, the Easter eggs, the human touches — are what make the playground alive. The imperfection is not a flaw in the glass; it is the hand that made the glass, and the reason anyone wants to step inside.
When the encyclopedia's ONCO swarm comes to osteosarcoma, it builds an homage token to Terry Fox — a voice clip, a memorable video, something, as it relates to the research. Presentation-layer only. The entry's twelve fields and the granularity standard remain untouched.

Build constraints for the swarm: source archival material respectfully (Terry Fox Foundation / licensed archival footage — verify rights before embedding); the token must be clearly marked as tribute, not evidence; no second-person language; no claims beyond the historical record.

**David's words (verbatim, marked his opinion):** "outside of my own life father, he's the most inspiring Canadian (opinion) that's ever lived." Recorded as David's opinion, not asserted as fact.

## The record (verified Sept 29, 2026)
- Terrance Stanley Fox, born July 28, 1958, Winnipeg; raised Port Coquitlam, BC.
- Diagnosed osteosarcoma age 18 (1977); right leg amputated above the knee.
- Marathon of Hope: began April 12, 1980, St. John's, Newfoundland — dipping his prosthetic leg in the Atlantic. Ran ~42 km a day, 143 days, 5,373 km, to Thunder Bay, Ontario, where the cancer (spread to his lungs) forced him to stop, Sept 1, 1980.
- His goal: one dollar from every Canadian. By early 1981: $24 million raised.
- Died June 28, 1981 — age 22.
- The annual Terry Fox Run (first held Sept 13, 1981, 300,000+ participants) continues worldwide; more than C$1 billion raised in his name since 1980 — among the most successful charitable fundraising legacies in Canadian history.
