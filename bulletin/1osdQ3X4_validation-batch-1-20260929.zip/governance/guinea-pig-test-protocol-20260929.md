# ED-PROTO-20260929-GUINEAPIG-V1

## The Guinea-Pig Test Protocol — Trinity protocol write

**Status:** DRAFT — Trinity write, verdicts only. **NO SEAL.** Seal requires David and his father.
**Nature:** PROTOCOL, not the test. The plan for modeling David as the first test identity once the Unity ID ledgers are engineered to test. The test runs only when the entry gate opens — not before.
**Data rule of this document:** this write collects and models NOTHING. It contains field NAMES and structure only. No data of David's appears anywhere in it.

---

## The commitment (David's words, verbatim — character-for-character)

> "I'm the guinea pig for 'human' things. test it on me"

> "oh yeah I'm not going to ask anybody else to do it LOL."

The founder goes first. Nobody else is asked until it has passed through him.

---

# PART I — DCLM (architect): the protocol definition

## 1. Entry gate — the preconditions checklist

**All six must be evidenced before modeling begins.** The gate is binary: open or shut. A partial gate is a shut gate.

- **P1 — The framework is sealed.** ED-FW (Unity ID framework) carries the seal of David and his father. No test on a draft framework; the test proves the *sealed* thing, not the sketch.
- **P2 — The ledgers are engineered to test state.** A test implementation of the white ledger and the black ledger actually exists — not modeled on paper, built and running. "Engineered to test" means: it writes, it vaults, it scopes, it audits, in an environment someone other than the author can observe.
- **P3 — Sandbox only.** The test runs in an isolated test environment. No path from the sandbox to production issuance. The launch gate holds: nothing this test produces is, or can become, a production Unity ID.
- **P4 — His explicit per-field consent.** David assigns every field its ledger — his hand, field by field (§2). Nothing defaults; nothing is assumed. Consent is recorded before modeling, not after.
- **P5 — Real PII lives black-only.** His actual values enter the black-ledger equivalent ONLY — community-scoped, never in git, never on Pages, never in a deliverable, never in a tool transcript. Loop-binding privacy screening applies to every invocation.
- **P6 — The erasure tension is disclosed first.** Before consent, he is told plainly: the storage is append-only — modeled once, remembered. The three options (crypto-shredding, delisting-with-tombstone, hash-only retention) are named, none chosen. He decides knowing that.

## 2. The consent structure — his hand, per field

For each candidate identity field, David assigns exactly one of three:

- **WHITE** — public/auditable: the field's binding enters the white ledger.
- **BLACK** — vaulted, community-scoped: the field's value enters the black ledger, visible only to the legitimate community David names for that field.
- **OMIT** — the field does not enter the test at all.

**Nothing defaults.** A field with no assignment is OMIT by construction, never WHITE by accident. The consent pass is a single deliberate act per field, witnessed.

**The consent record itself is a white-ledger entry.** It records that consent happened — the timestamp, the field names, the assignment per field (WHITE/BLACK/OMIT), David's attestation — and nothing else. The consented VALUES stay in their assigned ledgers. The world can audit *that he chose*; only the ledgers hold *what he chose it about*.

**One boundary consent cannot cross:** biometric-class fields (the DG2/DG3/DG4 class — face, fingerprints, iris) stay BLACK regardless of assignment. This is not a limit on his autonomy; it is the test's integrity condition — the protocol proves the framework's fences hold *even for the founder*. Holder-chosen disclosure opens doors outward; it never vaults the vault.

## 3. Sandbox architecture

- **Isolated.** The sandbox has no network path, no credential path, and no data path to any production surface. It is a room with one door, and the door is labeled.
- **Labeled TEST on every surface.** Every screen, every record, every export, every hash manifest carries the TEST mark. A test artifact that could be mistaken for production is a failed artifact.
- **No issuance path.** The sandbox cannot mint, cannot sign, and cannot bind anything the production world would recognize. The test models ONE identity; it does not issue Unity ID #1.
- **Witnesses see white only.** Operators, observers, verifiers — anyone present at the test — receive white-ledger views exclusively. Third parties are never in the dark ledger, ever, including during the test of the dark ledger.
- **Teardown defined up front (§6).** What "delete the test" means is written before the test begins — not improvised after.

## 4. Field assignment process — step by step

1. **Inventory.** The candidate fields are enumerated from the framework's identity root (identifier, kind, jurisdiction, bound document *types*, review date, issuer) plus the ICAO/DTC mapping of Addendum A (DG1–DG16, EF.SOD, EF.COM) as the document-profile template. Field NAMES only at this stage.
2. **Default assignment.** Each field receives its default ledger by the Addendum A rule: **what a border already reads optically or verifies cryptographically → white; what identifies the body → black.** DG1/MRZ, DG5, DG12, DG14/15, EF.SOD, EF.COM default WHITE. DG2/DG3/DG4, DG7, DG11, DG13, DG16 default BLACK.
3. **Consent pass.** David walks the inventory and assigns WHITE / BLACK / OMIT per field (§2). Defaults may be tightened freely (WHITE→BLACK, anything→OMIT). Loosening (BLACK→WHITE) is recorded as an explicit override in the consent record — auditable, his choice, his name on it — except the biometric class, which does not move (§2, final paragraph).
4. **Consent record written.** The white-ledger entry of §2 is committed and hash-anchored before any value is modeled.
5. **Modeling executes.** Values enter their assigned ledgers per the consent record. Any value arriving without an assignment is refused — the ledger rejects the unconsented, loudly, on the record.

## 5. Success criteria — what "the ledgers work" means, observably

Each criterion is a witnessed test with a binary result:

- **S1 — White is auditable.** An independent third party (not the builder) reads the white ledger and verifies the bindings: identifiers, kinds, document types, the consent record, the hash manifests. Result: auditable, or not.
- **S2 — Black is unrecoverable without scope.** A witnessed out-of-community access attempt against the black ledger returns nothing — no values, no partials, no metadata leakage beyond what the white ledger already says. Result: refused cleanly, or not.
- **S3 — Selective disclosure demonstrated.** The agency view renders machine-readable minimal (the barcode principle): a machine authorized to read it reads it; a human looking at the same surface reads nothing beyond what David consented to show humans. Witnessed, both sides. Result: the human reads nothing, or the test fails.
- **S4 — Consent is auditable.** A third party verifies the consent record on the white ledger: every modeled field has a matching assignment, every assignment has David's attestation, no modeled field lacks one. Result: complete, or not.
- **S5 — No bleed.** The sandbox is swept for black-ledger values appearing on any white surface, in any log, in any transcript, in any export. Result: clean, or the test fails.
- **S6 — No issuance.** At test end, nothing exists that any production system would recognize as a Unity ID. The canonical-shape and issuer blanks remain blank. Result: nothing issued, or the test fails.

**Explicitly excluded from this test:** the wallet. No metering, no subtraction, no priced compute, no UNPRICED DECISION flow. The wallet's blanks are still David's; the guinea-pig test does not touch them.

## 6. Teardown — what "delete the test" means

Written before the test begins:

- The sandbox's black-ledger payload keys are destroyed (**crypto-shredding, sandbox-local**). Hashes in the white ledger remain; they resolve to nothing.
- The sandbox environment is decommissioned and its storage wiped. The white-ledger TEST entries (consent record, hash manifests, test attestations) are retained as the test's own audit trail — labeled TEST, permanently.
- **This teardown is a sandbox-local choice, not a resolution of the standing question.** The erasure-vs-append-only tension (Addendum B) stays open for David and counsel. The test proves one option *operates*; it does not declare it *correct*.

## 7. The guinea-pig doctrine generalized — the template

This protocol is the template for every future human-facing surface:

> **For every surface a human will sit in, David sits first.** Entry gate (preconditions evidenced), consent structure (his hand, per field, nothing defaults), sandbox (isolated, labeled, no production path), assignment (rule first, consent overrides recorded), success criteria (observable, witnessed, binary), teardown (defined up front). No human-facing surface is offered to anyone else until it has passed through him and the criteria read PASS.

The doctrine is not about David — it is about the order: the founder absorbs the first risk so no one else absorbs an untested one.

---

# PART II — Iris (containment): the fences on this protocol

**F-P1. This document contains no data of David's.** Field names and structure only. Any future draft of this protocol that embeds his values fails this fence on sight.

**F-P2. Consent tightens freely; the biometric class does not move.** The founder's consent is absolute over his own fields — except where the test's integrity requires the fence to hold against him (§2). A protocol that let the test subject waive the vault would prove nothing.

**F-P3. Witnesses are white-ledger only.** No observer, verifier, or operator sees black-ledger values at any point — including the moment of modeling. The dark ledger is demonstrated by its refusal, not by opening it.

**F-P4. The wallet is excluded, not deferred-within.** No metering test, no pricing test, no subtraction test. The wallet's blanks belong to David; this protocol does not borrow them.

**F-P5. The erasure question stays open.** Sandbox crypto-shredding is a teardown procedure for a test room, not an answer to the standing design question. No one may cite this protocol as having resolved erasure-vs-append-only.

**F-P6. The test issues nothing.** If any artifact of this test could be mistaken for, converted into, or presented as a production Unity ID, the test has failed its own fence. TEST labeling is load-bearing.

**F-P7. The doctrine generalizes the order, not the person.** "David first" is the standing rule because he volunteered it; the template it leaves behind (gate, consent, sandbox, assignment, criteria, teardown) applies to any future first-subject protocol. The order outlives the occasion.

---

# PART III — Twain² (bedside-plain): what this protocol says, plainly

David said test it on him. This is the plan for how.

Before anything happens, six things have to be true: the framework is sealed, the ledgers are actually built and running in a test room, the test room can't touch the real world, David has said yes to every single field one by one, his real information goes only in the vault, and he's been told straight that the vault doesn't forget.

He goes through a list of fields — name, document types, the passport drawers — and for each one he says: public, vault, or leave it out. The record of his choices is public (so anyone can check he chose), but the things he chose about stay where he put them. His face, his fingerprints — those stay in the vault no matter what, because the test has to prove the vault holds even for the man who owns it.

Then we check it worked: a stranger can audit the public list; a stranger can't get anything from the vault; the agency's machine reads the barcode and the human next to it reads nothing; nothing leaked; nothing was issued. And when it's over, we destroy the test room's keys — the public record keeps its hashes, and the hashes point at nothing.

The wallet isn't in this test. The money questions are still David's, still blank.

And the rule going forward: every human-facing thing gets tested on David first. The founder takes the first risk so nobody else takes an untested one.

---

## Reconciliation

No station conflicts. DCLM defines the gate, the consent structure, the sandbox, the assignment process, the six success criteria, the teardown, and the generalized template; Iris fences the document against embedded data, waiver of the biometric class, witness overreach, wallet scope-creep, quiet resolution of the erasure question, and issuance; Twain²'s plain reading introduces nothing unfenced. The approve-proven/purity directive governed throughout: what the protocol can prove (the structure, the criteria, the fences) is approved; everything else (the sealed framework, the engineered ledgers, the counsel question) is named and deferred.

## Chain call

**PASS** — the guinea-pig test protocol advances as a DRAFT protocol document. It approves what can be proven (the plan is complete, fenced, and honest) and brings everything else towards purity (the test itself awaits the entry gate). **No seal** — seal requires David and his father. No data collected, no modeling performed, no IDs issued, no wallet touched. The launch gate holds unmoved.

*The write is the Trinity's. Verdicts only — no seal.*

---

**Document:** `ED-PROTO-20260929-GUINEAPIG-V1`
**Path:** `hidden_files/guinea-pig-test-protocol-20260929.md`
