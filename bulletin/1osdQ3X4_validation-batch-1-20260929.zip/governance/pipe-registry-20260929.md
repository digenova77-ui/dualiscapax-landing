
# THE PIPE REGISTRY — ED-REG-20260929-PIPES-V1
## David's mandate (Sept 28, 2026): "how many different pipes can you conjure right now... and start to assign them to bots that'll work on them even if I'm not here and even if you're not here"

**Standing law:** ideas → pipes → swarms. Every pipe is dual inside (two things considered or DECIDED, at whatever depth). Every pipe gets a swarm. Swarms run standing — scheduled, unattended, verdict-gated.

**Count: 50 pipes conjured.** 30 NEW (no data at all) + 20 DERIVATIVE (deeper on data we hold).

---

## PART A — NEW PIPES (no data at all) — 30

### A1. Municipal water & wastewater (Ontario)
Why: RTE Wave 1 named Water; never built. Every municipality runs one; nobody models them.
Dual: supply vs demand / purity vs cost.
Start: municipal water financial plans (O. Reg. 453/07 filings are public).

### A2. Food systems & agriculture (Ontario)
Why: RTE Wave 1 named Food; never built. Farm → processor → table.
Dual: production vs security / price vs resilience.
Start: OMAFRA public statistics, census of agriculture.

### A3. Climate adaptation modeling (municipal)
Why: RTE Wave 1 named Climate; never built. Municipalities face the costs first.
Dual: mitigation vs adaptation / modeled risk vs measured loss.
Start: municipal climate plans, insurance loss data.

### A4. Pandemic preparedness & stockpiles
Why: RTE Wave 1 named Pandemic; never built. The last one taught nothing durable.
Dual: readiness vs cost / speed vs accuracy.
Start: PHO reports, federal stockpile disclosures.

### A5. Electricity grid & utilities (Hydro One, IESO, LDCs)
Why: every decision the machine prices needs the energy oracle — this pipe BUILDS the oracle's data.
Dual: generation vs demand / price vs reliability.
Start: IESO public reports, OEB filings.

### A6. Housing supply & affordability
Why: the crisis every jurisdiction shares; modeled badly everywhere.
Dual: supply vs price / ownership vs shelter.
Start: CMHC, municipal housing plans, Starts data.

### A7. Mental health & addictions systems
Why: the parallel healthcare system nobody maps; Wave 1 touched opioids only.
Dual: treatment vs harm reduction / measured vs hidden need.
Start: ConnexOntario, coroner data, program budgets.

### A8. Courts & criminal justice flows
Why: backlog is a flow problem; flows are modelable.
Dual: speed vs justice / punishment vs restoration.
Start: court statistics, legal aid data.

### A9. Child welfare & social services
Why: high stakes, low visibility, modelable caseloads.
Dual: protection vs family unity / intervention vs support.
Start: children's aid society reports, ministry data.

### A10. Immigration & settlement systems
Why: Canada's growth engine; settlement outcomes vary wildly.
Dual: intake vs integration / speed vs settlement success.
Start: IRCC public data, settlement agency reports.

### A11. Broadband & telecom coverage
Why: the digital divide is geographic; geography is mappable.
Dual: coverage vs quality / urban vs rural.
Start: CRTC broadband fund maps, ISED data.

### A12. Critical minerals & supply chains
Why: Ontario sits on the Ring of Fire; sovereignty needs the map.
Dual: extraction vs stewardship / domestic vs export.
Start: NRCan, Ontario mining statistics.

### A13. Insurance markets (auto, property)
Why: FSRA regulates; rates are public-ish; models are private. Build the public model.
Dual: risk vs premium / pooled vs individual.
Start: FSRA filings, GISA auto data.

### A14. Pension & retirement systems
Why: OMERS, HOOPP, OTPP — trillions modeled opaquely. The public deserves the model.
Dual: contribution vs benefit / present vs future retiree.
Start: pension plan annual reports (public).

### A15. Emergency management & disaster response
Why: floods, fires, ice storms — response is a logistics simulation.
Dual: readiness vs response / centralized vs community.
Start: EMO Ontario, municipal emergency plans.

### A16. Waste, recycling & circular economy
Why: every municipality pays; nobody optimizes publicly.
Dual: diversion vs cost / producer vs municipal responsibility.
Start: RPRA datacall, municipal waste reports.

### A17. Forestry & natural resources
Why: Crown land, licenses, mills — a public asset modeled privately.
Dual: harvest vs conservation / jobs vs ecosystem.
Start: MNRF state of the forest reports.

### A18. Mining economics & royalties
Why: who gets what from the ground — a public question with private answers.
Dual: royalty vs investment / extraction vs remediation.
Start: Ontario mining stats, royalty filings.

### A19. Tourism & hospitality economics
Why: the RTE desk named hospitality as a module; never built.
Dual: visitation vs sustainability / seasonal vs year-round.
Start: Destination Ontario, municipal tourism data.

### A20. Arts, culture & heritage funding
Why: grant systems are allocation problems; allocations are modelable.
Dual: excellence vs access / project vs operating.
Start: OAC, Canada Council public data.

### A21. Electoral systems & democratic health
Why: turnout, representation, boundaries — the machine that chooses the choosers.
Dual: representation vs efficiency / access vs integrity.
Start: Elections Ontario/Canada public results.

### A22. Tax & revenue modeling (municipal/provincial)
Why: every budget is a revenue model wearing a trench coat.
Dual: burden vs service / growth vs stability.
Start: municipal FIRs (public), provincial public accounts.

### A23. Government procurement & contracting
Why: billions tendered; patterns visible to anyone who looks.
Dual: price vs value / open vs incumbent.
Start: Ontario Tenders, municipal procurement portals.

### A24. AI compute markets & the energy cost of intelligence
Why: FEEDS THE ENERGY ORACLE BLANK — the launch gate needs kwh_per_mode; this pipe finds it.
Dual: capability vs energy / centralized vs distributed compute.
Start: cloud pricing, datacenter filings, chip efficiency curves.

### A25. Pharmaceutical supply chains
Why: shortages kill; the chain is modelable; pharmacology's sibling.
Dual: just-in-time vs stockpile / cost vs security.
Start: Health Canada shortages database, distributor data.

### A26. Blood, organ & transplant systems
Why: waitlists are queues; queues are simulations.
Dual: supply vs demand / equity vs urgency.
Start: Ontario Health (Trillium Gift of Life) public data.

### A27. Disability services & accessibility
Why: ODSP, accessibility compliance — systems serving millions, mapped by few.
Dual: support vs independence / standard vs accommodation.
Start: ministry program data, AODA compliance reports.

### A28. Veterinary & animal health
Why: food safety's first line; zoonotic risk's early warning.
Dual: animal vs human health / production vs welfare.
Start: OMAFRA animal health data, CFIA.

### A29. Municipal finance & property tax modeling
Why: the FIR is public for every municipality — 444 ontologies of the same question.
Dual: levy vs service / residential vs commercial burden.
Start: municipal Financial Information Returns (public).

### A30. Funeral, bereavement & end-of-life economics
Why: every family pays; nobody models; the data exists.
Dual: grief vs commerce / ritual vs cost.
Start: BAO Ontario public data, price surveys.

---

## PART B — DERIVATIVE PIPES (have data, go deeper) — 20

### B1. Hospital-by-hospital Ontario (140+)
From: QHC vs KHSC pilot (2 hospitals). Go deeper: every Ontario hospital corporation, same pilot-mode figures.
Dual: capacity vs demand / reported vs modeled.

### B2. ED flow simulation per hospital
From: ED visit counts. Go deeper: triage-to-discharge flow models, wait-time drivers.
Dual: throughput vs acuity / staffed vs funded beds.

### B3. Waitlist dynamics (surgical, diagnostic, LTC)
From: LTC waitlist figure (34,862 modeled). Go deeper: inflow/outflow simulation per list.
Dual: need vs capacity / waiting vs served.

### B4. Healthcare staffing models (nursing, PSW, physician)
From: FTE figures. Go deeper: vacancy, burnout, agency-staffing cost spirals.
Dual: supply vs demand / permanent vs agency.

### B5. Per-school-board deep dives (72)
From: 72 boards, $32.02B envelope. Go deeper: each board modeled individually.
Dual: funding vs outcome / classroom vs administration.

### B6. Per-school modeling (4,684)
From: board aggregates. Go deeper: school-level friction mapping.
Dual: school vs board / measured vs modeled.

### B7. Per-transit-agency Ontario (108)
From: 108 agencies, TTC/GO figures. Go deeper: each agency's recovery and cost structure.
Dual: ridership vs subsidy / urban vs rural service.

### B8. Per-corridor freight (Ambassador, Blue Water, HOPA...)
From: corridor figures. Go deeper: crossing-by-crossing, port-by-port dynamics.
Dual: flow vs capacity / truck vs marine vs rail.

### B9. Airport-by-airport (Pearson, Billy Bishop, Ottawa, Hamilton...)
From: aviation figures. Go deeper: each airport's recovery curve and economics.
Dual: passenger vs cargo / hub vs regional.

### B10. Encyclopedia domain waves (neurological, oncological...)
From: the encyclopedia program (running). Go deeper: each domain swarm's disease list.
Dual: known vs unknown / atlas vs advisor (never crosses).

### B11. Pharmacology Stage-2 (post hold-lift)
From: Stage-1 sealed. Go deeper: activated ONLY when Condition 6 clears — the pipe waits, defined, patient.
Dual: sealed vs open / safety vs speed.

### B12. Residual-law per municipality (444)
From: $1.27B friction figure. Go deeper: each municipality's recoverable friction.
Dual: waste vs service / modeled vs proven.

### B13. eFuse tokenomics & energy oracle design
From: pricing law T(e)=√(D×E). Go deeper: the oracle, kwh_per_mode, conversion — the launch-gate blanks.
Dual: price vs energy / fixed vs adaptive.

### B14. Unity wallet metering (decision-unit economics)
From: wallet-beneath architecture. Go deeper: prepaid drawdown mechanics, receipting, recomputation.
Dual: prepaid vs metered / user vs machine pricing (David prices).

### B15. RTE-Teach per-role (teacher, EA, ECE, admin)
From: Sara seat, board data. Go deeper: each role's friction, modeled separately.
Dual: role vs person / task vs job.

### B16. RTE-Health per-role (RPN, RN, PSW, clerk, manager)
From: Sima seat. Go deeper: each role's task matrix and relief value.
Dual: role vs person / clinical vs administrative.

### B17. Hockey per-league/per-team pipeline
From: QRD/Dom seat. Go deeper: league-wide modeling, team-by-team.
Dual: development vs winning / ice time vs growth.

### B18. Financial bot swarm live scenarios
From: DCLM financial bot swarm sim. Go deeper: scenario library, stress tests.
Dual: modeled vs market / backtest vs live (never live without sanction).

### B19. Legal front-end per-practice-area
From: legal sim engine. Go deeper: family, criminal, corporate, real estate — each its own pipe.
Dual: process vs outcome / access vs cost.

### B20. Vehicular ownership per municipality
From: Unity vehicular sim. Go deeper: ownership cost modeling per town.
Dual: owning vs sharing / urban vs rural.

---

## PART C — STANDING SWARM ASSIGNMENTS

**Rule:** every pipe gets a swarm; swarms run standing (scheduled, unattended), verdict-gated per output. Priority order:
1. **Wave-1 RTE pipes first** (A1–A4: water, food, climate, pandemic) — the original mandate, never built.
2. **Launch-gate feeders** (A24 compute-energy → the energy oracle blank; B13 eFuse; B14 wallet).
3. **Derivatives of proven data** (B1–B9: hospital-by-hospital, per-board, per-agency...) — cheapest, data in hand.
4. **The rest**, in batches, by David's call or the three-question test.

**Seeded standing swarms (created 2026-09-29, weekly, verdict-gated, claim-hash idempotent):**
- `swarm-pipe-a1-water-weekly` — Mondays ~09:52 EDT — water & wastewater data-fill
- `swarm-pipe-a2-food-weekly` — Tuesdays ~09:52 EDT — food & agriculture data-fill
- `swarm-pipe-a3-climate-weekly` — Wednesdays ~09:52 EDT — climate adaptation data-fill
- `swarm-pipe-a4-pandemic-weekly` — Thursdays ~09:52 EDT — pandemic preparedness data-fill
- Idempotency: ED-SPEC-20260929-SWARM-CLAIMS-V1; registry `swarm-work-claims.jsonl`. No swarm does unclaimed work; no work is done twice.

**Registry law:** any new idea becomes a pipe (dual inside), any pipe becomes a swarm. The registry grows; the count is a floor, not a ceiling.
