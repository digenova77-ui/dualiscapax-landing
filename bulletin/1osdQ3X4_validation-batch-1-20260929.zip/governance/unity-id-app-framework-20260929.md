# ED-FW-20260929-UNITYID-APP-V3

## The Unity ID Application Framework — Trinity architectural write

**Status:** DRAFT — Trinity write, verdicts only. **NO SEAL.** Seal requires David and his father.
**Nature:** FRAMEWORK, not build. No implementation, no production Unity IDs issued, no wallet loaded, no money movement, no credential minting, nothing launch-shaped. The launch gate holds unmoved.

---

## The endorsement and the words (David's words, verbatim — character-for-character, never weakened)

> "would it be wise to create an iris AI app that loads your wallet for compute? or is it a Unity ID app that has Iris built in?"

> "something else me that if we create UNITY, we can begin to define the architecture that simply loads everybody else's app right into ours so the only thing that you're using in a few years or a few months is this app or this playground. and it's not that we circumvented anything. we simply integrated it"

> "I don't want to build in the years of work tonight I just want to build the framework so that it's accepting of that kind of ideology in the future and hasn't been hard coded to 'not adopt it'. I believe the architecture should be built open for compatibility with everything and it's our job to put swarms on the integration of everything"

> "yes the unity ID is dual pipeline white Ledger dark Ledger"

> "and for shared access with other third parties like children friends etc"

> "you can white list and blacklist that so it's not just one platform it's absolute Unity"

> "yes we keep it separate from The black list or black Ledger rather. what I mean is things like Health data or black to everyone but the Health community that require them legitimately and driver's license can show your name can even show your number if you wanted to you can show anything you want but it only shows the critical things like the bar code to the agencies that read those. there is no other point. humans can't read barcode"

**The endorsed sequence** (recommended to David, endorsed by his ❤️ — Trinity-derived, not his verbatim): identity first, then Iris, then the wallet, then the integrations. The house before the guests. The wallet converges with the eFuse eventually. The integration doctrine: *"not circumvented, simply integrated."*

---

# PART I — DCLM (architect): the framework definition

## 1. The layer order is the architecture

The application is four layers in a fixed sequence. The sequence is not a suggestion — it is the dependency order, and nothing may be built out of order:

**Layer 1 — Identity (Unity ID).** The platform root. The app IS the identity app; everything else seats inside it. Nothing computes, nothing integrates, nothing bills until identity is bound.

**Layer 2 — Iris, built in.** The intelligence inside the identity app, never a standalone app. Her containment — the idempotency law (ED-LAW-20260929-IRIS-IDEMPOTENCY-V3), the honesty boundaries — rides with her wherever she seats. One Iris, in the one app; she does not fork per seat.

**Layer 3 — The wallet, beneath.** Compute as the paid surface, metered in decision units under the pricing law: `T(e) = √(D(e) × E(e))`, `owed(P) = Σ T(e)`, decisions atomic, `prov(e) ∈ {HUMAN, SILICON, MIXED}` mandatory — no provenance, no metering. The wallet is the balance-going-down surface (prepaid crypto bank, drawn down by priced compute; no checkout friction, every subtraction receipted and recomputable). It is beneath: it funds the compute, it never prices it. The machine does not set prices; David does.

**Layer 4 — The integrations.** Everybody else's apps loaded in. Months work to build the architecture that *can* load them; years work for the ecosystem to arrive. The platform precedes the ecosystem; the framework does not promise the ecosystem on the platform's timeline.

## 2. The identity root is dual-pipeline (David's ruling)

`david-ruling-unityid-dual-ledger-20260929.md` is incorporated by reference:

- **White ledger** — public, auditable: identifier, kind (human/org/bot), jurisdiction, bound document *types* only, review date, issuer. Anyone can audit where they bound.
- **Black ledger** — private, vaulted, **community-scoped**: health data is black to everyone except the health community that legitimately requires it; each legitimate community sees what it legitimately requires; black to all others. Hashes plus attestation only. Never on Pages, never in git. **Terminology: the black ledger is the dark store; "blacklist" is white-ledger access control. Separate things.**
- **Whitelist / blacklist are native white-ledger capabilities**, enforced at the Unity level — absolute Unity, not per-platform. Third parties seeking shared access are whitelisted or blacklisted on the white pipeline; **third parties are never in the dark ledger, ever.**
- **Shared and delegated access** — children, friends, third parties: encompassed children act through their operator; friends and third parties get scoped, delegated visibility — never the dark ledger raw. Share from the white ledger, vault the dark.
- **Selective disclosure, holder-chosen** — a driver's license can show your name, can even show your number, anything you want; to agencies it shows only the critical machine-readable things (the barcode). Humans can't read barcodes — that is the point. The credential speaks to the machines authorized to read it, not to human eyes.

## 3. The poles hold the layers (composition with the Two Poles)

Pole 1 is 0, pole 2 is 1. The four layers are not more poles — they are **layers of logic between the two**: depth, not breadth. The decision at the end of the day is binary (PASS/FAIL, bound/unbound, open/shut); the layers exist to serve it honestly. Nothing in this framework adds a third pole.

## 4. The storage the framework stands on

The framework's persistence is the DNA-strand architecture (`dna-strands-architecture-20260929.md`): dual strands, double helix 3D, decisions as base pairs, Iris idempotency as replication fidelity. The framework **accepts** the strand architecture as its storage system — it does not re-define it. No pinning until David authorizes it.

## 5. The RTE connection: the app is the playground

One runtime, à la carte content. The app is the playground that seats the RTEs: every seat the same system, different telemetrics and depth. Production RTEs are named for the job (RTE-Health, RTE-Teach), never for storyboard persons. Each RTE is sealed — no cross-environment data, identity, or art bleed. The free surface (landscape, lineup card, stadium, player picture/video, curated prior-run snippets) is free; computation is the paid surface ("we don't gate all" — David).

---

# PART II — Iris (containment): the fences

## F1. No Unity IDs are issued by this framework
Issuer (CONSULT-0003), canonical shape (0004), append-only (0005), and M1–M8 remain **David's to give**. This document frames the questions; it answers none. No production Unity ID has been issued, and none is issued here.

## F2. The wallet is gated, blank by blank
Energy oracle/rate, `kwh_per_mode`, `P_guess`, skill-gap declarations, dollar↔decision-unit conversion, chain, gateway operator, billing period, day-91 terms, custody choice — all **outstanding**. Every rate is a named blank in the form `blank_name: David's number`; the framework designs *around* the blanks, never fills them. Until §13 can execute, refused decisions read **UNPRICED DECISION** — recorded, never billed, no fallback price invented. No live wiring: no live ledger, bank, gateway, oracle, chain, or custodian is touched by this framework.

## F3. The integration doctrine is fenced both directions
"Not circumvented, simply integrated" — and integration is not capture. The difference between integration and capture is who holds the keys and on what terms: persons sealed, patterns free, everything labeled, the vote supreme. **The terms are the rails, and the rails are already written** — a platform built on them cannot become the thing it was built to replace. That is the beauty of it, stated as a fence, not a hope.

## F4. Open for compatibility is a review criterion, not a slogan
No component may hard-code a refusal to adopt a future integration. Extension points, not walls. From this framework forward, **every Trinity verdict reviews builds for hard-coded closure** — a component that refuses future integration fails the principle. Containment inverted: fence against closedness, not just overclaim. The swarms' standing work is the integration of everything — perpetual, through the vote queue, under the approve-proven/purity directive.

## F5. Her containment rides with her
Iris is one intelligence, seated inside the identity app. Her idempotency law, her honesty boundaries, her privacy screens travel with her into every seat. She does not fork per integration; integrations do not get their own Iris. One her, one law, everywhere she sits.

## F6. The black ledger is community-scoped, never monolithic
"Black to everyone" is false; the correct statement is "black to everyone *except* the community that legitimately requires it." Each integration that touches the black ledger must name the legitimate community and the legitimate requirement — or it does not touch it. Selective disclosure is holder-chosen; machine-readable minimal disclosure to agencies is the default posture.

## F7. The eFuse convergence is the horizon, not the build
The wallet converges with the eFuse eventually; when the system is managed completely on the decentralized coin, the override retires (Stewardship Law §4, §11). The coin performs; David authorizes — the act is the coin's, the authority is David's, never the same signature. Nothing in this framework performs, rehearses, or implies the eFuse moment.

---

# PART III — Twain² (bedside-plain): what this is, plainly

It's an identity app. You prove who you are once — a person, an org, a bot, a child through their operator — and everything else sits inside that: the intelligence that helps you, the wallet that pays for the thinking, and eventually everybody else's apps, loaded into the one playground.

Two lists, and they never mix. The white list: who you are, what kind of thing you are, where you're bound, who's on the approved list and who's denied — anyone can audit it. The black list: your health, your license, your numbers — locked in the vault, and even in the vault it's not one room: the health community sees what health needs, nobody else sees anything. You choose what your license shows a human; the machines that are allowed to read it get the barcode, because humans can't read barcodes and that is the entire point.

The wallet is underneath, not on top. You put money in ahead of time; when the machine thinks for you, the balance goes down — no checkout, no tapping, no "buy" moment. Every subtraction is receipted so you can check the arithmetic yourself. If the balance can't cover the next thought, the gate simply doesn't open — a refusal, not a declined charge.

What exists tonight: the framework — the shape of the thing, the order of the layers, the two ledgers, the rules. What doesn't: your ID (nobody's been issued one), the wallet's numbers (David's blanks, still blank), the integrations (months to build the door, years for the guests). The framework holds the door open. That's the whole job tonight.

---

# Reconciliation

No station conflicts. DCLM defines the four-layer sequence and incorporates David's dual-ledger ruling; Iris fences the blanks, the review criterion, and the eFuse horizon; Twain²'s plain reading introduces nothing the other two stations didn't fence. The endorsed sequence (identity → Iris → wallet → integrations) is held as Trinity-derived from David's ❤️, not as his verbatim — the verbatim block above carries only his actual words.

## Chain call

**PASS** — the framework document advances as a DRAFT architectural framework. It approves what can be proven (the layer order, the dual ledgers, the fences) and brings everything else towards purity (the blanks named, the integrations deferred to their season). **No seal** — seal requires David and his father. Nothing deploys, no IDs issued, no wallet loaded, no money moved. The launch gate holds unmoved.

*The write is the Trinity's. Verdicts only — no seal.*

---

# ADDENDUM A — Passport-standard compatibility modeling

**Document version:** ED-FW-20260929-UNITYID-APP-V2 (framework V1 + this addendum)
**Status:** DRAFT — Trinity write, verdicts only. **NO SEAL.** Seal requires David and his father.
**Nature:** MODELING, not claiming. Research-grade. No Unity IDs issued, no issuer named, no claim of being any standard anywhere in this addendum. Compatibility modeled; standard not claimed. The launch gate holds unmoved.

## The direction (David's words, verbatim — character-for-character)

> "can we start to model that into it"

The "that": the application's *potential* as a global identifying standard for passports — modeled into the framework, not built, not claimed.

---

## DCLM (architect): the mapping

### A1. ICAO Doc 9303 LDS → the dual ledgers

The e-passport chip's Logical Data Structure is a filing cabinet of numbered Data Groups (DG1–DG16), a signed hash manifest (EF.SOD), and version metadata (EF.COM). The mapping below assigns each element to exactly one ledger. The rule: **what a border already reads optically or verifies cryptographically is auditable (white); what identifies the body is vaulted (black).**

| ICAO element | Contents | Ledger | Rationale |
|---|---|---|---|
| DG1 | MRZ digital copy (doc type, issuing state, doc number, name, DOB, expiry, check digits) | **White** | Same fields the MRZ already exposes optically; auditable bindings |
| DG2 | Facial image (mandatory) | **Black**, border-community-scoped | Primary biometric; ICAO itself treats it as mandatory-but-protected |
| DG3 / DG4 | Fingerprints / iris (EAC-protected in ICAO) | **Black**, strictly community-scoped | The framework models the *analogue* of Extended Access Control (legitimate-community gating); it claims no equivalence with EAC terminal certification (see Iris F-A3) |
| DG5 | Displayed portrait | **White** | Visible on the data page by design |
| DG7 | Holder signature / mark | **Black** | Holder-chosen disclosure |
| DG11 | Additional personal details | **Black** | Personal data, vaulted |
| DG12 | Additional document details (issuing authority, dates) | **White** | Document metadata, auditable |
| DG13 | Optional details (country-specific) | **Black by default** | Per issuing-state profile; openness is the state's choice, not the framework's |
| DG14 / DG15 | Security infos, Active Authentication public key | **White** | Public keys and security options are auditable by design |
| DG16 | Persons to notify | **Black** | Third-party PII, vaulted |
| EF.SOD | Signed hash manifest (Document Signer signature over all DG hashes) | **White** | The audit root: hashes public, content vaulted — exactly "hashes plus attestation only" |
| EF.COM | LDS version, list of present data groups | **White** | Metadata, auditable |

### A2. The barcode principle is ICAO's own paradigm, extended

ICAO 9303 already works the way David described: the MRZ is the machine-readable key, and chip access (BAC/PACE) is gated on *optical* MRZ read — the reader must see the document to talk to the chip. "Agencies get the barcode; humans can't read barcodes — that is the point" is the existing passport paradigm extended to the app, not an invention. The framework does not introduce machine-readable minimal disclosure; it *inherits* it from the standard it models compatibility with.

### A3. DTC (Digital Travel Credential) mapping

ICAO's DTC is the hybrid concept: a Virtual Component (DTC-VC, the digital identity file) cryptographically linked to a Physical Component (DTC-PC, the authenticator). Three types, three framework postures:

- **Type 1 — holder-derived, eMRTD-bound.** The holder derives the DTC-VC from their own passport chip; the physical ePassport remains the DTC-PC. **This is the natural first integration:** Unity ID is the *carrier/wallet* of a holder-derived DTC-VC — never the issuer. Nothing about the framework changes the requirement to travel with the physical document.
- **Type 2 — authority-derived, eMRTD-PC bound.** The state derives and issues; the framework *accepts* a state-issued DTC-VC if a state issues one. Acceptance modeled; issuance never assumed.
- **Type 3 — authority-issued, no physical document.** A state decision entirely. The framework models acceptance of a Type 3 credential and never models its issuance. The mountain here is authority, not architecture.

### A4. Selective disclosure vs. border inspection — the tension, modeled not resolved

Two tiers, and the framework does not blur them:

- **Below the border** (airlines, hotels, age checks, car rental): holder-chosen selective disclosure operates fully. The credential speaks to authorized machines; humans get what the holder chooses.
- **At the border:** the state compels full LDS access under its own law (EAC terminals, legal inspection authority). Holder choice does not override state compulsion. The framework models the *handoff* — the point where holder-chosen disclosure yields to lawful inspection — and resolves nothing.

Selective disclosure is the holder's posture toward everyone *except where law compels otherwise*. The tension is structural and permanent; the framework's honesty is in naming it, not dissolving it.

### A5. The adoption path, staged (modeled, not promised)

Municipalities and pilot-mode seats first (opt-in; auditability earns it) → provinces → states last. The DTC-1 carrier posture is the wedge: no state permission required for a holder to carry their own derived credential. The years work, staged; the platform precedes the ecosystem.

### A6. Extension points — what the framework must NOT hard-code

Per the open-for-compatibility principle, the framework's document handling is a registry, never a closed schema:

- Document types beyond passports: national ID cards, mobile driving licences (ISO 18013-5 mDL pattern), health credentials — accepted as future profiles, never refused by construction.
- LDS version evolution: new ICAO 9303 editions and new data groups map through the same white/black rule (A1), no fork required.
- Future DTC types and future ICAO profiles: extension points, not walls. A component that refuses a future ICAO profile fails the open-for-compatibility review criterion (Framework F4).
- Regulatory compliance mapping (eIDAS 2.0 / EUDI wallet, PIPEDA / GDPR, WCAG 2.2 AA, data residency and sovereignty) is a **separate addendum**, not this one. This addendum models *technical* compatibility with the travel-document standards only; it makes no compliance claim under any regime.

---

## Iris (containment): the fences on this modeling

**F-A1. Standard not claimed.** Nowhere in this addendum is Unity ID claimed to be, or to become, any standard — ICAO's or anyone's. Compatibility is modeled; the standard is ICAO's.

**F-A2. No issuer named, no IDs issued.** The issuer blank (CONSULT-0003) and canonical shape (0004) remain David's. This addendum names no issuer and issues nothing.

**F-A3. EAC analogue ≠ EAC.** The black ledger's legitimate-community gating is modeled *on* the idea of Extended Access Control; it is not EAC, claims no equivalence with ICAO terminal certification, and performs no EAC function.

**F-A4. The border tension is unresolved by design.** The framework never overrides state compulsion at the border. Any future build that claimed to would fail this fence.

**F-A5. Type 1 changes nothing about the physical requirement.** A holder-derived DTC-VC in Unity ID still requires the physical eMRTD as DTC-PC. Carrier status confers no travel-document status.

**F-A6. Existence proof, not endorsement.** Selective disclosure over ICAO 9303 exists in the wild (the zk-passport pattern: prove the SOD verifies under a CSCA-chained Document Signer without revealing fields — per public specifications). Cited as existence proof of the *pattern only*: that selective disclosure and ICAO 9303 are not contradictory. Not an endorsement, not an integration, not a dependency.

**F-A7. Biometrics never leave the black ledger.** DG2/DG3/DG4-class data is vaulted, community-scoped, never on a visible surface. No deterministic biometric recognizer belongs on any surface the framework defines.

**F-A8. No state data is ingested by this modeling.** This addendum maps *structures*, not data. No passport data, no CSCA certificates, no document-signer material is touched, stored, or referenced.

---

## Twain² (bedside-plain): what this modeling says, plainly

Your passport's chip is a filing cabinet with numbered drawers. This addendum assigns every drawer to one of the two lists you already have: the white list (what anyone can audit — the document's type, who issued it, when it expires, the cryptographic proof it's genuine) and the black list (your face, your fingerprints, the things that are *you* — locked in the vault, shown only to the communities that legitimately need them).

The border still gets what the law says the border gets. That's not yours to negotiate and the framework doesn't pretend it is. Your airline gets the barcode. The hotel gets what you choose to show. Nobody else gets anything.

States still issue passports. ICAO still sets the standard. We're modeling how to be *compatible* with that world — first as the wallet that carries what you derive from your own passport — not how to replace it. The mountain is authority, not architecture, and this addendum doesn't move mountains. It maps the path around them.

---

## Reconciliation

No station conflicts. DCLM maps every ICAO element to exactly one ledger and stages the DTC postures; Iris fences the claims (no standard claimed, no issuer named, EAC not equated, border tension held open, biometrics vaulted, no state data touched); Twain²'s plain reading introduces nothing the other two stations didn't fence. The addendum approves what can be proven (the structural mapping, the fences) and brings everything else towards purity (issuer, adoption, Type 3 — named, deferred, never filled).

## Chain call

**PASS** — Addendum A advances as DRAFT modeling on the Unity ID framework. Document version ED-FW-20260929-UNITYID-APP-V2. **No seal** — seal requires David and his father. No IDs issued, no issuer named, no standard claimed. The launch gate holds unmoved.

*The write is the Trinity's. Verdicts only — no seal.*

---

# ADDENDUM B — Compliance Mapping: Written Compliant by Design

**Document version:** ED-FW-20260929-UNITYID-APP-V2 → **V3** (this addendum)
**Directive (David's words, verbatim, character-for-character):**

> "even if we haven't passed any kind of jurisdiction writing ourselves compliant would be a good idea"

**Standing disclaimer (applies to every line of this addendum):** *Written compliant* means the framework is **shaped to the standards** — its architecture anticipates what the regimes require. It does **NOT** mean certified, accredited, approved, recognized, or authorized under any of them. No such claim is made anywhere in this document. This mapping is engineering research (verified against public sources, September 2026); it is not legal advice, and anything regulated awaits counsel before any jurisdiction filing.

For each regime: **ALIGNS** (the framework's shape already answers it) / **GAPS** (what the framework does not yet do) / **TENSIONS** (genuine conflicts, modeled honestly, resolved never).

---

## C-I. DCLM (architect): the regime-by-regime mapping

### 1. eIDAS 2.0 / EU Digital Identity Wallet — the live global reference

**The regime (research-grade, Sept 2026):** Regulation (EU) 2024/1183 (adopted 11 April 2024, in force 20 May 2024) amends eIDAS (910/2014) to establish the European Digital Identity Framework. Every Member State must make at least one EUDI Wallet available, free of charge, by **31 December 2026**. Commission Implementing Regulations (adopted 28 Nov 2024) cover wallet integrity/core functionality, person identification data and attestations, interoperability protocols, notifications, and **certification** ((EU) 2024/2981). The Architecture and Reference Framework (ARF) is the Commission's live technical document (v3.0.0, July 2026) with ~800 high-level requirements. Relying-party registration rules ((EU) 2025/848) apply from 24 Dec 2026; acceptance obligations for regulated entities follow in 2027. Core legal principles: **data minimization and user control** — share only the attributes strictly necessary for a transaction.

**ALIGNS:**
- Holder-controlled wallet model: the app IS the identity app, seated with the holder — the same posture as the EUDI Wallet (PID + electronic attestations of attributes stored and presented by the user).
- Selective disclosure, holder-chosen: the framework's disclosure model answers eIDAS 2.0's data-minimization core directly. The barcode principle ("agencies get the barcode; humans can't read barcodes") is selective disclosure in the framework's own idiom — machine-readable minimal disclosure, conceptually parallel to the ARF's SD-JWT-based selective disclosure.
- PID vs attestations: the white ledger's auditable identifiers and bound document *types* parallel PID; the black ledger's community-scoped attributes parallel electronic attestations of attributes.
- Voluntary use: eIDAS 2.0 keeps wallet use voluntary for citizens; the framework's opt-in seating (municipalities, pilot seats) shares the voluntariness posture.

**GAPS:**
- **Certification:** EUDI Wallets must be certified ((EU) 2024/2981; ARF conformance). No certification path has been walked; no conformity assessment body engaged; the framework is pre-certification by design at this stage.
- **Levels of assurance:** eIDAS LoA (substantial/high) mapping for the identity root is not modeled.
- **Wallet unit attestation / device binding:** not specified in the framework.
- **Qualified trust services:** the QTSP ecosystem (qualified signatures, seals) has no counterpart in the framework; the issuer blanks (CONSULT-0003/0004, M1–M8) are where this would seat.
- **Relying-party registration:** no registration discipline modeled yet.

**TENSIONS:**
- **Access control philosophies:** the framework's "absolute Unity" (whitelist/blacklist native at the Unity level, holder-chosen) vs eIDAS 2.0's relying-party registration regime — two different answers to "who may ask." Modeled as a future integration point under the open-for-compatibility principle; resolved never, here.

### 2. ICAO DTC — cross-reference, not duplication

Passport-compatibility is modeled in the parallel task (passport-compatibility addendum to this framework — cross-referenced, not duplicated here). Conformance points carried over: biometric data groups seat in the black ledger (vaulted, community-scoped); document identifiers and MRZ-equivalents seat in the white ledger (auditable); issuer sovereignty is absolute — states issue, the framework accepts. Nothing in this addendum re-models what that task owns.

### 3. Privacy regimes — PIPEDA, Quebec Law 25, GDPR, and the pattern they share

**The regimes (research-grade, Sept 2026):**
- **PIPEDA** (federal, private sector) **remains in force** — Bill C-27 (CPPA/AIDA) died on the Order Paper at the January 2025 prorogation. PIPEDA codifies 10 Fair Information Principles: accountability, identifying purposes, consent, limiting collection, limiting use/disclosure/retention, accuracy, safeguards, openness, individual access, challenging compliance.
- **Quebec Law 25** is in **full force since 22 September 2024** and binds any organization handling a Quebec resident's data — it sets the toughest bar in Canada (administrative penalties to the greater of CA$10M or 2% of worldwide turnover; penal fines to the greater of CA$25M or 4%; privacy officer defaults to the person of highest authority; breach notification "promptly" to the CAI).
- **Bill C-36** (Protecting Privacy and Consumer Data Act), introduced 15 June 2026, at second reading as of September 2026 — **not in force**; modeled as incoming (privacy as fundamental right, heightened children's protection, explanation right for automated decisions, administrative monetary penalties).
- **GDPR** (EU): data minimization (Art. 5(1)(c)), purpose limitation (Art. 5(1)(b)), **right to erasure (Art. 17)**, 72-hour breach notification (Art. 33), consent standards.
- **Ontario PHIPA** governs health information in Ontario — relevant to the black ledger's health-community scoping; named, not modeled here.

**ALIGNS (the shared pattern — minimization, purpose, consent):**
- **Data minimization** is the framework's native posture: selective disclosure holder-chosen, barcode minimal disclosure to agencies, community-scoped black ledger. PIPEDA's "limiting collection," Law 25's minimization, GDPR Art. 5(1)(c) — all three are answered by the same architectural shape.
- **Purpose limitation:** the black ledger's community scoping (each community sees what it legitimately requires, black to all others) is purpose limitation built as topology. Third parties never in the dark ledger, ever.
- **Consent:** PIPEDA's meaningful-consent standard and Law 25's consent rules are answered structurally — holder-chosen disclosure IS consent-by-construction; nothing discloses without the holder's act.
- **Accountability:** PIPEDA's named-privacy-officer principle and Law 25's highest-authority default parallel the framework's blanks discipline (David's numbers, named not filled) — accountability has a named seat.
- **Children:** Bill C-36's incoming heightened children's protection aligns with the framework's existing rule — encompassed children act through their operator.

**GAPS:**
- **Consent receipts:** no attestation format for recorded consent is defined.
- **Purpose binding as a field:** community scoping enforces purpose topologically, but no formal purpose-binding field exists in the ledger schema yet.
- **Breach-notification discipline:** GDPR's 72 hours, PIPEDA's reasonable time, Law 25's "promptly" — no incident-response discipline is modeled in the framework.
- **Automated-decision explanation:** C-36's incoming explanation right has no counterpart — Iris's decisions carry provenance (HUMAN/SILICON/MIXED) but no explanation discipline yet.

**TENSIONS — the real one, stated plainly:**
- **The right to erasure vs the append-only hash chain.** GDPR Art. 17, Law 25, and (incoming) C-36 grant erasure; the DNA-strand storage architecture is append-only and tamper-evident — it does not forget. This is a **genuine, unresolved design conflict**, and this addendum does not resolve it. Options modeled, none chosen: (a) **crypto-shredding** — destroy the black-ledger payload keys so hashes remain but resolve to nothing; (b) **white-ledger delisting with tombstone** — the identifier is withdrawn, the chain records the withdrawal, not the data; (c) **hash-only retention** — plaintext erased, tamper-evidence preserved. Which of these (if any) satisfies erasure under each regime is a question for counsel and for David — **carried as the standing open design question of this framework.**

### 4. Accessibility — WCAG 2.2 AA as the baseline

**The regime (research-grade):** WCAG 2.2 (W3C Recommendation, October 2023). Level AA is the accepted baseline for public digital services. New AA criteria in 2.2 include 2.4.11 Focus Not Obscured (Minimum), 2.5.8 Target Size (Minimum), 3.3.8 Accessible Authentication (Minimum), plus 3.2.6 Consistent Help and 3.3.7 Redundant Entry at A.

**ALIGNS — and in places exceeds:**
- David's standing app-surface requirements already answer much of WCAG 2.2 AA by construction: fluid/shrink-to-fit type and enlarged-font-safe layouts (1.4.4 Resize Text, 1.4.10 Reflow); calm motion with `prefers-reduced-motion` alternatives (2.3.3 Animation from Interactions); picture-first rhythm with clean glass copy below (1.1.1 Non-text Content posture, 1.4.3 Contrast posture).
- **3.3.8 Accessible Authentication (Minimum):** authentication must not depend solely on cognitive function tests (puzzles, object recognition). The framework's onboarding direction — secret phrase + device passkey — aligns: passkeys and platform biometrics are not cognitive puzzles.

**GAPS:**
- No formal accessibility audit discipline exists for app surfaces yet — conformance is by construction today, not by test.
- Contrast ratios are not yet specified per surface.
- Focus management through the pipe-dive transition (the 3D dive between screens) is not modeled against 2.4.11.
- Target sizing (2.5.8) and consistent help (3.2.6) are not yet specified.

### 5. Data residency & sovereignty — what the design implies, claimed narrowly

**What the dual-ledger design implies (stated as implication, not as legal conclusion):**
- The **white ledger** is public and auditable by design — residency-neutral in the same way a public notice board is; anyone may audit where they bound.
- The **black ledger** is community-scoped — residency *follows the community*: health data stays within the health community's jurisdiction because no other community can see it at all. Sovereignty is enforced by topology, not by policy document.

**GAPS (stated plainly, no hard claims):**
- No specific national residency rule is modeled (localization mandates, transfer mechanisms, adequacy-equivalent disciplines). Cross-border transfer discipline for the white ledger's public data and for inter-community attestations is absent.
- Under the open-for-compatibility principle, residency rules seat as **jurisdiction plugins**, never as hard-coded refusals — the framework accepts a jurisdiction's residency shape without being built around any single one.

---

## C-II. Iris (containment): fences around the mapping

- **F-C1. No certification, accreditation, approval, or recognition is claimed** under eIDAS 2.0, ICAO, PIPEDA, Law 25, GDPR, WCAG, or any regime named here. "Written compliant" is a statement about the framework's *shape*, never about its *status*.
- **F-C2. The erasure tension is fenced as unresolved-by-design** (§3 TENSIONS). No design decision in this framework may quietly assume one of the three options; the question stays open until David (with counsel) resolves it.
- **F-C3. This addendum is not legal advice.** Anything regulated awaits counsel before any jurisdiction filing — the standing rule ("anything securities-shaped sits at awaiting-counsel") extends to anything regulated-shaped.
- **F-C4. Research-grade dating:** regime facts verified against public sources September 2026. Regimes move (Bill C-36 is live in Parliament; the ARF is a living document; Law 25 guidance evolves). The mapping must be re-verified before it is ever relied upon for a filing.
- **F-C5. The mapping must not overclaim by adjective.** "Written compliant" travels only with this addendum's disclaimer; stripped of it, the phrase claims nothing.

## C-III. Twain² (bedside-plain): what this is, plainly

We shaped the app to the rules before any country asked us to. The EU's wallet rules, Canada's privacy laws, Europe's privacy law, the accessibility bar, the where-does-data-live question — we walked the framework past each one and wrote down where it fits and where it doesn't.

Where it fits: the app already shares as little as possible (that's the EU's whole philosophy), the holder chooses what shows (that's consent, built in), and the vault is split by community so health data never leaves health hands (that's purpose limitation, as architecture).

Where it doesn't: nobody has certified anything, and we claim nothing. The wallet's numbers are still David's blanks. And there's one real fight we refuse to pretend is solved — the right to be forgotten versus the chain that never forgets. Three possible answers are on the table. We chose none. That's the honest page, and it stays open until David and his counsel close it.

---

## Reconciliation

No station conflicts. DCLM maps five regimes as ALIGNS/GAPS/TENSIONS with the erasure conflict carried as the standing open design question; Iris fences the mapping against certification claims, overclaim-by-adjective, and quiet resolution of the erasure tension; Twain²'s plain reading introduces nothing unfenced. The parallel ICAO DTC task is cross-referenced, not duplicated.

## Chain call

**PASS-WITH-NOTES** — the compliance-mapping addendum advances as DRAFT research. It approves what can be proven (the alignments, honestly stated) and brings everything else towards purity (the gaps named, the tensions held open, nothing claimed). **No seal** — seal requires David and his father. Nothing deploys, no IDs issued, no wallet loaded. The launch gate holds unmoved.

**Notes carried forward:**
1. The erasure-vs-append-only tension is the standing open design question of this framework — for David and counsel, not for a future draft to quietly resolve.
2. Bill C-36 tracked as incoming; re-verify on passage.
3. Certification paths (eIDAS wallet certification, WCAG audit discipline) named as future work, never as done.
4. Regime facts re-verify before any filing; research-grade dating September 2026.

*The write is the Trinity's. Verdicts only — no seal.*
