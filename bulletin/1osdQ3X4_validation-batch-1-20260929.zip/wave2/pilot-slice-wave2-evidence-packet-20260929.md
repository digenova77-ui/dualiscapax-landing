# PILOT SLICE WAVE-2 EVIDENCE PACKET — ONTARIO x TRANSPORTATION x DERIVATIVES
Assembled: 2026-09-29T03:34:00Z | Cycle: pilot-slice-wave-2 | Mode: PILOT MODE (public/modeled figures only)
Matrix: Batter Thirteen (Ontario x Transportation) leads Wave 2 per the roster matrix; derivatives: Public Transit, Roads & Highways, Freight & Logistics, Aviation, Active & Commute.

## Data-fill files (sha256, independently anchored)
- Q1 Public Transit: `data-fill/pilot/on-tr-transit.md` sha256:d7dfdc4a042bcf3224c74efb29d08680204d760df926882739b613a4d60cc83b
- Q2 Roads & Highways: `data-fill/pilot/on-tr-roads.md` sha256:99e8c510bbdb169f70c21b21d5470d718a7fa3d441b253d5033a2d51cf3ad8e5
- Q3 Freight & Logistics: `data-fill/pilot/on-tr-freight.md` sha256:96ebefc8306231359c078c4c76dcdd62a4800d20f219d983e855fce7bfe6556a
- Q4 Aviation: `data-fill/pilot/on-tr-aviation.md` sha256:28f055c9acd321d6dc7cbd5100722c6c64a37584d51eb085a38ce9b07098940f
- Q5 Active & Commute: `data-fill/pilot/on-tr-active.md` sha256:2293978bc61850c9dbe3ce9962f30d159b609e9e168b562b04f098d2ae4e5066

## Telemetry summary
- Q1: 21 steps, 90s VALID | Q2: 20 steps, 94s VALID | Q3: 16 steps, 67s VALID | Q4: 21 steps, 86s VALID | Q5: 29 steps, 179s VALID
- All five timestamps sane (started after task dispatch 03:30:52Z, ended before packet assembly); no forward-dating this wave.
- Valid subset throughput: 60 figures / 516s (0.1433 agent-hr) = ~419 figures/agent-hr
- Data-per-cycle: 60 figures (5 batters x 12) | Steps: 107 | Decision units: 93 | Anomalies: 14 | Rework: 0
- Telemetry blocks: all 15/15 fields, appended to factory-telemetry-log-20260929.jsonl, hashes recomputed OK.

## Ground truth anchors carried verbatim (from data-fill/on-trans.md, compiled 2026-09-28 EDT)
Ontario municipal transit trips 2022: 556.0M (FAO, 106 agencies); TTC 321.0M; Canada urban transit ~1.5B (2023) / ~1.6B (2024) StatCan narrow series; Ontario share 47.9% MODELED; TTC share 57.7% MODELED; scope warning: 1.8B 2023 broad series (agencies + intercity/school/charter) NOT interchangeable. Highway network 16,900 km (alternate 16,525 km flagged); 400-series 1,997.3 km. For-hire truck tonnage ON origin 2014: 228.6M tonnes (TCOD discontinued after 2014; excludes own-account). Pearson 2023: 43.7M enplaned+deplaned (StatCan); 2024: 46.8M (GTAA; projects ~65M early 2030s). Commute mode share May 2024: car/truck/van 80.5% · transit 13.5% · active 5.2% (LFS, ages 15–69); 2016: 77.9/14.7/6.5; 2021 census: 83.6/8.7/5.4 pandemic trough.

## Key findings by derivative (worker-reported, Trinity adjudication pending)
- Transit: GO+UP 71.8M FY2024-25 (Metrolinx); TTC budget $2.568B gross/$1.231B net; TTC recovery ~80.2% of 2019 MODELED; 108 agencies (106 municipal + 2 provincial); gas tax $380.2M to 148 municipalities; One Fare cost trajectory $10M→$121M→$128M (FAO); DENOMINATOR TRAP fenced (TTC 54.3% of 590.9M universe vs 57.7% of 556.0M universe); GO-rail-ONLY still UNKNOWN (bundled figures REPORTED, GO-only unknown).
- Roads: 699,289 new vehicle registrations 2024 (led provinces); Hwy 401 >400k vehicles/day (~20% commercial); 407 ETR: 108 km, ownership Cintra 48.29%/CPP 44.20%/PSP 7.51%, 2025 revenue $2.0085B; MTO $15.732B expense / $4.513B capital; 296 road fatalities by Oct 2024 (OPP, scope-pinned); 2,880 bridges (variant 2,993 filed); 124,911 BEVs 2024 (+49.2%); Hwy 413 procurement Sept 1, 2026, corridor 59 vs 52 km variants; Winter Roads $13M/yr, ~3,200 km, 32 First Nations.
- Freight: ~13,900 vacant truck-driver positions Canada Q1 2025 (Ontario ~6,100, vintage unpinned); 421,600 employed in ON transport & warehousing 2024 (+4.9%); CN 2,546 route miles ON / CP 3,782 first-main-track km (2006–08 vintage, only public cut); HOPA 11.46M tonnes FY2024 (ON's largest port); Seaway ~37M tonnes 2024 (federal); Ambassador Bridge 2,280,569 trucks (−11.1%) vs Blue Water 1,858,505 (+14.6%) — corridor net −1.2% MODELED (share shifted); Canada Post parcels −19.9% 2024 (federal); Toronto diesel 155.4¢/L Feb 2026 (high 225.9¢ May 2022).
- Aviation: Pearson recovery 92.7% MODELED (46.8/50.5M same-publisher GTAA); 389,600 movements 2024; ~500k tonnes cargo (~45% of Canada's); 5 runways, 1,861 ha; Billy Bishop 2.02M pax 2024; Ottawa 4.607M (90.2% of 2019 MODELED); Hamilton 324,336 pax (−60% YoY) + 754M kg cargo (definitions never mixed); Pickering: NO airport (Jan 2025 ministerial decision); Pearson employment 52,000+ / $19.6B GDP; ATC-attributable delays 0.04% summer 2026; 179 ON airports (CBC, custody-flagged); 29.3% of Canada's private aircraft (≈7,800 MODELED).
- Active & Commute: WFH 21.7% May 2024 (highest province); avg commute 29.0 min (longest province); 60+ min: Ontario 9.1% (2021 census) / Toronto CMA 15.7% (May 2024); Bike Share Toronto 6,953,094 trips 2024 (+22%, 10th record); e-scooter pilot O. Reg. 389/19 to Nov 2029; Toronto transit ran 19.2 min longer than car MODELED; current ORSAR ped/cyclist fatality counts UNKNOWN (tables unrenderable — declared, not filled); pedestrian benchmark 95 deaths (death review ~2012, dated).

## Draft-to-verdict clock
- START: 2026-09-29T03:34:00Z (packet assembled, all five handoffs verified + telemetry logged)
- END: (chain call issued) — verdict: PENDING Trinity routing
- The write is theirs. Nothing deploys without it.
