/* DualisCapax Unity Engine — boot (2a/2b)
 * Starts the shell: registry → integrity guard → ambience → mount → dive-in.
 * The integrity guard runs first and a failure stops everything: nothing
 * mounts, nothing displays unvalidated. The engine mounts one sealed
 * environment (pharmacology, the Trinity-called first mount) without
 * touching its copy.
 */

'use strict';

import { runIntegrity } from './integrity.js';
import { mountAmbience } from './ambience.js';
import { createSeat, mountSeat } from './seat.js';
import { diveIn, diveOut } from './motion.js';
import { mountSpatialLayer } from './plates.js';
import { createConduit } from './conduit.js';

export async function boot(options) {
  const { ambienceCanvas, mountHost, onStatus, onIntegrity } = options;

  /* The gate: every check must pass before the shell draws anything mounted. */
  const result = runIntegrity().catch(err => ({
    pass: false,
    checks: [{ id: 'gate', label: 'Integrity gate', status: 'fail', detail: String(err && err.message || err) }],
    failMessage: 'The engine did not boot. The integrity gate itself failed to run. Nothing was mounted. This is the honest-no.'
  }));
  const integrity = await result;
  if (typeof onIntegrity === 'function') onIntegrity(integrity);
  if (!integrity.pass) {
    if (typeof onStatus === 'function') onStatus('honest-no');
    return { ok: false, failMessage: integrity.failMessage, integrity };
  }

  /* Ambience: the one scene, drawn behind the DOM. */
  const ambience = mountAmbience(ambienceCanvas);
  if (typeof onStatus === 'function') onStatus('ambience');

  /* 2b — the spatial layer: the shell's constellation (one lit node + honest
   * empties) and the environment plates, drawn through the ExchangePacket
   * gate; then the conduit dolly driver for the dives. */
  const spatial = mountSpatialLayer(ambience);
  if (typeof onStatus === 'function') onStatus('spatial');
  createConduit(ambience);

  /* The seat: one sitter's chair onto the pharmacology environment.
   * PILOT is the default; exiting it is a future gated transition. */
  const seatResult = createSeat({
    id: 'proof-seat',
    environment: 'pharmacology',
    subscribedEnvironments: ['pharmacology'],
    scopingFilters: { grain: 'design-surface', feeds: 'public-modeled-only' },
    pilotPosture: 'PILOT · RESEARCH',
    p8: {
      fence: 'PUBLIC',
      consentArchitecture: 'no personal ingress on the instrument — no person-level input exists in 2a'
    }
  });
  if (!seatResult.ok) {
    if (typeof onStatus === 'function') onStatus('honest-no');
    return { ok: false, failMessage: 'The engine did not boot. ' + seatResult.error + '. This is the honest-no.', integrity };
  }

  const mount = mountSeat(seatResult.seat, mountHost);
  if (typeof onStatus === 'function') onStatus('mounted');
  await diveIn(mount.element);

  return {
    ok: true,
    integrity,
    ambience,
    spatial,
    mount,
    diveOut: () => diveOut(mount.element).then(() => mount.unmount()),
    diveInAgain: () => {
      const host = mountHost;
      host.appendChild(mount.element);
      return diveIn(mount.element);
    }
  };
}
