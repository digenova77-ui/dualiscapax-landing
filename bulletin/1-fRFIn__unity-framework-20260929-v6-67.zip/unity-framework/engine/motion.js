/* DualisCapax Unity Engine — transition choreography (2a/2b)
 * The pipe-dive: a fixed ~1s camera move. Calm, skippable, reduced-motion-safe.
 * Under prefers-reduced-motion the dive is a calm crossfade — correct behavior,
 * not fallback. Durations are fixed constants: the transition is a slot, not a variable.
 */

'use strict';

/* Fixed ~1s camera move — the dive duration is architecture, not tunable per call. */
export const DIVE_MS = 1000;
export const CROSSFADE_MS = 320;

/* 2b — the conduit's dolly driver. The conduit (conduit.js) registers its
 * driver here. When a driver is registered AND motion is allowed, dives run
 * as the 3D camera move. Reduced-motion keeps the calm crossfade (correct,
 * not fallback); with no driver the 2a CSS veil path stays. The CSS path is
 * never removed. */
let dollyDriver = null;
export function setDollyDriver(driver) { dollyDriver = driver; }
export function getDollyDriver() { return dollyDriver; }

export function isReducedMotion() {
  return typeof window !== 'undefined' &&
    window.matchMedia &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

/* Ensure the one-time transition stylesheet exists (no reliance on shell CSS). */
function ensureStyles() {
  if (document.getElementById('engine-motion-styles')) return;
  const s = document.createElement('style');
  s.id = 'engine-motion-styles';
  s.textContent =
    '.eg-dive-veil{position:fixed;inset:0;z-index:90;pointer-events:none;opacity:0;' +
    'background:radial-gradient(ellipse at 50% 60%,rgba(0,245,212,.28),rgba(4,6,11,.96) 74%);' +
    'transition:opacity .45s ease;}' +
    '.eg-dive-veil.on{opacity:1;pointer-events:all;}' +
    '.eg-dive-in{animation:egDiveIn ' + DIVE_MS + 'ms cubic-bezier(.2,.7,.2,1) both;}' +
    '@keyframes egDiveIn{from{opacity:0;transform:scale(.965) translateY(18px)}' +
    'to{opacity:1;transform:none}}' +
    '.eg-crossfade{transition:opacity ' + CROSSFADE_MS + 'ms ease;}' +
    '@media (prefers-reduced-motion: reduce){' +
    '.eg-dive-in{animation:none;}' +
    '.eg-dive-veil{display:none;}}';
  document.head.appendChild(s);
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/* Dive INTO an element: the view travels forward through the veil into it.
 * 2b: with a registered dolly driver and motion allowed, the dive is the
 * conduit's ~1s camera move instead of the CSS veil. */
export function diveIn(el) {
  ensureStyles();
  if (!el) return Promise.resolve();
  if (isReducedMotion()) {
    /* Calm crossfade — static plates and calm fades are the correct 2a behavior. */
    el.classList.add('eg-crossfade');
    el.style.opacity = '0';
    requestAnimationFrame(() => requestAnimationFrame(() => { el.style.opacity = '1'; }));
    return wait(CROSSFADE_MS).then(() => { el.classList.remove('eg-crossfade'); el.style.opacity = ''; });
  }
  if (dollyDriver) return dollyDriver.dollyIn();
  const veil = document.createElement('div');
  veil.className = 'eg-dive-veil';
  veil.setAttribute('aria-hidden', 'true');
  document.body.appendChild(veil);
  void veil.offsetWidth;
  veil.classList.add('on');
  return wait(450).then(() => {
    el.classList.remove('eg-dive-in');
    void el.offsetWidth;
    el.classList.add('eg-dive-in');
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    veil.classList.remove('on');
    return wait(500);
  }).then(() => veil.remove());
}

/* Dive OUT of an element: the view lifts back out to the shell.
 * 2b: with a registered dolly driver and motion allowed, the dive-out is the
 * conduit's recede instead of the CSS veil. */
export function diveOut(el) {
  ensureStyles();
  if (!el) return Promise.resolve();
  if (isReducedMotion()) {
    el.classList.add('eg-crossfade');
    return wait(CROSSFADE_MS).then(() => el.classList.remove('eg-crossfade'));
  }
  if (dollyDriver) return dollyDriver.dollyOut();
  const veil = document.createElement('div');
  veil.className = 'eg-dive-veil';
  veil.setAttribute('aria-hidden', 'true');
  document.body.appendChild(veil);
  void veil.offsetWidth;
  veil.classList.add('on');
  return wait(450).then(() => {
    el.classList.remove('eg-dive-in');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    veil.classList.remove('on');
    return wait(500);
  }).then(() => veil.remove());
}
