#!/usr/bin/env python3
"""Audit Ledger builder: writes audit.jsonl (append-only canonical record),
copies a byte-identical bundled snapshot to assets/, and generates the
DIVINE audit page from the canonical record. Re-run after appending."""
import json, html, shutil
from pathlib import Path

ROOT = Path.home() / "workspace" / "audit-ledger"
LEDGER = ROOT / "audit.jsonl"
SNAP = ROOT / "assets" / "audit.jsonl"
PAGE = ROOT / "audit-ledger.html"

P = ("Three-umpire rotation (DCLM / Iris / Twain2), three separate passes, run by "
     "the builder swarm; verdicts reported in the build transcript of 2026-09-28; "
     "backfilled into this ledger by the audit-ledger builder. Only what the "
     "transcript reported is recorded here.")

def r(rid, name, date, artifact, dclm, iris, twain2, overall, ncond,
      conditions, repairs, disposition, note, handed, needs_review, notes,
      verification="transcript-reported"):
    return {
        "record_id": rid, "schema": "audit-ledger/1.0",
        "build_name": name, "date": date, "artifact_path": artifact,
        "gate": {"dclm": dclm, "iris": iris, "twain2": twain2, "overall": overall},
        "conditions_count": ncond, "conditions": conditions,
        "repairs_summary": repairs, "disposition": disposition,
        "disposition_note": note, "handed_to_bulletin_board": handed,
        "provenance": P, "verification": verification,
        "needs_review": needs_review, "notes": notes,
    }

RECORDS = [
 r("AUDIT-20260928-001", "RTE-Teach deep page", "2026-09-28",
   "~/workspace/your_files/rte-teach/rte-teach.html",
   "SOUND", "SOUND", "SOUND", "3-0 SOUND", 0, [],
   "No repairs needed.", "WRITTEN", "Draft. Gated, not handed to the bulletin board.",
   False, False, "Built weakest-to-strongest; nothing left behind."),
 r("AUDIT-20260928-002", "RTE-Ice deep page", "2026-09-28",
   "~/workspace/rte-ice/rte-ice-source.html",
   "SOUND", "SOUND", "SOUND", "3-0 SOUND", 0, [],
   "No repairs needed.", "WRITTEN", "Draft. Gated, not handed to the bulletin board.",
   False, False, "Next DIVINE surface after Teach."),
 r("AUDIT-20260928-003", "RTE-Golf deep page", "2026-09-28",
   "~/workspace/rte-golf/rte-golf-source.html",
   "unrecorded", "unrecorded", "unrecorded", "PROCEED AS DRAFT", 0, [],
   "unrecorded", "WRITTEN", "Draft. Independent umpire rotation verdict: PROCEED AS DRAFT.",
   False, True, "Built from zero with DB-backed hooks. Individual umpire votes and any conditions were not recorded in the transcript."),
 r("AUDIT-20260928-004", "Hockey data scour (GameSheet/OMHA/OHF/social via IRIS contract)", "2026-09-28",
   "~/workspace/data/registry/hockey.jsonl",
   "unrecorded", "unrecorded", "unrecorded", "unrecorded", 0, [],
   "unrecorded", "NOT-WRITTEN", "No gate was run. Completed working material: 5 records, 23 entities. Deliberately excluded from the suite (named minors).",
   False, True, "Scour completed; gating never recorded."),
 r("AUDIT-20260928-005", "RTE-Hospitality deep page", "2026-09-28",
   "~/workspace/ts-spaces/rte-hospitality/index.html",
   "SOUND", "SOUND", "SOUND", "3-0 SOUND", 0, [],
   "No repairs needed.", "WRITTEN", "Draft. Gated, not handed to the bulletin board.",
   False, False, "Built from zero; independent rotation."),
 r("AUDIT-20260928-006", "RTE-Ice onto the real website + database-backed data architecture", "2026-09-28",
   "~/workspace/ts-spaces/rte-ice/",
   "unrecorded", "unrecorded", "unrecorded", "4-0 SOUND", 0, [],
   "Corrections confirmed.", "WRITTEN", "Applied to the live site working copy.",
   False, True, "Transcript records a 4-0 SOUND verdict with corrections confirmed; the composition of the four votes was not recorded."),
 r("AUDIT-20260928-007", "RTE-Financials deep page", "2026-09-28",
   "~/workspace/ts-spaces/rte-financials/index.html",
   "unrecorded", "unrecorded", "unrecorded", "CONDITIONAL x3", 3, [],
   "All reported conditions repaired and verified.", "REPAIRED-AND-WRITTEN",
   "Draft. Independent rotation; repairs verified.",
   False, True, "Condition details were not recorded in the transcript; count only."),
 r("AUDIT-20260928-008", "Main landing page + derivatives: DIVINE treatment (pre-RTE working copy)", "2026-09-28",
   "~/workspace/ts-spaces/dualiscapax-mobile-site/",
   "SOUND", "SOUND", "SOUND", "3-0 SOUND", 0, [],
   "No repairs needed.", "WRITTEN", "Applied to the working copy. Exactly one append-only CSS block; no HTML, JS, or copy changed. Frozen pages otherwise untouched.",
   False, False, "Landing constellation, Fractals 01-06, RTE Desk, Canada derivatives, Doctrine."),
 r("AUDIT-20260928-009", "RTE Core basic hub (six room docks)", "2026-09-28",
   "~/workspace/your_files/rte-core/rte-core.html",
   "SOUND", "CONDITIONAL", "SOUND", "CONDITIONAL x1", 1,
   [{"id": "C1", "raised_by": "Iris",
     "finding": "Canonical registry/snapshot freshness must remain authoritative; the page is not a live file-existence check.",
     "repair": "Recorded as a standing condition: the registry is the freshness authority.",
     "repair_verified": "unrecorded"}],
   "Standing condition recorded.", "WRITTEN", "Draft. Six docks source-confirmed and sealed from one another; Unity ID hook reserved, no ID issued.",
   False, True, "Whether the Iris condition was closed or stands open was not recorded in the transcript."),
 r("AUDIT-20260928-010", "RTE Suite deployable site (six rooms)", "2026-09-28",
   "~/workspace/rte-suite-20260928.zip",
   "CONDITIONAL", "CONDITIONAL", "CONDITIONAL", "CONDITIONAL x3", 3, [],
   "All reported conditions repaired and statically reverified. No P0 findings.",
   "REPAIRED-AND-WRITTEN", "Handed to FACTORY_BULLETIN_BOARD on 2026-09-28. Health: Approved, published, living. Other five: Draft, published, living.",
   True, True, "Condition details were not recorded in the transcript; count and repair status only. Staging: ~/workspace/rte-suite-build/."),
 r("AUDIT-20260928-011", "Universal Binding Rite", "2026-09-28",
   "~/workspace/binding-rite/binding-rite-source.html",
   "unrecorded", "unrecorded", "unrecorded", "CONDITIONAL x3", 3, [],
   "All reported conditions repaired.", "REPAIRED-AND-WRITTEN",
   "Draft. Real five-state machine (IDLE/INVOKED/BOUND/MONITORING/RELEASED); every source MOCK-labeled; registry empty, honest 0:1.",
   False, True, "Individual umpire votes and condition details were not recorded in the transcript."),
 r("AUDIT-20260928-012", "Dark Ledger spec v0", "2026-09-28",
   "~/workspace/research_notes/dark-ledger/spec-v0.md",
   "unrecorded", "unrecorded", "unrecorded", "unrecorded", 0, [],
   "unrecorded", "NOT-WRITTEN", "Spec only; no build, no gate. Build held for the founder's twelve open questions.",
   False, False, "Settled constraints, proposed mechanics, twelve questions only the founder can close."),
 r("AUDIT-20260928-013", "Hospitality/Golf repair pass (umpire P1 repairs)", "2026-09-28",
   "~/workspace/rte-suite-build/ + ~/workspace/ts-spaces/rte-hospitality/",
   "unrecorded", "unrecorded", "unrecorded", "unrecorded", 0, [],
   "Hospitality now fetches assets/hospitality.jsonl matching the empty canonical registry; 0:1 legend added. Verification labels already correct; golf hydration already correct.",
   "WRITTEN", "Repairs applied to the shipped suite and the ts-spaces hospitality page.",
   False, True, "Repair pass following the umpire; no gate verdict was recorded for the pass itself."),
 r("AUDIT-20260928-014", "Healthcare integration draft (taxpayer-facing, Canada-first)", "2026-09-28",
   "~/workspace/healthcare-taxpayer/rte-healthcare-taxpayer.html",
   "CONDITIONAL", "SOUND", "CONDITIONAL", "CONDITIONAL x2", 2,
   [{"id": "C1", "raised_by": "DCLM", "finding": "unrecorded in transcript", "repair": "Repaired.", "repair_verified": True},
    {"id": "C2", "raised_by": "Twain2", "finding": "Eight repairs required (details unrecorded in transcript).", "repair": "All eight repaired.", "repair_verified": True}],
   "DCLM condition repaired; Twain2 eight repairs completed.", "REPAIRED-AND-WRITTEN",
   "Draft. Framing: 'For the people who pay.' Not wired to the Dark Ledger.",
   False, True, "Condition details were not recorded in the transcript; counts and repair status only."),
 r("AUDIT-20260928-015", "Email invocation interface (first passenger of the Binding Rite)", "2026-09-28",
   "~/workspace/email-invocation/email-invocation-source.html",
   "unrecorded", "unrecorded", "unrecorded", "CONDITIONAL x12", 12, [],
   "All reported conditions repaired.", "REPAIRED-AND-WRITTEN",
   "Draft. Real guarded five-state machine; MOCK mailboxes and readings; declared-permission authority only.",
   False, True, "Individual umpire votes and condition details were not recorded in the transcript."),
 r("AUDIT-20260928-016", "School-admin identifier adaptation (IRIS pipeline)", "2026-09-28",
   "~/workspace/user/identifiers/school.admin.titles.json",
   "unrecorded", "unrecorded", "unrecorded", "unrecorded", 0, [],
   "unrecorded", "NOT-WRITTEN", "Spec only; no build, no gate. Extractor code untouched. Five open questions for the founder; Teach stays unwired until he says his output is ready.",
   False, False, "Patterns: Principal, Vice-Principal, Superintendent, Director of Education, Trustee."),
 r("AUDIT-20260928-017", "Suite staging integrity audit", "2026-09-28",
   "~/workspace/rte-suite-build/",
   "unrecorded", "unrecorded", "unrecorded", "PASS (audit, not a gate)", 0, [],
   "No repairs needed.", "WRITTEN", "Integrity audit completed: hub-to-room links resolve, registry snapshots byte-identical, no dead references, state labels agree.",
   False, False, "An audit, not a three-umpire gate. IA observation left for the founder: only Health links back to the hub."),
 r("AUDIT-20260928-018", "Founder board concept (double helix cosmos)", "2026-09-28",
   "~/workspace/founder-board/founder-board-source.html",
   "unrecorded", "unrecorded", "unrecorded", "CONDITIONAL x8", 8, [],
   "All reported conditions repaired.", "REPAIRED-AND-WRITTEN",
   "Draft. Concept only; not for the bulletin board. Name-free surface; two honest 0:1 slots.",
   False, True, "Individual umpire votes and condition details were not recorded in the transcript."),
 r("AUDIT-20260928-019", "DIVINE design concept doc: new patterns (section 13)", "2026-09-28",
   "~/workspace/your_files/divine-design-concept-2026-09-27.md",
   "unrecorded", "unrecorded", "unrecorded", "unrecorded", 0, [],
   "unrecorded", "NOT-WRITTEN", "Documentation update; no gate was run.",
   False, True, "Patterns recorded: module docks, rite movements, container doctrine, 0:1 taxonomy, the seal, taxpayer frame, name-free surfaces."),
 r("AUDIT-20260928-020", "Education taxpayer draft (For the people who pay: schools)", "2026-09-28",
   "~/workspace/education-taxpayer/rte-education-taxpayer.html",
   "SOUND", "SOUND", "CONDITIONAL", "CONDITIONAL x2", 2,
   [{"id": "C1", "raised_by": "Twain2", "finding": "'banked' leaked into viewer copy (4 hits).", "repair": "Replaced with plain words ('calculated from the figures above', 'the September 2026 Ontario data').", "repair_verified": True},
    {"id": "C2", "raised_by": "Twain2", "finding": "Failure banners spoke registry jargon.", "repair": "Rewritten in citizen words ('The figures could not be verified right now').", "repair_verified": True}],
   "Both Twain2 conditions repaired.", "REPAIRED-AND-WRITTEN",
   "Draft. Six derived figures exact on banked inputs. Not wired to the Dark Ledger.",
   False, False, "DCLM and Iris: SOUND, no conditions."),
 r("AUDIT-20260928-021", "Canada municipal drill-down exploration", "2026-09-28",
   "~/workspace/canada-drilldown/canada-drilldown-source.html",
   "unrecorded", "unrecorded", "unrecorded", "CONDITIONAL x13", 13, [],
   "All reported conditions repaired and statically re-verified.", "REPAIRED-AND-WRITTEN",
   "Draft. Traversal mechanism real; municipal readings MOCK-labeled; honest 0:1 spine throughout.",
   False, True, "Individual umpire votes and condition details were not recorded in the transcript. Notable repair: Tweed's official type corrected to Municipality."),
 r("AUDIT-20260928-022", "Access tab deep page shell ($0 90-day modeling seat)", "2026-09-28",
   "~/workspace/access-seat/access-seat-source.html",
   "CONDITIONAL", "SOUND", "CONDITIONAL", "CONDITIONAL x13", 13,
   [{"id": "DCLM-C1..C5", "raised_by": "DCLM", "finding": "Five conditions (details unrecorded in transcript).", "repair": "All five repaired, incl. downgrading registry text_match overclaims to paraphrase with review_required.", "repair_verified": True},
    {"id": "Twain2-C1..C8", "raised_by": "Twain2", "finding": "Eight conditions; six repaired, two declined with rationale (kept the settled 0:1 taxonomy and the 'Draft - not landed' seal formula for cross-build consistency).", "repair": "Six repaired; two declined with written rationale.", "repair_verified": True}],
   "DCLM x5 repaired; Twain2 x8: six repaired, two declined with rationale.", "REPAIRED-AND-WRITTEN",
   "Draft. Five onboard steps as named reserved slots; zero credential collection.",
   False, True, "Condition details were not recorded in the transcript."),
]

PENDING = [
 r("AUDIT-20260928-023", "Whole-site assembly (hub + six rooms + all drafts)", "2026-09-28",
   "~/workspace/whole-site-build/",
   "unrecorded", "unrecorded", "unrecorded", "unrecorded", 0, [],
   "unrecorded", "PENDING", "Build in flight. Gate not yet run; a record will be appended when the verdict lands.",
   False, True, "Includes the Trinity consultation mechanism (~/workspace/trinity-consultation/).",
   verification="pending"),
 r("AUDIT-20260928-024", "Unity Framework website (the clonable framework as a site)", "2026-09-28",
   "~/workspace/unity-framework/",
   "unrecorded", "unrecorded", "unrecorded", "unrecorded", 0, [],
   "unrecorded", "PENDING", "Build in flight. Gate not yet run; a record will be appended when the verdict lands.",
   False, True, "Includes a live clone demonstration: one new RTE room built purely from the template.",
   verification="pending"),
 r("AUDIT-20260928-025", "Trinity consultation mechanism", "2026-09-28",
   "~/workspace/trinity-consultation/",
   "unrecorded", "unrecorded", "unrecorded", "unrecorded", 0, [],
   "unrecorded", "PENDING", "Build in flight as part of the whole-site assembly. Gate not yet run.",
   False, True, "Protocol + log + first consultations over the banked open questions.",
   verification="pending"),
]

ALL = RECORDS + PENDING

# Append-only guard: the backfilled spine (records 001-025) is frozen. New
# records are appended in APPENDIX only. build.py refuses to regenerate if any
# frozen record_id's content hash changed.
FROZEN_IDS = [rec["record_id"] for rec in ALL]
FROZEN_HASH = __import__("hashlib").sha256(
    "".join(json.dumps(rec, ensure_ascii=False, sort_keys=True) for rec in ALL).encode()
).hexdigest()

APPENDIX = [
 r("AUDIT-20260928-026", "Whole-site assembly gate (hub + six rooms + seven wings)", "2026-09-28",
   "~/workspace/whole-site-20260928.zip",
   "SOUND", "SOUND", "SOUND", "SOUND (DCLM CONDITIONAL x7, all repaired)", 7, [],
   "All seven DCLM conditions repaired by the writer's hands and re-verified by an independent pass. Arithmetic spine exact; all 10 bundled snapshots byte-identical to canonical registries; no cross-room bleed; no personal names on production surfaces.",
   "REPAIRED-AND-WRITTEN", "Supersedes the PENDING record AUDIT-20260928-023. 14 pages, 48 files. Handed to FACTORY_BULLETIN_BOARD on 2026-09-28 under execution statement E3 (a clean gate-verdict carries the seal).",
   True, True, "Condition details not enumerated in the build receipt; count and repair status only. Standing limitation recorded: no live browser render, code-verified only.",
   verification="build-receipt + parent record"),
 r("AUDIT-20260928-027", "Trinity consultation mechanism: protocol + 32 consultations", "2026-09-28",
   "~/workspace/trinity-consultation/consultations.jsonl",
   "unrecorded", "unrecorded", "unrecorded", "unrecorded", 0, [],
   "unrecorded", "WRITTEN", "Supersedes the PENDING record AUDIT-20260928-025. Mechanism live: protocol + audit-logged consultations, 32 executed (16 DEFER-TO-DAVID / 14 IMPLEMENT / 2 REASSESS).",
   False, True, "No separate three-umpire gate was recorded for the mechanism itself; the consultations are themselves Trinity execution statements. Key statements: E3 (clean gate-verdict carries the seal, incl. to the bulletin board), D1 (gate-verdict seal formula replaced the personal-word formula site-wide), G3 (assemble, then judge, then ship).",
   verification="consultations.jsonl (32 records) + parent record"),
 r("AUDIT-20260928-028", "CORRECTION to AUDIT-20260928-003 (RTE-Golf deep page votes)", "2026-09-28",
   "~/workspace/rte-golf/rte-golf-source.html",
   "CONDITIONAL", "SOUND", "CONDITIONAL", "PROCEED AS DRAFT", 0, [],
   "unrecorded", "WRITTEN", "Correction record. Supersedes AUDIT-20260928-003: the transcript reports DCLM CONDITIONAL / Iris SOUND / Twain2 CONDITIONAL, composite PROCEED AS DRAFT. The votes were wrongly marked unrecorded.",
   False, True, "Condition details genuinely unrecorded; count unknown. Issued per the append-only rule: the original record is untouched.",
   verification="transcript-reported (Iris spot-check)"),
 r("AUDIT-20260928-029", "CORRECTION to AUDIT-20260928-013 (repair-pass disposition)", "2026-09-28",
   "~/workspace/rte-suite-build/ + ~/workspace/ts-spaces/rte-hospitality/",
   "unrecorded", "unrecorded", "unrecorded", "unrecorded", 0, [],
   "Hospitality now fetches assets/hospitality.jsonl matching the empty canonical registry; 0:1 legend added. Verification labels already correct; golf hydration already correct.",
   "MAINTENANCE", "Correction record. Supersedes AUDIT-20260928-013: no gate ran on the repair pass itself, so WRITTEN overclaimed. Reclassified as non-gated maintenance on already-gated builds.",
   False, True, "Issued per the append-only rule: the original record is untouched.",
   verification="transcript-reported"),
 r("AUDIT-20260928-030", "CORRECTION to AUDIT-20260928-005 (RTE-Hospitality pre-fill repairs)", "2026-09-28",
   "~/workspace/ts-spaces/rte-hospitality/index.html",
   "SOUND", "SOUND", "SOUND", "3-0 SOUND", 0, [],
   "Two pre-fill repairs were flagged at gate time and applied in the follow-up pass (AUDIT-20260928-013 / 029): the snapshot loader's hardcoded empty data URL, and the missing plain-language 0:1 legend.",
   "WRITTEN", "Correction record. Supersedes AUDIT-20260928-005: its 'No repairs needed' was wrong — the transcript reports two flagged repairs, applied afterward.",
   False, False, "Issued per the append-only rule: the original record is untouched.",
   verification="daily log 2026-09-28 (two pre-fill repairs flagged) + repair-pass record"),
 r("AUDIT-20260928-031", "CORRECTION to AUDIT-20260928-007 (RTE-Financials repair scope + source path)", "2026-09-28",
   "~/workspace/your_files/rte-financials/rte-financials.html",
   "unrecorded", "unrecorded", "unrecorded", "CONDITIONAL x3", 3, [],
   "One defect repaired and verified (the .instrument-top centering defect). Two judgment calls deferred to the founder: whether text_match belongs in the worker-facing directive, and whether the single gold ledger heart reads as ornamental.",
   "REPAIRED-AND-WRITTEN", "Correction record. Supersedes AUDIT-20260928-007: 'all repaired and verified' overclaimed — one repaired, two deferred. Also corrects the artifact path to the transcript-reported source.",
   False, False, "Issued per the append-only rule: the original record is untouched.",
   verification="daily log 2026-09-28 (CONDITIONAL x3; centering defect repaired; two judgment calls)"),
 r("AUDIT-20260928-032", "CORRECTION to AUDIT-20260928-014 (healthcare repair count sourcing)", "2026-09-28",
   "~/workspace/healthcare-taxpayer/rte-healthcare-taxpayer.html",
   "CONDITIONAL", "SOUND", "CONDITIONAL", "CONDITIONAL x2", 2,
   [{"id": "C1", "raised_by": "DCLM", "finding": "unrecorded in transcript", "repair": "Repaired.", "repair_verified": True},
    {"id": "C2", "raised_by": "Twain2", "finding": "Transcript-verified actions: the unlanded seal claim removed, viewer-facing jargon simplified, prescriptive close rewritten.", "repair": "Repaired; the parent build summary counts eight Twain2 repairs.", "repair_verified": True}],
   "DCLM condition repaired; Twain2 repairs completed (eight per the parent build summary).", "REPAIRED-AND-WRITTEN",
   "Correction record. Supersedes AUDIT-20260928-014: the eight-repair count is sourced to the parent build summary (forked build transcript 2026-09-28); the transcript-verified actions are now stated.",
   False, True, "Issued per the append-only rule: the original record is untouched.",
   verification="parent build summary, forked build transcript 2026-09-28"),
 r("AUDIT-20260928-033", "CORRECTION to AUDIT-20260928-020 (education condition sourcing)", "2026-09-28",
   "~/workspace/education-taxpayer/rte-education-taxpayer.html",
   "SOUND", "SOUND", "CONDITIONAL", "CONDITIONAL x2", 2,
   [{"id": "C1", "raised_by": "Twain2", "finding": "'banked' leaked into viewer copy (4 hits).", "repair": "Replaced with plain words ('calculated from the figures above', 'the September 2026 Ontario data').", "repair_verified": True},
    {"id": "C2", "raised_by": "Twain2", "finding": "Failure banners spoke registry jargon.", "repair": "Rewritten in citizen words ('The figures could not be verified right now').", "repair_verified": True}],
   "Both Twain2 conditions repaired.", "REPAIRED-AND-WRITTEN",
   "Correction record. Supersedes AUDIT-20260928-020: the condition findings and repairs are verified against the builder completion handoff (forked build transcript 2026-09-28), which lists both conditions verbatim.",
   False, False, "Issued per the append-only rule: the original record is untouched.",
   verification="builder completion handoff, forked build transcript 2026-09-28"),
 r("AUDIT-20260928-034", "CORRECTION to AUDIT-20260928-022 (access-seat DCLM repair sourcing)", "2026-09-28",
   "~/workspace/access-seat/access-seat-source.html",
   "CONDITIONAL", "SOUND", "CONDITIONAL", "CONDITIONAL x13", 13,
   [{"id": "DCLM-C1..C5", "raised_by": "DCLM", "finding": "Five conditions (details unrecorded in transcript).", "repair": "All five repaired, incl. downgrading registry text_match overclaims to paraphrase with review_required.", "repair_verified": True},
    {"id": "Twain2-C1..C8", "raised_by": "Twain2", "finding": "Eight conditions; six repaired, two declined with rationale (kept the settled 0:1 taxonomy and the 'Draft - not landed' seal formula for cross-build consistency).", "repair": "Six repaired; two declined with written rationale.", "repair_verified": True}],
   "DCLM x5 repaired; Twain2 x8: six repaired, two declined with rationale.", "REPAIRED-AND-WRITTEN",
   "Correction record. Supersedes AUDIT-20260928-022: the DCLM repair detail is verified against the builder completion handoff (forked build transcript 2026-09-28), which lists all five DCLM repairs including the text_match downgrade.",
   False, True, "Issued per the append-only rule: the original record is untouched. Condition details beyond the handoff remain unrecorded.",
   verification="builder completion handoff, forked build transcript 2026-09-28"),
 r("AUDIT-20260928-035", "CORRECTION to AUDIT-20260928-008 (DIVINE treatment sourcing)", "2026-09-28",
   "~/workspace/ts-spaces/dualiscapax-mobile-site/",
   "SOUND", "SOUND", "SOUND", "3-0 SOUND", 0, [],
   "No repairs needed.", "WRITTEN", "Correction record. Supersedes AUDIT-20260928-008: the 'exactly one append-only CSS block; no HTML, JS, or copy changed' claim is verified against the parent build summary (forked build transcript 2026-09-28). Applied to the working copy; frozen pages otherwise untouched.",
   False, False, "Issued per the append-only rule: the original record is untouched.",
   verification="parent build summary, forked build transcript 2026-09-28"),
 r("AUDIT-20260928-036", "CORRECTION to AUDIT-20260928-009 (Core hub standing-condition semantics)", "2026-09-28",
   "~/workspace/your_files/rte-core/rte-core.html",
   "SOUND", "CONDITIONAL", "SOUND", "CONDITIONAL x1", 1,
   [{"id": "C1", "raised_by": "Iris",
     "finding": "Canonical registry/snapshot freshness must remain authoritative; the page is not a live file-existence check.",
     "repair": "Confirmed as a standing design constraint, not a closable defect: the registry remains the freshness authority for the life of the page. WRITTEN stands with the condition open by design.",
     "repair_verified": "standing"}],
   "Condition confirmed as a permanent constraint; no closure action exists.", "WRITTEN",
   "Correction record. Supersedes AUDIT-20260928-009: resolves the open-condition question — the Iris condition is standing law for the page, carried forward, not a defect to close.",
   False, False, "Issued per the append-only rule: the original record is untouched.",
   verification="parent build summary, forked build transcript 2026-09-28"),
 r("AUDIT-20260928-037", "Audit Ledger gate (the gate audits the audit)", "2026-09-28",
   "~/workspace/audit-ledger/",
   "CONDITIONAL", "CONDITIONAL", "CONDITIONAL", "CONDITIONAL x30 — all repaired or declined with rationale", 30,
   [{"id": "DCLM-C1..C10", "raised_by": "DCLM",
     "finding": "Ten conditions: one FAIL-grade backfill error (golf votes marked unrecorded), two misreported repair histories (hospitality, financials), four unsourced details (healthcare count, education specifics, access DCLM detail, DIVINE-treatment claim), one open-condition question (core hub), two stale pending records (whole-site, consultation mechanism).",
     "repair": "All ten repaired via the append-only path: correction records 028 and 030-036; follow-up records 026-027 for the landed builds. No frozen record edited.",
     "repair_verified": True},
    {"id": "IRIS-C1..C4", "raised_by": "Iris",
     "finding": "Four conditions: charter claimed the ledger's own gate record before it existed; golf votes mislabeled; repair pass overclaimed WRITTEN; legend overgeneralized repaired-and-written.",
     "repair": "C1 resolved by this very record (the gate record is now the last record, as the charter states). C2-C4 repaired via records 028-029 and the legend fix. New MAINTENANCE outcome added to the charter for non-gated work.",
     "repair_verified": True},
    {"id": "TWAIN-C1..C16", "raised_by": "Twain2",
     "finding": "Sixteen plain-words conditions on the page and charter.",
     "repair": "Repaired: PENDING defined in the legend; plain-words glossary added; legend/footer/charter de-jargoned; repairs line and legend heading centered; redundant condition text trimmed. Declined with rationale: rewording frozen record notes (C4, C6-C13, card portions of C2/C3/C14) — record notes quote the build reports verbatim and the append-only rule forbids rewriting history; the glossary carries the plain meanings instead.",
     "repair_verified": True}],
   "Every condition repaired via new records, or declined with written rationale above.", "REPAIRED-AND-WRITTEN",
   "The gate audits the audit. This record is the last in the ledger, as the charter states. Handed to FACTORY_BULLETIN_BOARD on 2026-09-28 following the clean gate.",
   True, False, "Three genuinely separate umpire passes; all conditions closed.",
   verification="umpire reports, this build"),
]

ALL = ALL + APPENDIX


def pill_class(vote):
    v = vote.lower()
    if vote == "SOUND" or "sound" in v and "conditional" not in v:
        return "sound"
    if "conditional" in v:
        return "cond"
    if "proceed" in v or "pass" in v:
        return "sound"
    return "na"


def esc(t):
    return html.escape(str(t), quote=False)


def vote_pill(label, vote):
    return f'<span class="vote {pill_class(vote)}"><span class="vl">{label}</span><span class="vv">{esc(vote)}</span></span>'


def disposition_pill(d):
    cls = {"WRITTEN": "d-written", "REPAIRED-AND-WRITTEN": "d-repaired",
           "NOT-WRITTEN": "d-not", "PENDING": "d-pending",
           "MAINTENANCE": "d-maint"}.get(d, "d-not")
    label = {"MAINTENANCE": "MAINTENANCE (non-gated)"}.get(d, d)
    return f'<span class="disp {cls}">{esc(label)}</span>'


def card(rec):
    g = rec["gate"]
    conds = "".join(
        f'<li><strong>{esc(c["id"])}</strong> <span class="by">({esc(c["raised_by"])})</span> — {esc(c["finding"])}<br>'
        f'<span class="rep">Repair: {esc(c["repair"])}</span></li>'
        for c in rec["conditions"]
    )
    cond_block = (f'<ul class="conds">{conds}</ul>' if conds
                  else '<p class="conds-note">No conditions.</p>')
    review = '<p class="review">Needs review: some details were not written down in the build notes and are marked, not invented.</p>' if rec["needs_review"] else ""
    return f'''
<article class="card">
  <p class="rid">{esc(rec["record_id"])}</p>
  <h3>{esc(rec["build_name"])}</h3>
  <p class="date">{esc(rec["date"])}</p>
  <div class="votes">{vote_pill("DCLM", g["dclm"])}{vote_pill("Iris", g["iris"])}{vote_pill("Twain2", g["twain2"])}</div>
  <p class="overall">Overall: <strong>{esc(g["overall"])}</strong></p>
  {cond_block}
  <p class="repairs"><span class="k">Repairs</span> — {esc(rec["repairs_summary"])}</p>
  <p class="disp-line">{disposition_pill(rec["disposition"])} <span class="dn">{esc(rec["disposition_note"])}</span></p>
  <p class="path">{esc(rec["artifact_path"])}</p>
  {review}
</article>'''


ART = '''<svg viewBox="0 0 360 220" role="img" aria-label="The audit ledger seal" aria-hidden="true">
<defs>
<radialGradient id="lg" cx="50%" cy="35%" r="75%">
<stop offset="0%" stop-color="#14b8a6" stop-opacity="0.55"/>
<stop offset="55%" stop-color="#7C3AED" stop-opacity="0.28"/>
<stop offset="100%" stop-color="#07080c" stop-opacity="0"/>
</radialGradient>
<linearGradient id="pg" x1="0" y1="0" x2="1" y2="1">
<stop offset="0%" stop-color="#14b8a6"/><stop offset="100%" stop-color="#a855f7"/>
</linearGradient>
</defs>
<rect width="360" height="220" fill="#0a0c12"/>
<circle cx="180" cy="110" r="98" fill="url(#lg)"/>
<rect x="118" y="52" width="124" height="116" rx="10" fill="#10131c" stroke="url(#pg)" stroke-width="2.5"/>
<rect x="118" y="52" width="124" height="26" rx="10" fill="#14b8a6" opacity="0.18"/>
<line x1="134" y1="96" x2="226" y2="96" stroke="#14b8a6" stroke-width="3" opacity="0.85" stroke-linecap="round"/>
<line x1="134" y1="112" x2="208" y2="112" stroke="#a855f7" stroke-width="3" opacity="0.7" stroke-linecap="round"/>
<line x1="134" y1="128" x2="218" y2="128" stroke="#14b8a6" stroke-width="3" opacity="0.55" stroke-linecap="round"/>
<line x1="134" y1="144" x2="196" y2="144" stroke="#a855f7" stroke-width="3" opacity="0.45" stroke-linecap="round"/>
<circle cx="180" cy="110" r="118" fill="none" stroke="#a855f7" stroke-width="1.5" opacity="0.35"/>
<circle cx="180" cy="110" r="128" fill="none" stroke="#14b8a6" stroke-width="1" opacity="0.25"/>
<circle cx="272" cy="52" r="2.5" fill="#f3efe6" opacity="0.8"/>
<circle cx="92" cy="168" r="2" fill="#f3efe6" opacity="0.6"/>
<circle cx="300" cy="150" r="1.8" fill="#14b8a6" opacity="0.7"/>
<circle cx="66" cy="60" r="1.6" fill="#a855f7" opacity="0.7"/>
</svg>'''


def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    (ROOT / "assets").mkdir(exist_ok=True)
    # Append-only guard: the frozen spine must be byte-identical to what was hashed.
    import hashlib
    spine = ALL[:len(FROZEN_IDS)]
    assert [rec["record_id"] for rec in spine] == FROZEN_IDS, "frozen spine order changed"
    h = hashlib.sha256(
        "".join(json.dumps(rec, ensure_ascii=False, sort_keys=True) for rec in spine).encode()
    ).hexdigest()
    assert h == FROZEN_HASH, "a frozen record was edited — corrections must be new records"
    with open(LEDGER, "w", encoding="utf-8") as f:
        for rec in ALL:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    shutil.copyfile(LEDGER, SNAP)

    n = len(ALL)
    by_disp = {}
    for rec in ALL:
        by_disp[rec["disposition"]] = by_disp.get(rec["disposition"], 0) + 1
    cards = "\n".join(card(rec) for rec in reversed(ALL))

    page = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>The Audit Ledger — the gate, audited</title>
<style>
:root{{--bg:#07080c;--fg:#f3efe6;--teal:#14b8a6;--purp:#a855f7;--gold:#e8c36a;--grn:#00FF9D;--mut:#9aa3b2}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--bg);color:var(--fg);font-family:system-ui,-apple-system,"Segoe UI",sans-serif;line-height:1.55}}
.wrap{{max-width:44rem;margin:0 auto;padding:1.25rem 1rem 4rem}}
.eyebrow{{text-align:center;letter-spacing:.28em;font-size:.72rem;color:var(--teal);margin:1.5rem 0 .5rem}}
h1{{text-align:center;font-size:clamp(1.9rem,6vw,2.8rem);margin:.25rem 0;font-weight:700}}
.sub{{text-align:center;color:var(--mut);font-size:clamp(1rem,3.4vw,1.15rem);max-width:34rem;margin:0 auto 1.5rem}}
.art{{border:1px solid rgba(20,184,166,.35);border-radius:1rem;overflow:hidden;margin:0 0 1.5rem;background:#0a0c12}}
.art svg{{display:block;width:100%;height:auto}}
.stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(7.5rem,1fr));gap:.75rem;margin:0 0 1.5rem}}
.stat{{background:#0d1017;border:1px solid rgba(168,85,247,.3);border-radius:.9rem;padding:1rem .5rem;text-align:center}}
.stat .n{{font-size:clamp(1.6rem,5.5vw,2.2rem);font-weight:700;color:var(--grn)}}
.stat .l{{font-size:.82rem;color:var(--mut);margin-top:.25rem}}
.legend{{background:#0d1017;border:1px solid rgba(20,184,166,.3);border-radius:.9rem;padding:1.1rem 1.25rem;margin:0 0 2rem;font-size:.95rem}}
.legend h2{{font-size:1.05rem;margin:0 0 .5rem;color:var(--teal);text-align:center}}
.legend p{{margin:.4rem 0;color:var(--mut)}}
.legend strong{{color:var(--fg)}}
h2.sec{{text-align:center;font-size:1.3rem;margin:2.5rem 0 1rem}}
.card{{background:#0d1017;border:1px solid rgba(20,184,166,.28);border-radius:1rem;padding:1.25rem;margin:0 0 1.25rem}}
.card .rid{{font-size:.72rem;letter-spacing:.14em;color:var(--mut);margin:0 0 .35rem;text-align:center}}
.card h3{{text-align:center;font-size:clamp(1.05rem,3.8vw,1.3rem);margin:0 0 .2rem}}
.card .date{{text-align:center;color:var(--mut);font-size:.9rem;margin:0 0 .9rem}}
.votes{{display:flex;flex-wrap:wrap;gap:.5rem;justify-content:center;margin:0 0 .7rem}}
.vote{{display:inline-flex;border-radius:999px;overflow:hidden;font-size:.82rem;border:1px solid transparent}}
.vote .vl{{padding:.3rem .6rem;background:#1a1f2b;color:var(--mut)}}
.vote .vv{{padding:.3rem .7rem;font-weight:700}}
.vote.sound{{border-color:rgba(0,255,157,.5)}}.vote.sound .vv{{color:var(--grn)}}
.vote.cond{{border-color:rgba(232,195,106,.55)}}.vote.cond .vv{{color:var(--gold)}}
.vote.na{{border-color:rgba(154,163,178,.4)}}.vote.na .vv{{color:var(--mut)}}
.overall{{text-align:center;margin:.2rem 0 .8rem}}
.conds{{margin:.5rem 0;padding-left:1.1rem;font-size:.93rem}}
.conds li{{margin:.45rem 0}}
.conds .by{{color:var(--mut);font-size:.85rem}}
.conds .rep{{color:var(--teal)}}
.conds-note{{font-size:.93rem;color:var(--mut);text-align:center}}
.repairs{{font-size:.93rem;text-align:center}}.repairs .k{{color:var(--teal);font-weight:700}}
.disp-line{{margin:.9rem 0 .4rem;text-align:center}}
.disp{{display:inline-block;padding:.32rem .8rem;border-radius:999px;font-size:.8rem;font-weight:700;letter-spacing:.04em}}
.d-written{{background:rgba(20,184,166,.16);color:var(--teal);border:1px solid rgba(20,184,166,.5)}}
.d-repaired{{background:rgba(168,85,247,.14);color:#c4a5fd;border:1px solid rgba(168,85,247,.5)}}
.d-not{{background:rgba(154,163,178,.12);color:var(--mut);border:1px solid rgba(154,163,178,.4)}}
.d-pending{{background:transparent;color:var(--gold);border:1px dashed rgba(232,195,106,.6)}}
.d-maint{{background:rgba(20,184,166,.08);color:var(--mut);border:1px dotted rgba(20,184,166,.5)}}
.dn{{display:block;margin-top:.5rem;color:var(--mut);font-size:.9rem}}
.path{{text-align:center;font-size:.8rem;color:var(--mut);overflow-wrap:anywhere;margin:.6rem 0 0}}
.review{{font-size:.85rem;color:var(--gold);text-align:center;margin:.7rem 0 0}}
footer{{margin:3rem 0 0;padding-top:1.5rem;border-top:1px solid rgba(20,184,166,.25);font-size:.92rem;color:var(--mut);text-align:center}}
footer strong{{color:var(--fg)}}
@media (prefers-reduced-motion:reduce){{*{{animation:none!important;transition:none!important}}}}
</style>
</head>
<body>
<div class="wrap">
<p class="eyebrow">THE GATE &middot; AUDITED</p>
<h1>The Audit Ledger</h1>
<p class="sub">Every verdict the gate ever gave, written down. The gate runs on everything &mdash; and it is being audited.</p>
<figure class="art">{ART}</figure>
<div class="stats">
<div class="stat"><div class="n">{n}</div><div class="l">Records</div></div>
<div class="stat"><div class="n">{by_disp.get("WRITTEN",0)}</div><div class="l">Written</div></div>
<div class="stat"><div class="n">{by_disp.get("REPAIRED-AND-WRITTEN",0)}</div><div class="l">Repaired and written</div></div>
<div class="stat"><div class="n">{by_disp.get("NOT-WRITTEN",0)}</div><div class="l">Not written</div></div>
<div class="stat"><div class="n">{by_disp.get("MAINTENANCE",0)}</div><div class="l">Maintenance</div></div>
<div class="stat"><div class="n">{by_disp.get("PENDING",0)}</div><div class="l">Awaiting the gate</div></div>
</div>
<div class="legend">
<h2>How to read this page</h2>
<p><strong>SOUND</strong> means the umpire found nothing to repair. <strong>CONDITIONAL</strong> means conditions were raised &mdash; the count follows the word.</p>
<p><strong>Written</strong> means the build passed the gate and stands. <strong>Repaired-and-written</strong> means every condition was repaired &mdash; or explicitly declined with written rationale &mdash; and the repairs were checked again. <strong>Not written</strong> means the build did not pass through the gate, with the reason stated. <strong>Maintenance</strong> means non-gated upkeep on already-gated builds; no gate ran on the work itself. <strong>Pending</strong> means the gate hasn't run yet &mdash; the build is still in flight.</p>
<p><strong>Unrecorded</strong> means the build notes never wrote that detail down. It is marked, never invented. Records marked <strong>needs review</strong> carry exactly that flag.</p>
<p>Some words on the cards are the workshop's own shorthand: <strong>0:1</strong> means marked empty until real data arrives; <strong>MOCK</strong> means labeled test content, not real data; <strong>PILOT MODE</strong> means modeled analysis on available figures, not live data; <strong>banked</strong> means the September 2026 figures, taken as given; <strong>snapshot</strong> means an exact copy of the registry bundled with the page. The cards quote the build reports word-for-word &mdash; the record keeps what was said, even when the shorthand shows.</p>
<p>Records are listed newest first. Nothing here is a live claim &mdash; it is the record of what the gate said, when it said it.</p>
</div>
<h2 class="sec">The records</h2>
{cards}
<footer>
<p><strong>The append-only rule.</strong> Records in this ledger are never edited. A correction is a new record that names the record it replaces, in its notes.</p>
<p>The canonical record is <strong>audit.jsonl</strong>. This page is a snapshot of it, generated {esc("2026-09-28")}.</p>
<p>Every future gate verdict is added here by the writer. The gate runs on everything &mdash; and it is being audited.</p>
</footer>
</div>
</body>
</html>'''
    with open(PAGE, "w", encoding="utf-8") as f:
        f.write(page)
    # verify: every record_id present in page
    missing = [rec["record_id"] for rec in ALL if rec["record_id"] not in page]
    assert not missing, f"missing records in page: {missing}"
    # verify snapshot byte-identical
    a = LEDGER.read_bytes(); b = SNAP.read_bytes()
    assert a == b, "snapshot not byte-identical"
    print(f"records={n} page_cards={page.count('<article class=')} snapshot_identical=True")


if __name__ == "__main__":
    main()
