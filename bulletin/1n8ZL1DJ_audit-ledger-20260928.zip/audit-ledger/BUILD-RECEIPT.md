# BUILD-RECEIPT — Audit Ledger

**Built:** September 28, 2026, under the authority register and the execution path.
**Package:** `audit-ledger-20260928.zip`

## What it is

The permanent, append-only record of the gate — "and its being audited," made real and visible.

- `audit.jsonl` — the canonical record. 37 records, one per gated build (or correction, or pending build). Append-only: records are never edited; corrections are new records that name the record they replace.
- `assets/audit.jsonl` — byte-identical bundled snapshot.
- `audit-ledger.html` — the DIVINE audit page. Newest first, each record a centered card: build, date, the three votes, conditions, repairs, outcome. Picture-first, mobile-first, enlarged-font safe, reduced-motion stills.
- `AUDIT-LEDGER.md` — the charter: what the ledger is, the append-only rule, the going-forward contract (every future gate verdict is added here by the writer, as part of the build).
- `build.py` — regenerates the snapshot and the page from the canonical record. Carries a frozen-spine guard: it refuses to regenerate if any backfilled record was edited.

## Backfill honesty

22 builds backfilled from the 2026-09-28 build transcript, plus the whole-site assembly and the Trinity consultation mechanism when they landed, plus the ledger's own gate record. The backfill law held throughout: **record only what actually happened.** Where the transcript never wrote a detail down, the record says `unrecorded` — never invented. 23 records carry `needs_review`. Three builds remain PENDING (gate not yet run): the Unity Framework website and two others in flight.

## The gate (the gate audits the audit — three genuinely separate passes)

- **DCLM: CONDITIONAL ×10 → all repaired.** One FAIL-grade backfill error (RTE-Golf votes marked unrecorded that the transcript reports), two misreported repair histories, four unsourced details, one open-condition question, two stale pending records. All repaired via the append-only path (records 028, 030–036, 026–027). No frozen record edited.
- **Iris: CONDITIONAL ×4 → all repaired.** Charter claim corrected by this very record existing; golf votes corrected; repair-pass reclassified as MAINTENANCE (new outcome, added to the charter); legend fixed.
- **Twain²: CONDITIONAL ×16 → repaired or declined with rationale.** Legend gained the PENDING definition and a plain-words glossary; footer, charter, and generated copy de-jargoned; centering fixed. Rewording frozen record notes declined with written rationale: the notes quote the build reports verbatim and the append-only rule forbids rewriting history — the glossary carries the plain meanings instead.

Final verdict: **CONDITIONAL ×30, every condition repaired or declined with written rationale, statically re-verified.** The vote is the execution path.

## Standing limitation

No live browser render was performed — code-verified only. David's eyes remain the final QA.
