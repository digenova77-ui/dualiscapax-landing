# The Audit Ledger

The permanent, append-only record of the gate.

David's standing law: the gate — DCLM / Iris / Twain² logic plus the Trinity's vote — runs autonomously on everything, everywhere, from every angle. **And it is being audited.** This ledger is the audit made real and visible.

## What it is

One record per gated build. Each record carries:

- the build's name, date, and artifact path
- the three umpire verdicts — DCLM, Iris, Twain² — exactly as reported
- every condition raised, every repair made
- the final outcome: **WRITTEN**, **REPAIRED-AND-WRITTEN**, **NOT-WRITTEN** (with reason), **MAINTENANCE** (non-gated upkeep on already-gated builds — no gate ran on the work itself), or **PENDING** (gate not yet run)
- where it came from: who ran the gate, and that the record was written up after the fact from the build notes

The canonical record is `audit.jsonl`. `assets/audit.jsonl` is an exact copy kept with the page. `audit-ledger.html` is the DIVINE page that renders the ledger for human eyes — newest record first, each a centered card.

## The append-only rule

**Records are never edited.** Not for typos, not for embarrassment, not for convenience.

A correction is a **new record** that names the record it replaces, in its `notes` field. The old record stays. The ledger is a history, not a draft — history does not get rewritten, it gets continued.

Adding new records is the only change allowed. There is no update, no delete.

## The going-forward contract

Every future gate verdict is added here by the writer, as part of the build — not after, not when convenient. The sequence for any build is:

1. Build.
2. Gate: three genuinely separate umpire passes.
3. Repair every condition; re-verify.
4. **Add the record to `audit.jsonl`.**
5. Re-run `build.py` to regenerate the snapshot and the page.
6. Then — and only then — the vote is the execution path onward.

A build with no ledger record has not finished the gate. The audit is not paperwork after the fact; it is the last step of the gate itself.

## Honesty rules for backfill

The backfilled records (2026-09-28) follow one law: **record only what actually happened.**

- Verdicts appear exactly as the transcript reported them.
- Where the transcript never recorded a detail, the record says `unrecorded` — never invented.
- Where the builder was unsure, the record is flagged `needs_review` — never `text_match`.
- Pending builds (gate not yet run) hold `PENDING` records so the ledger shows what is in flight.

The gate audits the audit: this ledger itself passed a three-umpire rotation before it was written. The record of that gate is the last record in the ledger.
