# BUILD RECEIPT — base3d-worldwide-20260929-nav2.zip

**Artifact:** worldwide 3D package (34 stations, manifest ED-DATA-20260929-BASE3D-MANIFEST-V15)
**Built:** 2026-09-29T08:21:55Z
**Generator:** `build-worldwide.py` (sha256 `dd5314f546953a5a5d33239a05deceb2307d8f0d6529ac1b95ebd894784eb189`)
**Package sha256:** `18ad037cc9c2a2892ba3b723f2bbbd00e5f0bd194f55c02941a7569794217e09`
**Package size:** 1,716,993 bytes
**Supersedes:** `base3d-worldwide-20260929-nav.zip` (nested archive layout — this zip is flat: `index.html` + `BUILD-RECEIPT.md` at archive root)

## What changed in this fix round (sighted-bot render report, 2026-09-29)

The box bot rendered the -nav.zip locally at desktop and phone widths (no crash) and returned 7 items. Disposition:

1. **WAVE DESK title/subtitle overlap** — FIXED. The art-plate words are now laid out bottom-up from a wrapped line list; the title can never sit on the subtitle however many lines it wraps to. Copy untouched — layout only.
2. **Subtitle ran off phone edges** — FIXED. A narrow-viewport framing helper pulls the station anchor back proportionally on phone aspects so the full 4.6-unit art plate stays inside the frustum. Desktop aspects (>= 1) untouched; composes with the calm drift, drag-look, and reduced-motion.
3. **Desktop clipped the hero card top** — FIXED. All 24 v1 plates reframed to y=1.55, z=1.4 (verified against the 55°-FOV station framing: plate top 2.99 vs 3.41 visible; no center-card occlusion). The 9 world-section templates match.
4. **Figures row clipped outer cards ($97.1B lost its $, NOT YET MEASURED clipped, source lines warped)** — FIXED. Arc tightened (wave-desk + healthcare 1.15→0.86; 22 domain spans capped at 0.94), end-card yaw eased (0.9→0.65), figure-card source line enlarged 30→33px and bottom-anchored so it can never cross the card's bottom edge. Source copy untouched.
5. **`<title>` contained (DRAFT)** — FIXED. Title is now `Base 3D — DualisCapax`. The DRAFT badge removal from the prior round is intact.
6. **Filename says -nav but navigation is only the station dropdown** — NO CHANGE, by design. The 34-station dropdown IS the navigation, per sealed verdict ED-VERDICT-20260929-NAV-DESIGN-V1. The "-nav" in the zip name refers to the nav redesign. Verified 34/34: 34 unique station keys, 34 dropdown options, real `api.goToSection` navigation on change, counts line outside the dropdown (Iris binding).
7. **One console 404 (favicon)** — FIXED. Inline data-URI SVG favicon (teal orb); no external favicon request occurs.

## Validation

- Generator assertion suite green (fail-loud on rebuild), including new assertions: no DRAFT in `<title>`, favicon embedded, narrow-viewport framing present, nav change wiring intact, arc/plate counts exact.
- All 37 inline script blocks pass `node --check`.
- Manifest V15 intact; 1,694 figures; 380 unknown slots; all v1 entries byte-identical.
- Counts mechanism intact (computed from manifest at runtime): 2,108 instruments · 1 banked · 1,615 reported · 78 modeled · 380 unknown · 0 unlabeled.
- Frozen surface `~/workspace/ts-spaces/web3d-hud/`: 52/52 files unchanged (sha256 + nanosecond mtime) vs 2026-09-29 snapshot.
- v1 base package untouched (all fixes encoded in the generator).

## Honest limitation

No live render is available in this build environment; the box bot remains the visual QA. David's eyes are final.
