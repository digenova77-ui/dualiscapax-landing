# BUILD RECEIPT — base3d worldwide nav redesign (Twain² second-pass remediation)

- Artifact: index.html (single-file 3D worldwide build)
- SHA-256: c0fb2484a511832eae28ee18fd6138e75dcad806dea9b26887b4c718573697d6
- Bytes: 1,711,293
- Built: 2026-09-29 ~04:01 EDT via build-worldwide.py (generator, assertion suite 6/6 green)
- Manifest: V15 — 34 stations, 2,108 instruments, 1 banked, 1,615 reported, 78 modeled, 380 unknown, 0 unlabeled, 1,694 figures
- Design verdict: ED-VERDICT-20260929-NAV-DESIGN-V1 (PASS-WITH-NOTES, sealed)
- Twain² second pass: PASS-WITH-NOTES — DRAFT badge regression killed at generator level, label "Station · 34", ellipsis hardening
- Crash diagnostic 2026-09-29: no code defect; Chrome "Aw Snap" attributed to transient GPU memory pressure (3 heavy WebGL loads in 8 min), not the build
- Frozen surface: ~/workspace/ts-spaces/web3d-hud/ 52/52 unchanged (sha256+mtime)
- Pre-flight: no payments, no stripe, no buy flows — static single file
- Rollback: previous board build / live build at bot's discretion (owner: David)

Owner go-ahead for deploy: David, 2026-09-29 ~04:09 EDT ("landing it on the live site").
Test plan: owner tests in a second browser; on failure, bot redeploys current live build.
