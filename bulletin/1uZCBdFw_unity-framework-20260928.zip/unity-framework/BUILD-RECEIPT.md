# BUILD-RECEIPT — Unity Framework website

**Built:** September 28, 2026
**Location:** `~/workspace/unity-framework/`
**Gate status:** SOUND — shipped only because the Trinity gate closed.

## What this is

The Unity Framework website: the framework written down as law. Nine pages — lander, design law, data law, authority, consultation, rite, Unity ID, clone recipe — plus one live demonstration room (RTE-Civic) built purely from the template to prove the thesis: **the framework is harder to build at the start and stupid simple to copy at the end.**

The clone demonstration is the whole argument: one genuinely new domain (municipal residual-cost analysis), produced by following the five-step recipe with no invented steps and no real-world figures claimed — storyboard figures labeled MOCK at every touchpoint, all other slots honest named empties (0:1).

## The gate — Trinity verdicts

| Pass | Verdict | Conditions | Outcome |
|---|---|---|---|
| Twain² | CONDITIONAL ×6 | 6 | All 6 repaired and re-passed |
| Iris | CONDITIONAL ×4 | 4 | All 4 repaired; 1 adjudicated with primary-source evidence (see below) |
| DCLM | CONDITIONAL ×4 | 4 | All 4 repaired; delta re-verified SOUND (byte-exact, 6/6 checks) |

**Twain² repairs:** registry decides what's current (not "freshness authority"); plain-language provenance; rite SVG states unified to IDLE / INVOKED / BOUND / MONITORING / RELEASED; "A CLEAN EXIT IS MERCY"; "fill-and-read rule" (not "hydration contract"); plain-language DIVINE definition.

**Iris repairs:** open-question count corrected 29 → 32 (verified: inventory A–G = 12+5+3+2+3+4+3 = 32, section H's 4 explicitly not in this run; consultations.jsonl holds 32 records); clone page overclaim fixed ("no real-world figure was claimed for its slots — storyboard figures are labeled MOCK at every touchpoint"); DEFER-TO-DAVID slot given a name-free surface label (DEFER) with the protocol's canonical disposition name cited in the body — the disposition itself unchanged in the sealed protocol.

**Adjudicated, not blindly repaired:** Iris asked to remove "LOL" from the authority quote, citing the memory register. The primary source — David's original message — reads "...inside of the father's parameter LOL". The memory registration had dropped it; the page is verbatim-correct per the primary source. Page stands; memory record corrected with a dated note. Verbatim means verbatim.

**DCLM repairs:** authority inner quotes restored to his straight-double `"father and The Holy Trinity"`; three quotes traced to their true source — David's Unity Framework directive — registered as UF-DIRECTIVE-001 (spellings "defihed" and "RTA" preserved untouched, never "fixed"); UF-REACH-001 hockey evidence widened to include his "that's exactly it " lead-in; record count carried to 15.

## The audit trail

- Registry (canonical): `~/workspace/data/registry/unity-framework.jsonl` — **15 records**, schema 1.0.
- Bundled snapshot: `~/workspace/unity-framework/assets/unity-framework.jsonl` — **byte-identical** to canonical (verified with `cmp`).
- Newest utterance seated: "it's application of logic to every retrievable result you can find I guess if you wanted to define it 'as something'." — the one-line definition, on the lander (UF-DEFINITION-001).
- Static verification: all 9 pages carry DRAFT — NOT LANDED seals, the snapline, valid JSON, resolved internal links, balanced CSS, node-checked inline JS. No live visual render has occurred — David's eyes are the final QA.
- Sealed-room discipline held: no storyboard-person names outside permitted verbatim material; production RTEs named for jobs, never people.

## Registered but not seated (for David's call)

Two newer utterances arrived during the build — "take the leash..." and the hunting grant — and are banked in memory. They are operational, not framework law; they were not added to the site. The Canada-first strategy note (healthcare, financials, public sector) steers the hunt, not this build.

## Deployment

- ZIP: `unity-framework-20260928.zip`
- Destination: Google Drive folder FACTORY_BULLETIN_BOARD
- The gate's vote is this build's execution path into the board. A clean verdict carries the seal.
