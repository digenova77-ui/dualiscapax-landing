/* DualisCapax Unity Engine — the spatial layer (2b): constellation + plates
 * Real 3D objects in the ambience layer, drawn through the ExchangePacket gate.
 *
 * DOM-first, always: every word about these objects lives in the document
 * (the shell's 3D LAYER card). The scene carries light only — no readable
 * text, no data figures, no per-object interactivity (scene craft is DEFERRED;
 * plates are visual only, no click handlers anywhere in this module).
 *
 * THE CONSTELLATION IS THE SHELL'S. It is NOT the frozen landing page's
 * constellation and is never presented as such. One lit node = the mounted
 * environment (pharmacology). The dim nodes are honest empties: unmounted
 * mounting points for future intervals, labeled in the DOM as unmounted
 * mounting points — never as content. Zero contact with frozen pages stands
 * (open architecture question #1 stays undecided).
 *
 * PLATES: each mounted environment gets one 3D plate object. In 2b that is
 * exactly one plate — pharmacology — a soft disc behind its lit node.
 * Visual only. No interaction.
 */

'use strict';

/* Fixed, deterministic node field — positions are architecture, not data.
 * x/y in Normalized Device Coordinates (NDC). Row layout: [x, y, size px@720p, r, g, b] */
const LIT_NODE = [0.0, 0.16, 30, 0x00 / 255, 0xf5 / 255, 0xd4 / 255];

const EMPTY_NODES = [
  /* id, x, y — dim on purpose: unmounted mounting points, never content. */
  ['genome-proteome', -0.58,  0.44],
  ['wave-tranches',     0.60,  0.42],
  ['agencies',         -0.55, -0.36],
  ['seats',             0.57, -0.40]
];
const EMPTY_RGB = [0x59 / 255, 0x47 / 255, 0x73 / 255]; /* dim violet-gray */
const EMPTY_SIZE = 13;

/* The plate: a soft disc of dim teal behind the lit node. Visual only. */
const PLATE_POINTS = [
  [0.00, 0.16, 110, 0x00 / 255, 0x38 / 255, 0x30 / 255],
  [-0.17, 0.16, 70, 0x00 / 255, 0x2e / 255, 0x28 / 255],
  [0.17, 0.16, 70, 0x00 / 255, 0x2e / 255, 0x28 / 255]
];

const CONSTELLATION_PACKET = Object.freeze({
  packet_id: 'pkt-spatial-constellation-001',
  pattern_kind: 'spatial-node',
  method: 'seeded-point-node',
  fence_level: 'AMBIENT',
  screen_result: 'DECORATIVE' /* structural label — decorative kinds carry no data; no screen was run */
});

const PLATE_PACKET = Object.freeze({
  packet_id: 'pkt-spatial-plate-pharmacology-001',
  pattern_kind: 'plate',
  method: 'seeded-point-disc',
  fence_level: 'AMBIENT',
  screen_result: 'DECORATIVE' /* structural label — decorative kinds carry no data; no screen was run */
});

/* The shell's constellation, as DOM-label facts. The lit node is the mounted
 * environment; every dim node is an honest empty — an unmounted mounting
 * point. This list is what the 3D LAYER card renders. */
export const CONSTELLATION = [
  { id: 'pharmacology', lit: true, label: 'pharmacology — lit, mounted' },
  { id: 'genome-proteome', lit: false, label: 'genome-proteome — unmounted mounting point' },
  { id: 'wave-tranches', lit: false, label: 'wave-tranches — unmounted mounting point' },
  { id: 'agencies', lit: false, label: 'agencies — unmounted mounting point' },
  { id: 'seats', lit: false, label: 'seats — unmounted mounting point' }
];

function toPoints() {
  const pts = [{
    x: LIT_NODE[0], y: LIT_NODE[1], size: LIT_NODE[2],
    r: LIT_NODE[3], g: LIT_NODE[4], b: LIT_NODE[5]
  }];
  for (const [, x, y] of EMPTY_NODES) {
    pts.push({ x, y, size: EMPTY_SIZE, r: EMPTY_RGB[0], g: EMPTY_RGB[1], b: EMPTY_RGB[2] });
  }
  return pts;
}

function plateToPoints() {
  return PLATE_POINTS.map(p => ({ x: p[0], y: p[1], size: p[2], r: p[3], g: p[4], b: p[5] }));
}

/* Mount the spatial layer onto an ambience handle: the shell's constellation
 * (one lit node + honest empties) and the pharmacology plate. The ambience
 * layer draws each through the ExchangePacket gate every frame; plates.js
 * itself never touches WebGL. Returns { ok, constellation, destroy }. */
export function mountSpatialLayer(ambience) {
  if (!ambience || typeof ambience.addPointLayer !== 'function')
    return { ok: false, reason: 'no ambience point layer — spatial layer not mounted' };

  ambience.addPointLayer({ id: 'plate-pharmacology', packet: PLATE_PACKET, points: plateToPoints() });
  ambience.addPointLayer({ id: 'constellation', packet: CONSTELLATION_PACKET, points: toPoints() });

  return {
    ok: true,
    constellation: CONSTELLATION,
    destroy() {
      ambience.removePointLayer('constellation');
      ambience.removePointLayer('plate-pharmacology');
    }
  };
}
