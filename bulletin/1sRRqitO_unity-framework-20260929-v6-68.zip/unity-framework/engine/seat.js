/* DualisCapax Unity Engine — seat-mounting contract (2a/2b)
 * environment = DOM document + scene descriptor.
 * The engine supplies lighting (ambience), transitions (motion), and honesty
 * labels (the PILOT bar) — it NEVER rewrites environment content.
 * Containment: the environment's DOM document lives inside a sandboxed frame;
 * the engine's hands never cross that boundary. Byte-faithful is structural.
 */

'use strict';

import { getEnvironment, getLanded } from './registry.js';

/* P8 is load-bearing: without a consent architecture + fence declaration the
 * mounting contract is invalid (DCLM ill-sealed #4). The gate is mechanical. */
const SEAT_FIELDS = ['id', 'environment', 'subscribedEnvironments', 'pilotPosture', 'p8'];

export function createSeat(spec) {
  const missing = SEAT_FIELDS.filter(f => !(f in spec) || spec[f] === undefined || spec[f] === null);
  if (missing.length)
    return { ok: false, error: 'seat mounting refused — missing: ' + missing.join(', ') };
  if (!spec.p8 || !spec.p8.fence || !spec.p8.consentArchitecture)
    return { ok: false, error: 'seat mounting refused — P8 incomplete (fence + consent architecture required)' };
  const env = getEnvironment(spec.environment);
  if (!env) {
    if (getLanded(spec.environment))
      return { ok: false, error: 'seat mounting refused — "' + spec.environment + '" is landed-frozen: registered for the guard, never mounted (open question #1)' };
    return { ok: false, error: 'seat mounting refused — environment "' + spec.environment + '" is not registered' };
  }
  if (env.status !== 'sealed')
    return { ok: false, error: 'seat mounting refused — environment "' + spec.environment + '" is not sealed' };
  /* Seat-to-seat isolation is sealed law: a seat draws on environments, never on
   * another seat. Nothing in this contract names another seat. */
  return {
    ok: true,
    seat: {
      id: String(spec.id),
      environment: env.id,
      subscribedEnvironments: Array.isArray(spec.subscribedEnvironments) ? spec.subscribedEnvironments.slice() : [],
      scopingFilters: spec.scopingFilters || null,
      pilotPosture: String(spec.pilotPosture),
      p8: { fence: String(spec.p8.fence), consentArchitecture: String(spec.p8.consentArchitecture) },
      sessionDate: new Date().toISOString().slice(0, 10)
    }
  };
}

/* Mount a seat onto a host element.
 * Builds ONLY shell chrome around the environment's own DOM document:
 * a PILOT honesty bar (fixed template fields per architecture §6) and a
 * contained frame loading the environment's entry file as-is. The engine
 * never reaches inside the frame's document. */
export function mountSeat(seat, host) {
  const env = getEnvironment(seat.environment);
  if (!env) throw new Error('mountSeat: unregistered environment "' + seat.environment + '"');

  const wrap = document.createElement('section');
  wrap.className = 'eg-mount';
  wrap.setAttribute('aria-label', 'Mounted environment: ' + env.id);

  /* PILOT honesty bar — fixed template fields: posture + fetch date +
   * one-session-snapshot disclosure. The engine's label, on the engine's side
   * of the boundary; the environment's own copy is untouched. */
  const bar = document.createElement('div');
  bar.className = 'eg-pilot-bar';
  bar.setAttribute('role', 'note');
  bar.innerHTML =
    '<strong>' + escapeHtml(env.pilot.posture) + '</strong>' +
    '<span>one-session snapshot · fetched ' + escapeHtml(seat.sessionDate) + '</span>' +
    '<span>figures fixed at mount — the engine does not refresh them</span>';
  wrap.appendChild(bar);

  /* The environment's DOM document, contained. sandbox keeps the frame's own
   * navigation and scripts inside its boundary; allow-same-origin + allow-scripts
   * so the sealed page behaves exactly as sealed. No rewriting — ever.
   *
   * SANDBOX RE-EXAMINATION — 2b verdict, 2026-09-28 (2a watch item #2).
   * Frame→shell direction: with sandbox="allow-same-origin allow-scripts" the
   * framed document (same origin over HTTP) CAN reach window.parent and the
   * shell's DOM/JS — the boundary contains the environment's own navigation
   * and scripts; it is not a same-origin capability barrier. The posture
   * stands because the framed bytes are not arbitrary: the sealed-copy hash
   * in the integrity guard verifies pharmacology.html byte-for-byte at boot,
   * and drift refuses to boot. The trusted party is the sealed artifact,
   * verified — not the sandbox string. 2b mounts NO new surface (pharmacology
   * only — already sealed and Trinity-passed), so the 2a sandbox posture
   * stands UNCHANGED. Re-examination is owed again before the first
   * non-sealed surface ever mounts. Attributes below intentionally untouched. */
  const frame = document.createElement('iframe');
  frame.className = 'eg-mount-frame';
  frame.src = env.entry;
  frame.title = env.id + ' — sealed environment, byte-faithful';
  frame.setAttribute('sandbox', 'allow-same-origin allow-scripts');
  frame.setAttribute('loading', 'eager');
  wrap.appendChild(frame);

  /* Scene descriptor: the environment renders against the engine's ambience
   * (lighting behind, never content inside). Depth contract surfaced as a
   * normal-size clean data label. */
  const plate = document.createElement('p');
  plate.className = 'eg-depth-label';
  plate.textContent = 'Depth contract: ' + env.depthContract;
  wrap.appendChild(plate);

  host.appendChild(wrap);

  return {
    element: wrap,
    frame,
    environment: env,
    unmount() {
      if (wrap.parentNode) wrap.parentNode.removeChild(wrap);
    }
  };
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
