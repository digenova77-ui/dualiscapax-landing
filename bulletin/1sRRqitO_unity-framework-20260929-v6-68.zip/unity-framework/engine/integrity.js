/* DualisCapax Unity Engine — integrity proofs (2a)
 * L6 in code, mechanical. Four gate checks per environment claim's spirit:
 *   1. manifest — the registry is complete and well-formed;
 *   2. PILOT — every mounted environment declares its PILOT posture;
 *   3. sealed-copy — hash of the banked wordage (pharmacology.html) vs the file
 *      the shell is about to mount; drift refuses to boot;
 *   4. frozen-file guard — each of the six frozen files is fetched and hashed
 *      against its banked hash; a mismatch stops the engine with the honest-no.
 * Integrity proves labels and hashes, not truth: it proves the page says what
 * it was sealed to say and frozen files are untouched. Nothing about the world.
 */

'use strict';

import { ENVIRONMENTS, LANDED, validateRegistry } from './registry.js';

export async function sha256Hex(buffer) {
  const digest = await crypto.subtle.digest('SHA-256', buffer);
  return Array.from(new Uint8Array(digest))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

async function fetchBytes(url) {
  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  return res.arrayBuffer();
}

/* Run the full integrity gate. Returns { pass, checks, failMessage }.
 * Nothing mounts unless pass is true. */
export async function runIntegrity() {
  const checks = [];

  /* 1 — manifest. */
  const v = validateRegistry();
  checks.push({
    id: 'manifest',
    label: 'Environment registry — manifest complete',
    status: v.valid ? 'pass' : 'fail',
    detail: v.valid
      ? Object.keys(ENVIRONMENTS).length + ' sealed environment · ' + Object.keys(LANDED).length + ' landed-frozen entries'
      : v.problems.join('; ')
  });

  /* 2 — PILOT posture declared on every mounted environment. */
  const pilotOk = Object.values(ENVIRONMENTS).every(e => e.pilot && e.pilot.posture);
  checks.push({
    id: 'pilot',
    label: 'PILOT posture declared on mounted environments',
    status: pilotOk ? 'pass' : 'fail',
    detail: pilotOk ? Object.values(ENVIRONMENTS).map(e => e.id + ': ' + e.pilot.posture).join('; ') : 'missing PILOT posture'
  });

  /* 3 — sealed-copy check: pharmacology.html must hash exactly to its banked wordage. */
  const env = ENVIRONMENTS.pharmacology;
  try {
    const buf = await fetchBytes(env.entry);
    const hex = await sha256Hex(buf);
    const match = hex === env.sealedCopySha256;
    checks.push({
      id: 'sealed-copy',
      label: 'Sealed-copy check — ' + env.entry,
      status: match ? 'pass' : 'fail',
      detail: match
        ? 'sha256 matches the banked wordage'
        : 'DRIFT — rendered file no longer matches the sealed copy'
    });
  } catch (err) {
    checks.push({
      id: 'sealed-copy',
      label: 'Sealed-copy check — ' + env.entry,
      status: 'fail',
      detail: 'could not fetch the file (' + err.message + ') — serve the shell over HTTP so the guard can verify'
    });
  }

  /* 4 — frozen-file guard: read each frozen file, compare to its banked hash. */
  let frozenFailures = [];
  for (const [id, landed] of Object.entries(LANDED)) {
    try {
      const buf = await fetchBytes(landed.entry);
      const hex = await sha256Hex(buf);
      if (hex === landed.sha256) {
        checks.push({
          id: 'frozen:' + id, label: 'Frozen guard — ' + landed.entry,
          status: 'pass', detail: 'byte-identical to the sealed record'
        });
      } else {
        frozenFailures.push(landed.entry);
        checks.push({
          id: 'frozen:' + id, label: 'Frozen guard — ' + landed.entry,
          status: 'fail', detail: 'CHANGED — file no longer matches its sealed hash'
        });
      }
    } catch (err) {
      frozenFailures.push(landed.entry);
      checks.push({
        id: 'frozen:' + id, label: 'Frozen guard — ' + landed.entry,
        status: 'fail', detail: 'could not fetch the file (' + err.message + ')'
      });
    }
  }

  const pass = checks.every(c => c.status === 'pass');

  let failMessage = null;
  if (!pass) {
    const drift = checks.find(c => c.id === 'sealed-copy' && c.status === 'fail');
    if (drift && /DRIFT/.test(drift.detail)) {
      failMessage =
        'The engine did not boot. The pharmacology surface no longer matches the copy ' +
        'the Trinity sealed — its words have drifted. Nothing was mounted and nothing was changed. ' +
        'The sealed record is the truth; the drift is the fact. This is the honest-no.';
    } else if (frozenFailures.length) {
      failMessage =
        'The engine did not boot. A frozen file changed: ' + frozenFailures.join(', ') + '. ' +
        'Frozen means frozen — no edits without David\'s word. Nothing was mounted and nothing ' +
        'was changed. This is the honest-no.';
    } else {
      failMessage =
        'The engine did not boot. An integrity check failed and the shell will not mount anything ' +
        'it cannot verify. Nothing was changed. This is the honest-no.';
    }
  }

  return { pass, checks, failMessage };
}
