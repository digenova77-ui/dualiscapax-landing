/* DualisCapax Unity Engine — environment registry (2a)
 * Manifest per environment: id, entry file, sealed status, depth contract.
 * Frozen pages appear as "landed" entries — registered, never touched by the
 * engine's hands. Middle path, decided 2026-09-28 (Trinity unanimous
 * conditional): a registry listing is not an environment mount. These entries
 * are metadata only — id, entry path, sealed status, hash, depth contract —
 * held for the frozen-file guard (read + hash compare) and for threshold
 * dives: the conduit may carry the view to a frozen page's threshold, but the
 * camera never enters its visual field. Zero write contact, permanently: no
 * byte edits, no DOM edits, no copy edits, no WebGL-ification of frozen text;
 * any change to a frozen file → the engine refuses to boot (the honest-no).
 * In-page wrapping is NOT authorized: engine ambience behind frozen content,
 * or any visual change to an approved surface, needs David's explicit
 * per-page word. Reserved for David alone: whether wrapping counts as an edit
 * (experience boundary, not byte boundary).
 * Nothing here fetches, mutates, or wraps a frozen file. Registration only.
 */

'use strict';

export const ENGINE_PHASE = '2b';
export const ARCHITECTURE_SEAL_DATE = '2026-09-28';

/* Mountable environments — sealed artifacts the engine may mount into the shell. */
export const ENVIRONMENTS = {
  pharmacology: {
    id: 'pharmacology',
    kind: 'environment',
    entry: 'pharmacology.html',
    /* Trinity verdicts banked on the page: DCLM FAIL→fixed→sealed,
     * Iris PASS (binding conditions carried into research),
     * Twain² FAIL→fixed→sealed. Design sealed 2026-09-28. */
    status: 'sealed',
    sealNote: 'Trinity-passed design surface — Stage-1 only. Sealed 2026-09-28.',
    depthContract:
      'Stage-1 design surface only: seven sealed dimensions, ten-estate research slate ' +
      '(hypotheses, not findings), Stage-2 boundary wall. No estate research conducted; ' +
      'no grades assigned; zero estate data claims. Stage-2 NOT BUILT.',
    pilot: {
      posture: 'PILOT · RESEARCH',
      fetchNote: 'design snapshot 2026-09-28'
    },
    /* Banked sealed-copy hash. Drift refuses to boot (integrity.js). */
    sealedCopySha256:
      '7805d751f7ab12223a1b62fefefdc205fe70a2874e2352f2c5b5dd2e93b0c5a4',
    /* The five sealed artifacts of the environment interface (architecture §3). */
    interface: {
      dimensionSchema: 'seven sealed dimensions — design sealed 2026-09-28',
      estateSlate: 'ten-estate research slate — open hypotheses, not findings',
      boundaryContract: 'Stage-2 boundary wall — the ten closures, gate-held',
      fillContract: 'design phase — research pending; no fill executed',
      gradeRecord: 'no grades assigned — no estate research conducted'
    }
  }
};

/* Landed entries — the six frozen pages. Registry entries, not contact.
 * Middle path, decided 2026-09-28 (Trinity unanimous conditional verdict).
 * The manifest lists them so it is complete; the engine holds them only for
 * the frozen-file guard (read + hash compare). Zero write contact, permanently:
 * no byte edits, no DOM edits, no copy edits, no WebGL-ification of frozen text.
 * Any change to a frozen file → the engine refuses to boot (the honest-no).
 * Threshold dives authorized: the pipe-dive may carry users to and from a
 * frozen page, but the conduit ends at the page's threshold and never enters
 * the page's visual field. In-page wrapping is NOT authorized: engine ambience
 * behind frozen content, or any visual change to an approved surface, requires
 * David's explicit per-page word. Registry listing is not environment mount.
 * Reserved for David alone: whether wrapping counts as an edit
 * (experience boundary, not byte boundary). Architecture §8. */
export const LANDED = {
  water: {
    id: 'water', kind: 'landed-frozen', entry: 'water-countries.html',
    status: 'frozen', sealNote: 'frozen — zero write contact, permanently; no edits without David\'s explicit word',
    depthContract: 'metadata, not contact — middle path decided 2026-09-28; zero write contact, permanently; threshold dives authorized (conduit ends at the page threshold); in-page wrapping NOT authorized without David\'s explicit per-page word',
    sha256: '714b961af744e36bfce42f41e095a3b15412c8dd9465a6698201dffb9c8eff51'
  },
  energy: {
    id: 'energy', kind: 'landed-frozen', entry: 'energy-countries.html',
    status: 'frozen', sealNote: 'frozen — zero write contact, permanently; no edits without David\'s explicit word',
    depthContract: 'metadata, not contact — middle path decided 2026-09-28; zero write contact, permanently; threshold dives authorized (conduit ends at the page threshold); in-page wrapping NOT authorized without David\'s explicit per-page word',
    sha256: '77948d6e142db685513de2192521a95504bf78756f7bbe0ea88c39f55df978cc'
  },
  climate: {
    id: 'climate', kind: 'landed-frozen', entry: 'climate-countries.html',
    status: 'frozen', sealNote: 'frozen — zero write contact, permanently; no edits without David\'s explicit word',
    depthContract: 'metadata, not contact — middle path decided 2026-09-28; zero write contact, permanently; threshold dives authorized (conduit ends at the page threshold); in-page wrapping NOT authorized without David\'s explicit per-page word',
    sha256: 'b61cf27e5ec4628d9f4db9f5bd984c04ca37f459f28ca56501879fcfe38a4646'
  },
  'tree-sitemap': {
    id: 'tree-sitemap', kind: 'landed-frozen', entry: 'tree-sitemap.html',
    status: 'frozen', sealNote: 'frozen — zero write contact, permanently; no edits without David\'s explicit word',
    depthContract: 'metadata, not contact — middle path decided 2026-09-28; zero write contact, permanently; threshold dives authorized (conduit ends at the page threshold); in-page wrapping NOT authorized without David\'s explicit per-page word',
    sha256: '068e94c5c546cf1aee314cc6a57e76415c356c727036f4c8ce7363c6cbf2da4a'
  },
  food: {
    id: 'food', kind: 'landed-frozen', entry: 'food-countries.html',
    status: 'frozen', sealNote: 'frozen — zero write contact, permanently; no edits without David\'s explicit word',
    depthContract: 'metadata, not contact — middle path decided 2026-09-28; zero write contact, permanently; threshold dives authorized (conduit ends at the page threshold); in-page wrapping NOT authorized without David\'s explicit per-page word',
    sha256: '8e468767324c7b2ddb1a25cd3ab0ba3529b7556be18f71532523e7b536939215'
  },
  pandemic: {
    id: 'pandemic', kind: 'landed-frozen', entry: 'pandemic-countries.html',
    status: 'frozen', sealNote: 'frozen 2026-09-28 ~20:42 EDT — zero write contact, permanently; no edits without David\'s explicit word',
    depthContract: 'metadata, not contact — middle path decided 2026-09-28; zero write contact, permanently; threshold dives authorized (conduit ends at the page threshold); in-page wrapping NOT authorized without David\'s explicit per-page word',
    sha256: 'b25bfb470629ce203f63d4c971a1010dce59d0b8e4f199f20b2e0d925485c5dc'
  }
};

const ENV_FIELDS = ['id', 'kind', 'entry', 'status', 'sealNote', 'depthContract'];
const LANDED_FIELDS = ['id', 'kind', 'entry', 'status', 'sealNote', 'depthContract', 'sha256'];

function shapeOk(entry, fields) {
  return entry && fields.every(f => typeof entry[f] === 'string' && entry[f].length > 0);
}

/* Manifest validation: every registered entry carries a complete manifest.
 * A missing field earns a refusal to boot, never a pass. */
export function validateRegistry() {
  const problems = [];
  for (const [key, env] of Object.entries(ENVIRONMENTS)) {
    if (env.id !== key) problems.push(`environment key "${key}" does not match manifest id "${env.id}"`);
    if (!shapeOk(env, ENV_FIELDS)) problems.push(`environment "${key}" has an incomplete manifest`);
    if (env.status === 'sealed' && !env.sealedCopySha256)
      problems.push(`sealed environment "${key}" carries no sealed-copy hash`);
    if (env.status === 'sealed' && !(env.pilot && env.pilot.posture))
      problems.push(`sealed environment "${key}" declares no PILOT posture`);
  }
  for (const [key, landed] of Object.entries(LANDED)) {
    if (landed.id !== key) problems.push(`landed key "${key}" does not match manifest id "${landed.id}"`);
    if (!shapeOk(landed, LANDED_FIELDS)) problems.push(`landed entry "${key}" has an incomplete manifest`);
    if (landed.kind !== 'landed-frozen') problems.push(`landed entry "${key}" has a wrong kind`);
  }
  return { valid: problems.length === 0, problems };
}

export function getEnvironment(id) {
  return ENVIRONMENTS[id] || null;
}

export function getLanded(id) {
  return LANDED[id] || null;
}

export function listMounted() {
  return Object.keys(ENVIRONMENTS);
}

export function listLanded() {
  return Object.keys(LANDED);
}
