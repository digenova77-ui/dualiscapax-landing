/* DualisCapax Unity Engine — ExchangePacket draw-call gate (2b)
 * Closes 2a watch item #1.
 *
 * Every 3D draw call in the spatial layer consumes one ExchangePacket:
 *   { packet_id, pattern_kind, method, fence_level, screen_result }
 *
 * The gate is structural, not a test suite:
 *   - decorative/ambience kinds ('orb-field', 'conduit-ring', 'spatial-node',
 *     'plate'): the packet must be present, the kind known, the packet labeled
 *     decorative, and the packet must carry no data. These draws carry light
 *     only — geometry constants closed over by the draw function, never figures.
 *   - data pattern kinds ('data'): the draw call REFUSES unless
 *     screen_result === 'PASS' — a byte-exact string match on the label.
 *
 * The gate never decides PASS itself. It invents no screen methodology, no
 * cell_floor defaults, and no sufficiency criteria — those are DEFERRED.
 * Ship the gate, not the test suite. A future screen suite assigns the labels;
 * this module only enforces them.
 *
 * Refusals are returned, never thrown: a refused draw is a fact for the
 * caller to record, not an exception to catch.
 */

'use strict';

/* The only pattern kinds the gate knows. Anything else is refused. */
const KNOWN_KINDS = {
  'orb-field':    { carriesData: false },
  'conduit-ring': { carriesData: false },
  'spatial-node': { carriesData: false },
  'plate':        { carriesData: false },
  'data':         { carriesData: true }
};

const DECORATIVE_LABEL = 'DECORATIVE';
const PASS_LABEL = 'PASS';

function isNonEmptyString(v) {
  return typeof v === 'string' && v.length > 0;
}

/* Screen one packet. Returns { ok: true } or { ok: false, refusal }.
 * Pure: no DOM, no WebGL calls — testable in isolation. */
export function screenPacket(packet) {
  if (!packet || typeof packet !== 'object')
    return { ok: false, refusal: 'draw refused — no ExchangePacket was presented' };
  if (!isNonEmptyString(packet.packet_id))
    return { ok: false, refusal: 'draw refused — packet carries no packet_id' };
  const kind = KNOWN_KINDS[packet.pattern_kind];
  if (!kind)
    return { ok: false, refusal: 'draw refused — unknown pattern_kind "' + String(packet.pattern_kind) + '"' };
  if (!isNonEmptyString(packet.method) || !isNonEmptyString(packet.fence_level))
    return { ok: false, refusal: 'draw refused — packet "' + packet.packet_id + '" is incomplete (method + fence_level required)' };

  if (kind.carriesData) {
    /* Data draws refuse unless the screen label is exactly PASS. The gate
     * reads the label; it does not run the screen. */
    if (packet.screen_result === PASS_LABEL) return { ok: true };
    return {
      ok: false,
      refusal: 'draw refused — data pattern_kind without screen_result "PASS" ' +
        '(packet "' + packet.packet_id + '" carries "' + String(packet.screen_result) + '")'
    };
  }

  /* Decorative kinds: structurally validated — labeled decorative, no data aboard. */
  if (packet.screen_result !== DECORATIVE_LABEL)
    return {
      ok: false,
      refusal: 'draw refused — decorative kind "' + packet.pattern_kind + '" must be labeled ' +
        '"' + DECORATIVE_LABEL + '" (packet "' + packet.packet_id + '" carries "' +
        String(packet.screen_result) + '")'
    };
  if ('data' in packet && packet.data !== undefined)
    return {
      ok: false,
      refusal: 'draw refused — decorative packet "' + packet.packet_id + '" carries a data field; ' +
        'decorative draws carry no data'
    };
  return { ok: true };
}

/* Run a draw call through the gate.
 *   gatedDraw(packet, drawFn) → { drawn: true, refusal: null }
 *                            | { drawn: false, refusal: '<reason>' }
 * drawFn takes no arguments: decorative draws close over fixed geometry
 * constants; data draws, once they exist, receive their figures only after
 * the gate passes — never before. */
export function gatedDraw(packet, drawFn) {
  const s = screenPacket(packet);
  if (!s.ok) return { drawn: false, refusal: s.refusal };
  drawFn();
  return { drawn: true, refusal: null };
}

/* The pattern kinds the gate recognizes — for callers that must declare
 * their kind up front. Read-only. */
export function knownPatternKinds() {
  return Object.keys(KNOWN_KINDS);
}
