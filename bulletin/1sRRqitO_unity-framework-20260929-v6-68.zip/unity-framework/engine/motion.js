/* DualisCapax Unity Engine — transition choreography (2a/2b)
 * The pipe-dive: a fixed ~1s camera move. Calm, skippable, reduced-motion-safe.
 * Under prefers-reduced-motion the dive is a calm crossfade — correct behavior,
 * not fallback. Durations are fixed constants: the transition is a slot, not a variable.
 */

'use strict';

/* Fixed ~1s camera move — the dive duration is architecture, not tunable per call. */
export const DIVE_MS = 1000;
export const CROSSFADE_MS = 320;

import { getLanded } from './registry.js';

/* 2b — the conduit's dolly driver. The conduit (conduit.js) registers its
 * driver here. When a driver is registered AND motion is allowed, dives run
 * as the 3D camera move. Reduced-motion keeps the calm crossfade (correct,
 * not fallback); with no driver the 2a CSS veil path stays. The CSS path is
 * never removed. */
let dollyDriver = null;
export function setDollyDriver(driver) { dollyDriver = driver; }
export function getDollyDriver() { return dollyDriver; }

export function isReducedMotion() {
  return typeof window !== 'undefined' &&
    window.matchMedia &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

/* Ensure the one-time transition stylesheet exists (no reliance on shell CSS). */
function ensureStyles() {
  if (document.getElementById('engine-motion-styles')) return;
  const s = document.createElement('style');
  s.id = 'engine-motion-styles';
  s.textContent =
    '.eg-dive-veil{position:fixed;inset:0;z-index:90;pointer-events:none;opacity:0;' +
    'background:radial-gradient(ellipse at 50% 60%,rgba(0,245,212,.28),rgba(4,6,11,.96) 74%);' +
    'transition:opacity .45s ease;}' +
    '.eg-dive-veil.on{opacity:1;pointer-events:all;}' +
    '.eg-dive-in{animation:egDiveIn ' + DIVE_MS + 'ms cubic-bezier(.2,.7,.2,1) both;}' +
    '@keyframes egDiveIn{from{opacity:0;transform:scale(.965) translateY(18px)}' +
    'to{opacity:1;transform:none}}' +
    '.eg-crossfade{transition:opacity ' + CROSSFADE_MS + 'ms ease;}' +
    '@media (prefers-reduced-motion: reduce){' +
    '.eg-dive-in{animation:none;}' +
    '.eg-dive-veil{display:none;}}';
  document.head.appendChild(s);
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/* Threshold dive: the conduit carries the view to a FROZEN page's threshold
 * and stops there. Interval 3 — the middle path, decided 2026-09-28 (Trinity
 * unanimous conditional). Registry entries live at boot; the threshold dive
 * resolves the id to metadata only.
 *
 * The boundary: the dive animation ends at the page's threshold. The frozen
 * page then loads as its own document — a full navigation out of the shell —
 * it is never mounted in the shell, never framed, never wrapped, never
 * touched by the engine's DOM. The camera never enters the page's visual
 * field. Zero file contact: no fetch of the page's contents here (the
 * frozen-file guard runs at boot), no DOM touch of its document.
 *
 * The return dive (frozen page back to the shell) belongs to the frozen
 * page's own navigation. The engine has zero contact with frozen pages and
 * choreographs nothing inside them — an honest boundary, not a missing
 * feature.
 *
 * Fail-closed: an unknown id, or an id that is not a landed-frozen entry,
 * refuses — no move, no navigation. This handle only exists after the boot
 * guard passed, so every dive starts from a verified shell. */
export function diveToThreshold(landedId) {
  if (typeof window === 'undefined' || !window.location)
    return Promise.resolve({ ok: false, error: 'dive refused — no window to navigate from' });
  const landed = getLanded(landedId);
  if (!landed || landed.kind !== 'landed-frozen')
    return Promise.resolve({
      ok: false,
      error: 'dive refused — "' + String(landedId) + '" is not a registered landed-frozen entry'
    });
  /* Registry metadata only: the entry path resolved against the shell's own
   * location. No contact with the frozen file — just where it lives. */
  const href = new URL(landed.entry, window.location.href).href;
  return thresholdMove().then(() => {
    window.location.assign(href);
    return { ok: true, id: landed.id, entry: landed.entry };
  });
}

/* The move to the threshold: the same calm dive the shell already knows —
 * the conduit's ~1s camera move through its seven rings when a driver is
 * registered and motion is allowed (rings drawn through the ExchangePacket
 * gate, ambience.js); a calm crossfade under reduced-motion (correct, not
 * fallback); the 2a CSS veil otherwise. The move carries light only — no
 * readable text, no figures. It ends at the threshold, not inside. */
function thresholdMove() {
  ensureStyles();
  if (isReducedMotion()) {
    /* Calm crossfade — static and calm is the correct 2a behavior. */
    return wait(CROSSFADE_MS);
  }
  if (dollyDriver) return dollyDriver.dollyIn();
  const veil = document.createElement('div');
  veil.className = 'eg-dive-veil';
  veil.setAttribute('aria-hidden', 'true');
  document.body.appendChild(veil);
  void veil.offsetWidth;
  veil.classList.add('on');
  return wait(450).then(() => {
    veil.classList.remove('on');
    return wait(500);
  }).then(() => veil.remove());
}
/* Dive INTO an element: the view travels forward through the veil into it.
 * 2b: with a registered dolly driver and motion allowed, the dive is the
 * conduit's ~1s camera move instead of the CSS veil. */
export function diveIn(el) {
  ensureStyles();
  if (!el) return Promise.resolve();
  if (isReducedMotion()) {
    /* Calm crossfade — static plates and calm fades are the correct 2a behavior. */
    el.classList.add('eg-crossfade');
    el.style.opacity = '0';
    requestAnimationFrame(() => requestAnimationFrame(() => { el.style.opacity = '1'; }));
    return wait(CROSSFADE_MS).then(() => { el.classList.remove('eg-crossfade'); el.style.opacity = ''; });
  }
  if (dollyDriver) return dollyDriver.dollyIn();
  const veil = document.createElement('div');
  veil.className = 'eg-dive-veil';
  veil.setAttribute('aria-hidden', 'true');
  document.body.appendChild(veil);
  void veil.offsetWidth;
  veil.classList.add('on');
  return wait(450).then(() => {
    el.classList.remove('eg-dive-in');
    void el.offsetWidth;
    el.classList.add('eg-dive-in');
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    veil.classList.remove('on');
    return wait(500);
  }).then(() => veil.remove());
}

/* Dive OUT of an element: the view lifts back out to the shell.
 * 2b: with a registered dolly driver and motion allowed, the dive-out is the
 * conduit's recede instead of the CSS veil. */
export function diveOut(el) {
  ensureStyles();
  if (!el) return Promise.resolve();
  if (isReducedMotion()) {
    el.classList.add('eg-crossfade');
    el.style.opacity = '0';
    return wait(CROSSFADE_MS).then(() => { el.classList.remove('eg-crossfade'); el.style.opacity = ''; });
  }
  if (dollyDriver) return dollyDriver.dollyOut();
  const veil = document.createElement('div');
  veil.className = 'eg-dive-veil';
  veil.setAttribute('aria-hidden', 'true');
  document.body.appendChild(veil);
  void veil.offsetWidth;
  veil.classList.add('on');
  return wait(450).then(() => {
    el.classList.remove('eg-dive-in');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    veil.classList.remove('on');
    return wait(500);
  }).then(() => veil.remove());
}
