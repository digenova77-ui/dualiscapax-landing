/* DualisCapax Unity Engine — conduit dolly driver (2b)
 * The pipe-dive as a real ~1s camera move: a tunnel of calm rings the camera
 * dollies forward through on dive-in and recedes through on dive-out.
 * One calm move, fixed at DIVE_MS — the duration is architecture, not tunable.
 *
 * The driver registers itself with motion.js via motion.setDollyDriver().
 * motion.js runs the 3D dolly only when a driver is registered AND motion is
 * allowed; under prefers-reduced-motion the dive stays a calm crossfade
 * (correct behavior, not fallback), and with no driver the 2a CSS veil path
 * stays. Nothing here touches the CSS path.
 *
 * DOM-first always: the conduit carries light only — no readable text, no
 * figures. Its rings are drawn through the ExchangePacket gate in ambience.js.
 */

'use strict';

import { setDollyDriver, DIVE_MS } from './motion.js';

function easeInOut(t) {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}

/* One dolly run: camera progress from `from` to `to` over exactly DIVE_MS,
 * eased. dive-in goes 0 → 1 (forward through the rings); dive-out goes
 * 1 → 0 (recede). Resolves when the move completes. */
function runDolly(conduit, from, to) {
  return new Promise(resolve => {
    conduit.begin();
    const start = performance.now();
    function frame(now) {
      const t = Math.min(1, (now - start) / DIVE_MS);
      conduit.frame(from + (to - from) * easeInOut(t));
      if (t < 1) {
        requestAnimationFrame(frame);
      } else {
        conduit.end();
        resolve();
      }
    }
    requestAnimationFrame(frame);
  });
}

/* Build the driver from an ambience handle and register it with motion.js.
 * Returns the driver, or null when the ambience layer has no conduit
 * (the 2D-plate path) — in which case no driver is registered and the CSS
 * veil path carries the dives, as in 2a. */
export function createConduit(ambience) {
  if (!ambience || !ambience.conduit) return null;
  const conduit = ambience.conduit;
  const driver = {
    dollyIn() { return runDolly(conduit, 0, 1); },
    dollyOut() {
      /* The view lifts back out to the shell while the rings recede. */
      if (typeof window !== 'undefined' && window.scrollTo)
        window.scrollTo({ top: 0, behavior: 'smooth' });
      return runDolly(conduit, 1, 0);
    }
  };
  setDollyDriver(driver);
  return driver;
}
