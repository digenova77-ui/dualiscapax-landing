/* DualisCapax Unity Engine — ambience (2a) + spatial layer (2b)
 * The one WebGL scene: the void, an orb field, and — in 2b — the spatial
 * layer: the shell's constellation, environment plates, and the conduit
 * (a tunnel of calm rings the camera dollies through on dive-in/out).
 * One job: lighting. It carries no data, encodes no figures, and is never
 * instrumentation — ambience lives in lighting and glass only. Declared on
 * the canvas as ambience.
 *
 * DOM-first, always: no readable text inside WebGL. The 3D layer is the
 * environment layer behind the DOM, never the content layer.
 *
 * Every draw call in this scene runs through the ExchangePacket gate
 * (packet.js): decorative kinds are structurally labeled and carry no data;
 * a data draw without screen_result "PASS" refuses. 2b draws are decorative.
 *
 * Reduced-motion: a single static frame, re-rendered when the spatial layer
 * changes — correct behavior, not fallback. No WebGL: a static 2D plate.
 */

'use strict';

import { gatedDraw } from './packet.js';

const VOID = [0x07 / 255, 0x08 / 255, 0x0c / 255, 1.0];

/* Fixed, seeded orb field — deterministic, not random per frame. */
const ORBS = [
  // [x, y, z (depth 0.2 near → 1.0 far), radius px@720p, r, g, b, drift speed, phase]
  [-0.62,  0.34, 0.55, 34, 0x00/255, 0xf5/255, 0xd4/255, 0.05, 0.0],
  [ 0.55,  0.52, 0.80, 52, 0xa8/255, 0x55/255, 0xf7/255, 0.03, 1.7],
  [ 0.10, -0.42, 0.35, 26, 0x14/255, 0xb8/255, 0xa6/255, 0.07, 3.1],
  [-0.20, -0.10, 0.95, 70, 0xa8/255, 0x55/255, 0xf7/255, 0.02, 4.4],
  [ 0.78, -0.30, 0.60, 30, 0xe8/255, 0xc3/255, 0x6a/255, 0.04, 2.2],
  [-0.85, -0.45, 0.75, 44, 0x14/255, 0xb8/255, 0xa6/255, 0.03, 5.5],
  [ 0.30,  0.05, 0.25, 22, 0x00/255, 0xf5/255, 0xd4/255, 0.08, 0.9],
  [-0.05,  0.62, 0.70, 40, 0xa8/255, 0x55/255, 0xf7/255, 0.03, 3.8],
  [ 0.90,  0.15, 0.90, 60, 0x00/255, 0xf5/255, 0xd4/255, 0.02, 6.1],
  [-0.42,  0.78, 0.45, 28, 0x14/255, 0xb8/255, 0xa6/255, 0.06, 1.2],
  [ 0.42, -0.72, 0.65, 36, 0xa8/255, 0x55/255, 0xf7/255, 0.04, 5.0],
  [-0.95,  0.05, 0.50, 30, 0xe8/255, 0xc3/255, 0x6a/255, 0.05, 2.7]
];

/* Decorative packets — structural labels. These draws carry light only:
 * seeded geometry constants, never figures. No screen was run; the
 * "DECORATIVE" label says what the draw is, not that it passed a test. */
const ORB_PACKET = Object.freeze({
  packet_id: 'pkt-amb-orb-field-001',
  pattern_kind: 'orb-field',
  method: 'seeded-point-field',
  fence_level: 'AMBIENT',
  screen_result: 'DECORATIVE'
});

const CONDUIT_PACKET = Object.freeze({
  packet_id: 'pkt-amb-conduit-rings-001',
  pattern_kind: 'conduit-ring',
  method: 'line-loop-tunnel',
  fence_level: 'AMBIENT',
  screen_result: 'DECORATIVE'
});

const VERT = `
attribute vec2 aPos;
attribute vec3 aColor;
attribute float aSize;
varying vec3 vColor;
void main(){
  gl_Position = vec4(aPos, 0.0, 1.0);
  gl_PointSize = aSize;
  vColor = aColor;
}`;

const FRAG = `
precision mediump float;
varying vec3 vColor;
void main(){
  vec2 c = gl_PointCoord - vec2(0.5);
  float d = length(c) * 2.0;
  float core = smoothstep(1.0, 0.0, d);
  float halo = smoothstep(1.0, 0.35, d) * 0.35;
  float a = core * core * 0.85 + halo * 0.5;
  if (a < 0.004) discard;
  gl_FragColor = vec4(vColor, a);
}`;

/* The conduit: seven calm rings in a simple perspective tunnel. The camera
 * dollies forward through them (dive-in) and recedes (dive-out). Rings fade
 * as the camera passes — the tunnel feel with no sway, no hurry. */
const RING_VERT = `
attribute vec2 aXY;
attribute float aRing;
attribute vec3 aColor;
uniform float uCamZ;
uniform float uFocal;
uniform float uAspect;
varying vec3 vColor;
varying float vAlpha;
void main(){
  float ringZ = -(3.0 + aRing * 2.0);
  float z = uCamZ - ringZ;
  float s = uFocal / max(z, 0.02);
  vec2 p = aXY * 2.0;
  p.x /= uAspect;
  gl_Position = vec4(p * s, 0.0, 1.0);
  vColor = aColor;
  float nearFade = smoothstep(0.0, 1.4, z);
  float farFade = 1.0 - smoothstep(13.0, 17.0, z);
  vAlpha = nearFade * farFade;
}`;

const RING_FRAG = `
precision mediump float;
varying vec3 vColor;
varying float vAlpha;
void main(){
  if (vAlpha < 0.004) discard;
  gl_FragColor = vec4(vColor, vAlpha * 0.42);
}`;

const RING_COUNT = 7;
const RING_SEGMENTS = 64;

function makeShader(gl, type, src) {
  const s = gl.createShader(type);
  gl.shaderSource(s, src);
  gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) return null;
  return s;
}

function makeProgram(gl, vertSrc, fragSrc) {
  const vs = makeShader(gl, gl.VERTEX_SHADER, vertSrc);
  const fs = makeShader(gl, gl.FRAGMENT_SHADER, fragSrc);
  if (!vs || !fs) return null;
  const prog = gl.createProgram();
  gl.attachShader(prog, vs);
  gl.attachShader(prog, fs);
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return null;
  return prog;
}

/* Honest fallback: a static plate drawn on 2D canvas — still calm, still
 * honest. Includes the spatial layer's points so the constellation reads
 * even without WebGL. */
function drawStaticPlate(canvas, layers) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const w = canvas.width = canvas.offsetWidth || 360;
  const h = canvas.height = canvas.offsetHeight || 640;
  ctx.fillStyle = '#07080c';
  ctx.fillRect(0, 0, w, h);
  const dot = (x, y, r, style) => {
    const cx = (x * 0.5 + 0.5) * w;
    const cy = (y * 0.5 + 0.5) * h;
    const rad = r * (h / 720);
    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, rad);
    g.addColorStop(0, style);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(cx, cy, rad, 0, Math.PI * 2);
    ctx.fill();
  };
  for (const [x, y, , r] of ORBS) dot(x, y, r, 'rgba(0,245,212,0.20)');
  for (const layer of layers) {
    for (const p of layer.points) {
      const a = Math.round(Math.max(p.r, p.g, p.b) * 255);
      dot(p.x, p.y, p.size, 'rgba(' +
        Math.round(p.r * 255) + ',' + Math.round(p.g * 255) + ',' +
        Math.round(p.b * 255) + ',' + (a / 255 * 0.8).toFixed(3) + ')');
    }
  }
}

/* Mount the ambience scene on a canvas.
 * Returns { destroy(), webgl, conduit, addPointLayer(), removePointLayer() }.
 * Respects prefers-reduced-motion by construction. */
export function mountAmbience(canvas) {
  const reduced =
    typeof window !== 'undefined' &&
    window.matchMedia &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const gl = canvas.getContext('webgl', { alpha: false, antialias: true })
          || canvas.getContext('experimental-webgl');

  /* ---- No WebGL: the static 2D plate. Layers redraw it on change. ---- */
  if (!gl) {
    const layers = [];
    const redraw = () => drawStaticPlate(canvas, layers);
    redraw();
    return {
      destroy() {},
      webgl: false,
      conduit: null, /* no dolly driver without WebGL — the CSS path carries dives */
      addPointLayer(layer) {
        const i = layers.findIndex(l => l.id === layer.id);
        if (i >= 0) layers[i] = layer; else layers.push(layer);
        redraw();
      },
      removePointLayer(id) {
        const i = layers.findIndex(l => l.id === id);
        if (i >= 0) layers.splice(i, 1);
        redraw();
      }
    };
  }

  const pointProg = makeProgram(gl, VERT, FRAG);
  const ringProg = makeProgram(gl, RING_VERT, RING_FRAG);
  if (!pointProg || !ringProg) {
    const layers = [];
    const redraw = () => drawStaticPlate(canvas, layers);
    redraw();
    return {
      destroy() {},
      webgl: false,
      conduit: null,
      addPointLayer(layer) {
        const i = layers.findIndex(l => l.id === layer.id);
        if (i >= 0) layers[i] = layer; else layers.push(layer);
        redraw();
      },
      removePointLayer(id) {
        const i = layers.findIndex(l => l.id === id);
        if (i >= 0) layers.splice(i, 1);
        redraw();
      }
    };
  }

  /* ---- Point program attributes ---- */
  const pPos = gl.getAttribLocation(pointProg, 'aPos');
  const pCol = gl.getAttribLocation(pointProg, 'aColor');
  const pSiz = gl.getAttribLocation(pointProg, 'aSize');

  /* Orb field buffers: colors static, positions/sizes per frame. */
  const n = ORBS.length;
  const orbPosBuf = gl.createBuffer();
  const orbSizBuf = gl.createBuffer();
  const orbColBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, orbColBuf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(ORBS.flatMap(o => [o[4], o[5], o[6]])), gl.STATIC_DRAW);

  /* ---- Ring program: attributes, uniforms, static buffers ---- */
  const rXY = gl.getAttribLocation(ringProg, 'aXY');
  const rRing = gl.getAttribLocation(ringProg, 'aRing');
  const rCol = gl.getAttribLocation(ringProg, 'aColor');
  const uCamZ = gl.getUniformLocation(ringProg, 'uCamZ');
  const uFocal = gl.getUniformLocation(ringProg, 'uFocal');
  const uAspect = gl.getUniformLocation(ringProg, 'uAspect');

  const ringXY = new Float32Array(RING_COUNT * RING_SEGMENTS * 2);
  const ringIdx = new Float32Array(RING_COUNT * RING_SEGMENTS);
  const ringCol = new Float32Array(RING_COUNT * RING_SEGMENTS * 3);
  const TEAL = [0.0, 0.55, 0.48], PURPLE = [0.38, 0.22, 0.55];
  for (let i = 0; i < RING_COUNT; i++) {
    const c = i % 2 === 0 ? TEAL : PURPLE;
    for (let s = 0; s < RING_SEGMENTS; s++) {
      const k = i * RING_SEGMENTS + s;
      const a = (s / RING_SEGMENTS) * Math.PI * 2;
      ringXY[k * 2] = Math.cos(a);
      ringXY[k * 2 + 1] = Math.sin(a);
      ringIdx[k] = i;
      ringCol[k * 3] = c[0]; ringCol[k * 3 + 1] = c[1]; ringCol[k * 3 + 2] = c[2];
    }
  }
  const ringXYBuf = gl.createBuffer();
  const ringIdxBuf = gl.createBuffer();
  const ringColBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, ringXYBuf);
  gl.bufferData(gl.ARRAY_BUFFER, ringXY, gl.STATIC_DRAW);
  gl.bindBuffer(gl.ARRAY_BUFFER, ringIdxBuf);
  gl.bufferData(gl.ARRAY_BUFFER, ringIdx, gl.STATIC_DRAW);
  gl.bindBuffer(gl.ARRAY_BUFFER, ringColBuf);
  gl.bufferData(gl.ARRAY_BUFFER, ringCol, gl.STATIC_DRAW);

  /* ---- Spatial layers (constellation, plates) — static point clouds ---- */
  const layers = new Map();

  function buildLayer(layer) {
    const pts = layer.points;
    const rec = {
      id: layer.id,
      packet: layer.packet,
      n: pts.length,
      posBuf: gl.createBuffer(),
      colBuf: gl.createBuffer(),
      sizBuf: gl.createBuffer()
    };
    const pos = new Float32Array(pts.length * 2);
    const col = new Float32Array(pts.length * 3);
    const siz = new Float32Array(pts.length);
    for (let i = 0; i < pts.length; i++) {
      pos[i * 2] = pts[i].x; pos[i * 2 + 1] = pts[i].y;
      col[i * 3] = pts[i].r; col[i * 3 + 1] = pts[i].g; col[i * 3 + 2] = pts[i].b;
      siz[i] = pts[i].size;
    }
    gl.bindBuffer(gl.ARRAY_BUFFER, rec.posBuf);
    gl.bufferData(gl.ARRAY_BUFFER, pos, gl.STATIC_DRAW);
    gl.bindBuffer(gl.ARRAY_BUFFER, rec.colBuf);
    gl.bufferData(gl.ARRAY_BUFFER, col, gl.STATIC_DRAW);
    gl.bindBuffer(gl.ARRAY_BUFFER, rec.sizBuf);
    gl.bufferData(gl.ARRAY_BUFFER, siz, gl.STATIC_DRAW);
    return rec;
  }

  /* ---- Conduit state ---- */
  let conduitActive = false;
  let conduitP = 0;

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(1, Math.round(canvas.clientWidth * dpr));
    const h = Math.max(1, Math.round(canvas.clientHeight * dpr));
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
    gl.viewport(0, 0, w, h);
  }

  function bindPointCloud(posBuf, colBuf, sizBuf) {
    gl.bindBuffer(gl.ARRAY_BUFFER, posBuf);
    gl.enableVertexAttribArray(pPos);
    gl.vertexAttribPointer(pPos, 2, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, colBuf);
    gl.enableVertexAttribArray(pCol);
    gl.vertexAttribPointer(pCol, 3, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, sizBuf);
    gl.enableVertexAttribArray(pSiz);
    gl.vertexAttribPointer(pSiz, 1, gl.FLOAT, false, 0, 0);
  }

  function drawOrbField(t) {
    gl.useProgram(pointProg);
    const hPx = canvas.height;
    const positions = new Float32Array(n * 2);
    const sizes = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const o = ORBS[i];
      /* Calm drift: slow sinusoidal wander on a fixed field. Static at t=0
       * when reduced-motion is on (single frame). */
      const dx = 0.035 * Math.sin(t * o[7] + o[8]);
      const dy = 0.030 * Math.cos(t * o[7] * 0.8 + o[8] * 1.3);
      positions[i * 2] = o[0] + dx;
      positions[i * 2 + 1] = o[1] + dy;
      sizes[i] = o[3] * (hPx / 720) * 2.0;
    }
    gl.bindBuffer(gl.ARRAY_BUFFER, orbPosBuf);
    gl.bufferData(gl.ARRAY_BUFFER, positions, gl.DYNAMIC_DRAW);
    gl.bindBuffer(gl.ARRAY_BUFFER, orbSizBuf);
    gl.bufferData(gl.ARRAY_BUFFER, sizes, gl.DYNAMIC_DRAW);
    bindPointCloud(orbPosBuf, orbColBuf, orbSizBuf);
    gl.drawArrays(gl.POINTS, 0, n);
  }

  function drawLayer(rec) {
    gl.useProgram(pointProg);
    bindPointCloud(rec.posBuf, rec.colBuf, rec.sizBuf);
    gl.drawArrays(gl.POINTS, 0, rec.n);
  }

  function drawRings() {
    gl.useProgram(ringProg);
    const camZ = conduitP * -17.0;
    gl.uniform1f(uCamZ, camZ);
    gl.uniform1f(uFocal, 1.6);
    gl.uniform1f(uAspect, canvas.width / Math.max(1, canvas.height));
    gl.bindBuffer(gl.ARRAY_BUFFER, ringXYBuf);
    gl.enableVertexAttribArray(rXY);
    gl.vertexAttribPointer(rXY, 2, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, ringIdxBuf);
    gl.enableVertexAttribArray(rRing);
    gl.vertexAttribPointer(rRing, 1, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, ringColBuf);
    gl.enableVertexAttribArray(rCol);
    gl.vertexAttribPointer(rCol, 3, gl.FLOAT, false, 0, 0);
    for (let i = 0; i < RING_COUNT; i++) {
      gl.drawArrays(gl.LINE_LOOP, i * RING_SEGMENTS, RING_SEGMENTS);
    }
  }

  function render(t) {
    resize();
    gl.clearColor(VOID[0], VOID[1], VOID[2], VOID[3]);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.disable(gl.DEPTH_TEST);

    /* Every draw call through the gate. A refused draw simply does not draw. */
    gatedDraw(ORB_PACKET, () => drawOrbField(t));
    for (const rec of layers.values()) {
      gatedDraw(rec.packet, () => drawLayer(rec));
    }
    if (conduitActive) {
      gatedDraw(CONDUIT_PACKET, drawRings);
    }
  }

  let raf = 0;
  let dead = false;

  if (reduced) {
    /* Correct behavior, not fallback: one still frame. Re-rendered when the
     * spatial layer changes so static plates always show the constellation. */
    render(0);
  } else {
    const loop = ms => {
      if (dead) return;
      render(ms / 1000);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
  }

  function restatic() {
    if (reduced && !dead) render(0);
  }

  return {
    destroy() {
      dead = true;
      if (raf) cancelAnimationFrame(raf);
      layers.clear();
      const lose = gl.getExtension('WEBGL_lose_context');
      if (lose) lose.loseContext();
    },
    webgl: true,
    /* The conduit: driven by conduit.js (the dolly driver). begin() opens the
     * tunnel, frame(p) moves the camera (0 outside → 1 through), end() closes. */
    conduit: {
      begin() { conduitActive = true; },
      frame(p) { conduitP = Math.min(1, Math.max(0, p)); },
      end() { conduitActive = false; }
    },
    addPointLayer(layer) {
      layers.set(layer.id, buildLayer(layer));
      restatic();
    },
    removePointLayer(id) {
      layers.delete(id);
      restatic();
    }
  };
}
