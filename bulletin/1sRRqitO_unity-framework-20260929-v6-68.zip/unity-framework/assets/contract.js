/* Soil-first: the contract opens before the data. Dismissible, honest, calm.
   Per-page copy arrives via window.CONTRACT. ?nocontract=1 skips (for QA). */
(function(){
  if(/[?&]nocontract=1/.test(location.search)) return;
  var C=window.CONTRACT||{kicker:'THE CONTRACT',title:'Why this page exists',
    why:'Why before what.',law:'NO_FORCE · HOST_SAFE · CLEANUP_FIRST'};
  document.addEventListener('DOMContentLoaded',function(){
    var veil=document.createElement('div');
    veil.className='contract-veil';
    veil.setAttribute('role','dialog');veil.setAttribute('aria-modal','true');
    veil.setAttribute('aria-label',C.title);
    var card=document.createElement('div');card.className='contract-card';
    var k=document.createElement('p');k.className='contract-kicker';k.textContent=C.kicker;
    var t=document.createElement('h2');t.className='contract-title';t.textContent=C.title;
    var w=document.createElement('p');w.className='contract-why';w.textContent=C.why;
    var l=document.createElement('p');l.className='contract-law';l.textContent=C.law;
    var btn=document.createElement('button');btn.className='contract-enter';
    btn.type='button';btn.textContent='Enter';
    card.appendChild(k);card.appendChild(t);card.appendChild(w);card.appendChild(l);card.appendChild(btn);
    veil.appendChild(card);
    var closed=false;
    function close(){
      if(closed)return;closed=true;
      veil.classList.remove('show');document.body.style.overflow='';
      setTimeout(function(){if(veil.parentNode)veil.parentNode.removeChild(veil);},600);
    }
    btn.addEventListener('click',close);
    veil.addEventListener('click',function(e){if(e.target===veil)close();});
    function onKey(e){if(e.key==='Escape'){close();document.removeEventListener('keydown',onKey);}}
    document.addEventListener('keydown',onKey);
    document.body.appendChild(veil);
    document.body.style.overflow='hidden';
    requestAnimationFrame(function(){requestAnimationFrame(function(){veil.classList.add('show');});});
    btn.focus();
  });
})();
