# Whole-Site Assembly Notes — September 28, 2026

## What this is
One coherent navigable site unifying the RTE universe: the Core hub + the six suite rooms + the seven new drafts. Built at ~/workspace/whole-site-build/ under the authority register and the execution path (the gate is the gate; the writer's hands implement the Trinity's vote).

## Structure
- `index.html` — the unified hub: RTE rooms (6) + new wings (7), main-site naming section, seal footer.
- `health/`, `teach/`, `ice/`, `golf/`, `hospitality/`, `financials/` — the six suite rooms, copied unchanged from rte-suite-build (gated, repaired, audited).
- `healthcare-taxpayer/`, `education-taxpayer/`, `access-seat/`, `canada-drilldown/`, `binding-rite/`, `email-invocation/`, `founder-board/` — the seven drafts, each with its bundled registry snapshot in `assets/`.
- `assets/data/` — the suite rooms' bundled snapshots.

## Decisions made under the new law (pending the Trinity's statements)
- Hub footer formula updated to the new authority register: "Drafts stay drafts until the Trinity's vote lands them — publishing upgrades no claim." (The old "until David says they land" contradicts the register; the consultation D1 will rule the rite's own formula.)
- Founder board labeled "Concept · draft" — it is a concept lander, not a room.
- Taxpayer ledgers labeled "Draft · pilot mode" — their PILOT MODE boundaries are part of the label.
- Frozen main-site pages (landing constellation, Fractals 01–06, RTE Desk, Doctrine) are named, not duplicated, not linked by fabricated URL.
- No rooms were altered for back-links yet — E1 is before the Trinity.
- No draft was promoted, renamed, or re-labeled beyond its own verdict.

## What the assembly raises (to the consultation mechanism)
- E1 back-links, E3 seal-carries, G3 suite-v2/board-flow, D1 rite footer formula — all already in the open-question inventory; the assembly implements whatever the statements direct.
- hockey.jsonl remains excluded from every shipped surface (named minors; standing law).

## Verification so far
- All 13 pages present; every relative href/src/fetch target resolves inside the tree; no absolute paths, no dead controls.
- Bundled snapshots byte-verified against their source registries at copy time (the drafts' own build reports certify this; re-verified in the Phase 3 gate).
