# Figure Provenance — whole-site-build, September 28, 2026

How every room's figures reach the page. Recorded so the chain is written down inside the assembly (DCLM condition C6, Phase-3 gate).

## Rooms that read a registry (bundled snapshot, byte-identical to ~/workspace/data/registry/)

- **RTE-GOLF** — fetches `golf/golf.snapshot.jsonl` (fail-closed to honest 0:1).
- **RTE-HOSPITALITY** — fetches `assets/data/hospitality.jsonl` (fail-closed to honest 0:1).
- **RTE-FINANCIALS** — reads its embedded snapshot of `assets/data/financials.jsonl` (fail-closed to honest 0:1).
- **Healthcare taxpayer** — fetches `healthcare-taxpayer/assets/healthcare-taxpayer.jsonl`; embedded JS snapshot as fallback.
- **Education taxpayer** — fetches `education-taxpayer/assets/education-taxpayer.jsonl`; embedded JS snapshot as fallback.
- **Access seat** — fetches `access-seat/assets/access-seat.jsonl`; reserved states parse from data.
- **Canada drill-down** — fetches `canada-drilldown/assets/canada-drilldown.jsonl`.
- **Binding rite** — fetches `binding-rite/assets/bindings.jsonl` (0:1 — empty by design).
- **Email invocation** — fetches `email-invocation/assets/email-invocation.jsonl` (0:1 — empty by design).

The registry is the freshness authority in every case; snapshots re-sync at build/publish.

## Rooms whose figures are fixed instrument slots (no registry file)

- **RTE-HEALTH** — figures inline (EMPIRICAL N=60 study; PILOT MODE modeled results labeled "modeled"). Provenance chain: the suite build of September 28, 2026 — built from David's banked RTE-Health denominators (65,000 annual valuation basis; 144,200 corporation-wide volume; N=60 study), umpire-gated (DCLM CONDITIONAL → repaired; Iris SOUND; Twain² CONDITIONAL → repaired), and handed to FACTORY_BULLETIN_BOARD as `rte-suite-20260928.zip`. Approved · published · living.
- **RTE-TEACH** — figures inline (STORYBOARD DRAFT; three reserved slots awaiting David's deterministic extractor output). Provenance chain: the suite build of September 28, 2026 — weakest-to-strongest rebuild, umpire verdict 3–0 SOUND, zipped to the bulletin board as above. Draft · published · living.
- **RTE-ICE** — figures inline (STORYBOARD DRAFT; tournament dates Fri Nov 06–Sun Nov 08, 2026 per the Kitchener host listing; Quinte participation not confirmed). Provenance chain: the suite build of September 28, 2026 — umpire verdict 4–0 SOUND with corrections confirmed, zipped to the bulletin board as above. Draft · published · living.

These three rooms carry no registry file by design: their figures are fixed slots from the gated suite build, not volatile fill data. If a fill pass later begins for teach/health domains, the rooms read their domain files and the provenance moves to the registry section above.

## Deliberately excluded

- `hockey.jsonl` (named minors) is excluded from every shipped surface per Trinity ruling CONSULT-0028. The registry holds it lawfully; no page, snapshot, or ZIP in this assembly renders it.
