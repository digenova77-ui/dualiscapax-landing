# ED-VERDICT-20260929-BASE3D-R8-V1
## Base 3D Rotation 8 — Sections 13 (child welfare) + 14 (courts)
**Self-review** by the building worker (rotation coordinator r14's depth-2
worker). This is not independent review — the same hands that built the
sections checked them. David's eyes remain final QA.

**Disposition: PASS-WITH-NOTES** (3 bounded notes below).

**Scope:** two DRAFT-only anchor sections under
`~/workspace/website-engineering-layer/drafts/base3d/`:
- Section 13 — Child-welfare anchors, Wave 12, station x = −176
- Section 14 — Courts anchors, Wave 13, station x = −192
No seal. No deployment.

---

## 1. DCLM — architecture / controls

- **Binder law holds.** Every figure bound carries value + label + source +
  display; `bindFigure` throws on any missing field (verified by code
  inspection of the shared binder in index.html and by construction — all
  249 new cards passed the builder's field guard before the manifest
  write). UNKNOWN cards bind through `bindUnknownSlot` and render empty.
- **Manifest discipline.** Append-only: 767 → 1,016 figure entries, 87 →
  97 unknown slots. No existing entry touched — verified by the builder's
  pre-write byte-identity check (the V7 file reproduced byte-for-byte
  under the canonical serializer before mutation) and by the recorded
  pre-write sha 00036a77…2f8ce4164.
- **Slot resolution.** All 130 section-13 slots and all 129 section-14
  slots resolve against the V8 manifest; zero referenced-but-absent IDs,
  zero duplicates. Checked programmatically, not by eye.
- **Inline manifest byte-identity.** The `<script id="figures-manifest">`
  block in index.html is byte-identical to `data/figures.json` (verified
  by direct byte comparison after the patch).
- **Dense-tier subdivision (R5 precedent, disclosed).** Section 13:
  funding 32 → 2 arcs, in-care 38 → 3 arcs, Indigenous 31 → 2 arcs.
  Section 14: funding 33 → 2 arcs, legal-aid 30 → 2 arcs, corrections
  35 → 2 arcs. Reason stated in both briefs and section headers: density,
  not ceremony. No arc exceeds the 1.5-rad field-of-view cap.
- **Station geometry.** 16-unit spacing preserved end to end
  (−160 → −176 → −192, all gaps exactly 16). Section 14 is the new far
  end. Ambience particles extended to x=−210..+35 (comment-marked); no
  new point lights — same ruling as R6/R7.
- **Navigation.** 14 buttons (was 12), STATION_ORDER / STATION_POS /
  mount list / script tags all extended. Keyboard keys `[` and `]`
  assigned to sections 13/14 — no collisions with 1–0, -, = (verified
  programmatically: 14 keys, all unique).
- **Reduced motion.** The `diveTo` early return (`if(REDUCED){…return;}`)
  is intact; pointer-parallax and drift loops remain REDUCED-guarded.
  The main inline script passes `node --check`; both new section files
  pass `node --check`.

## 2. Iris — containment, no PII, dignity

- **No PII.** All figures are aggregate public figures; no person-level
  case data anywhere in the 249 new cards.
- **Child-welfare framing.** Language plain, respectful, dignified.
  Children and young people are never framed as the problem; figures
  describe system actions and outcomes. Indigenous communities framed
  with agency — discrimination and underfunding are the stated causes,
  never the communities. Enforced in card sources, tier comments, and
  the section-13 brief.
- **Courts/corrections framing.** Figures describe the justice system —
  never judge litigants, self-represented parties, or people in custody.
  Capacity, conditions, and outcomes are the system's record. Enforced
  in the section-14 brief and section header.
- **Fenced estimates stay fenced.** Midpoints, conveniences, vintages,
  and scopes are labeled in the source strings and never averaged or
  reconciled across instruments.

## 3. Twain² — plain-language honesty

- **Billions rule.** Large measurable figures use billions ($21.4B,
  $21.7B, $2.64B, $4B, $1.55B, $23.3B, $8.8B).
- **No tiny disclaimers.** Honesty boundaries render as normal-size data
  labels (e.g., "MODELED — convenience sum", "partial year, fenced",
  "advocacy, labeled").
- **Refusals recorded, not dropped.** All 13 refusals across both waves
  are named in the briefs with reasons.
- **Duplicates routed, not hidden.** 4 wave-12 duplicates and 2
  wave-13 numbered duplicates + 2 subclaim-level routes are recorded in
  the briefs with their target binds.
- **Copy stance.** Section headers state the framing law in plain words;
  no mechanism explainers, no fake telemetry.

## 4. Reconciliation and chain call

**Wave-12 gate (60 numbered figures):** 42 bound (125 cards: funding 31,
in-care 37, permanency 8, outcomes 19, indigenous 30; 124 REPORTED +
1 MODELED) · 9 refused · 4 duplicates routed · 5 numbered UNKNOWNs.
42 + 9 + 4 + 5 = 60 ✓.

**Wave-13 gate (60 numbered figures):** 49 bound (124 cards: funding 32,
backlog 9, access 20, legal aid 29, corrections 34; all REPORTED) ·
4 refused · 2 fully-duplicate numbered figures · 5 numbered UNKNOWNs.
49 + 4 + 2 + 5 = 60 ✓. Plus 2 subclaim-level routes recorded
(legal-aid L9's threshold-freeze context → crt13-leg-ag-threshold-freeze;
corrections F5's ~2,000-over-beds → crt13-bac-inmates-over-beds).

**Manifest V8 totals:** 1,016 figures · 97 unknown slots · labels
979 REPORTED / 36 MODELED / 1 BANKED. (Was V7: 767 / 87 /
731 / 35 / 1.)

**Derived cards (runtime only, weakestLabel, never manifest):**
- Section 13: 30 ÷ 7.7 = 3.896… → "3.9×", weakestLabel(REPORTED,
  REPORTED) = REPORTED. Eleventh weakestLabel exercise.
- Section 14: 135,811 ÷ 154,899 = 87.67% → "87.7%",
  weakestLabel(REPORTED, REPORTED) = REPORTED. Twelfth exercise.
- The −23.5% out-of-home-care decline (8,779 → 6,719) was computed at
  runtime only, weakestLabel-carried, and never entered the manifest.

**Computed HUD-meta expectation:** 1110 instruments · 1 banked ·
979 reported · 36 modeled · 97 unknown · 0 unlabeled (computed by the
page from mounted slots + manifest labels, never hardcoded).

**Frozen surface:** 52/52 files unchanged — file list identical, SHA-256
hashes identical, mtimes identical (snapshots taken before work,
compared after). Nothing written under `~/workspace/ts-spaces/web3d-hud/`.

**Change receipts:**
| artifact | before | after |
|---|---|---|
| `data/figures.json` (manifest V7→V8) | 00036a77038da11b8c4432e441bb241ae756fcc97628fb07f75930e2f8ce4164 | e3aceef82d8016ad881cc78387ec4bc6e619c2027f9eb2c049a8b1eadddd7b39 |
| `index.html` (2 scripts, 2 buttons, stations, keys, inline manifest, ambience) | 5dbc171630c8344803c4644a3404b42393da91714205787c4109813f81bc988d | e14060fa995d3c3fe1f106f3475382c2de1301918cae21ce5c41eda0c84361d7 |
| `arch/ed-arch-20260929-base3d-v1.md` (R8 amendment appended) | e64badebecb0c389cda1e64d4075d4ca2ae3aa215031ae559c6eaf4147f05789 | 3e728cd2fcca326ea7e3ab299c526dfb02dc511f2d58ee629fe3569116ef8910 |
| `sections/section-13-child-welfare-anchors.js` (created) | — | 453ef3e85a3ba222fe87afd241ce9c47d59905edea44e6c5921a73415dab1dfd |
| `sections/section-14-courts-anchors.js` (created) | — | a03a3b096a92ab58222652cd4651dadc945db519310b9dc510de7d877011c67e |
| `arch/section-13-child-welfare-anchors.md` (created) | — | 4db9469e3904c7ac9129d6bf1f2eab94c02355734e9ddf9260f38cd58c0e7047 |
| `arch/section-14-courts-anchors.md` (created) | — | 9db9f5f2a8e051240455c24a85dee8b9d2e3ea46e927fb169ec7b689d94bb366 |

**Validation that followed:** byte-identity manifest check; 249-card /
10-unknown builder run with collision and field guards; slot-resolution
and duplicate-slot checks (130/130, 129/129); inline-manifest
byte-identity; derived-math checks (3.9×, 87.7%); spacing/navigation/
key/reduced-motion checks; `node --check` on both sections and the main
inline script; frozen 52/52 hash+mtime comparison.

**Notes (bounded):**
1. The V8 manifest note's duplicate parenthetical is loose shorthand
   ("3 duplicates routed…"); the section-14 brief carries the canonical
   numbered-level accounting (2 fully-duplicate + 2 subclaim-level).
   The manifest is append-only, so the brief and this verdict supersede
   the note's wording, not its data.
2. The section-02 instrument-count question is still **OPEN for David**
   (unchanged from R7) — the gateway binds zero figure slots.
3. Manual visual verification was NOT performed — no browser is
   available in this rotation. David's eyes remain final QA. The 3D
   layout math (arc spans, plate position, float phases) follows the
   R7 templates exactly but has not been seen rendered.

**Chain call:** 2026-09-29T05:14:00Z (self-review by the building worker;
run personally, never claimed as independent).

**DRAFT ONLY — no seal, no deployment.**
