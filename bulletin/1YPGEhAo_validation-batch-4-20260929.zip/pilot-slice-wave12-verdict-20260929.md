# ED-VERDICT-20260929-PILOT-WAVE12-V1 — Trinity Verdict, Pilot Slice Wave 12 (Ontario x Child Welfare)

**Verdict ID:** ED-VERDICT-20260929-PILOT-WAVE12-V1
**Wave:** 12 | **Pipe:** WAVE12 | **Scope:** ontario-child-welfare | **Vintage:** 2026-Q3
**Claim hash:** a658dae77e07582c5ef0bfe50d03c3d42efc84b946e31033d898d98f1ba59e6c
**Status:** DRAFT — verdict-gated, no seal, no deployment, no production writes.
**Result:** PASS-WITH-NOTES
**Chain call:** 2026-09-29T04:55:00Z

---

## DCLM pass (deterministic logic)
1. **Counts:** 5 derivative files × 12 figures = 60 figures. Verified by `grep -c '^## F'` per file: 12/12/12/12/12. Total 60 by grep. ✓
2. **Label arithmetic:** 55 REPORTED / 0 MODELED / 5 UNKNOWN. Every figure carries exactly one label. No UNKNOWN filled; no REPORTED invented. ✓
3. **Provenance:** every figure carries value + label + source name + retrieval date + one-line provenance + vintage where applicable. The five UNKNOWNs carry no value, by rule. ✓
4. **Fencing:** 14 in-run slips recorded in the packet, all fenced side-by-side (never averaged/merged). Competing estimates (800 vs 1,000 aging-out; 21% vs 30% Indigenous share; 58% vs 25–50% homelessness; 6,400 vs 5,000 vs 360 permanency counts; press vs coroner mortality) remain fenced. ✓
5. **Forward-dating check:** no filing timestamps beyond assembly time (2026-09-29T04:52:16Z). Forward-dated content is limited to published forecasts/commitments (FAO 2026-27–2028-29 outlook; Jordan's Principle renewal through 2027-03-31; C-92 status Jan 2026), all inside vintage 2026-Q3, all anchored to published sources. No hash anchoring refused. ✓
6. **Integrity:** `sha256sum -c` in-run: 5/5 OK. Packet hashes match computed hashes. ✓
7. **Idempotency:** claim hash computed before any work; registry collision check returned 0; claim line appended (claimed_at 2026-09-29T04:50:28Z); no other line in the registry claims WAVE12/ontario-child-welfare. ✓
8. **Seal discipline:** no seal claimed or applied anywhere; packet and all derivatives marked PILOT MODE / No seal. ✓

## Iris pass (governance/security)
1. **Person-level data:** none present. All figures are aggregates. The Ombudsman case (outcomes F7) is reported from a published case story with no identifying detail. The mortality aggregates are coroner/press aggregates. No individual child, youth, family, or worker is identifiable from any figure. ✓
2. **Source hygiene:** government framing labeled as government framing (Parsa decade trends, ministry releases, MCCSS presentations); union advocacy labeled as union advocacy (CUPE); association data labeled as association framing (OACAS); research labeled as research with authors and dates; the GitHub cage-map was consulted in early research but NOT used as a source for any figure (kept out). ✓
3. **No PHI, no clinical advice, no legal advice.** No sensitive personal attributes inferred or volunteered. ✓
4. **No PII adjacent:** office addresses not published; only institutional URLs and public reports cited. ✓

## Twain² pass (bedside test — plain, respectful, dignified framing)
1. **Language check:** figures describe what the system did or did not provide; young people are never the problem being described. "58% experience homelessness" is framed as the system's record at the transition boundary. The advocate-causes statement (46% of families served because of adult mental health issues) is stated without judgment on families. Indigenous figures name discrimination and underfunding as causes, communities never as the problem. ✓
2. **No sensationalism:** the mortality figures are carried with the OACAS methodological corrective fenced alongside the press investigation — alarm and caution preserved, not resolved by the worker. No figure leans on shock. ✓
3. **No trivialization:** the 97%-at-home figure and the kinship-shift figures are carried as the full picture (the bedside test demands honesty in both directions), not as exoneration. ✓
4. **Dignity in outcomes:** F2/F4 outcomes explicitly state these are "the system's outcomes, reported so the gap can be closed, not judgments on the young people." ✓

## Reconciliation
All three stations agree: the wave is internally consistent, honestly fenced, and privacy-safe. The zero-MODELED split is accepted as the honest choice for this wave — the five consequential totals that would have been modeled from advocacy-adjacent components are instead five named UNKNOWNS, which is the more conservative and more honest treatment. No station requests a re-grade.

## Chain call
- Claim → a658dae77e07582c5ef0bfe50d03c3d42efc84b946e31033d898d98f1ba59e6c (claimed 2026-09-29T04:50:28Z)
- Evidence → pilot-slice-wave12-evidence-packet-20260929.md (assembled 2026-09-29T04:52:16Z)
- Files → on-childwelfare-funding.md:6dbf96b84482d51ba82b88f28bd954593043def68702568d6f9305fed3721f21 | on-childwelfare-incare.md:48d87d126f78e11e99b63263967b1a77e28edc1821971ddc13eb23b58daa3019 | on-childwelfare-permanency.md:0675ab8d328bb72ffd8d020fc9518f19e88c55890232d8d161a9a09e037964a8 | on-childwelfare-outcomes.md:7377b60cf9ed72e624a1444c2fbc76af2b9d41a1e5a412869bac359be20056fc | on-childwelfare-indigenous.md:f0e21955c4c8d6a67c1dc861ebf98824c153b1b7d6926780812eddd2f6017084
- Verdict → ED-VERDICT-20260929-PILOT-WAVE12-V1 (2026-09-29T04:55:00Z)
- Cumulative → 1146 figures (1086 + 60)

## Bounded notes (non-blocking, specific)
1. The five UNKNOWNs are the wave's most valuable output: province-wide CAS transfer rollup, licensed foster-home census, current adoption waitlist, current post-care outcome tracking, and consolidated Indigenous-agency caseloads. A future wave could assemble the transfer rollup from society-by-society audited financials — flagged as a candidate modeling task, not done here.
2. The $23.3B settlement figure is carried as widely-reported public record; a future pass could anchor it to the Federal Court order directly.
3. The CYDRA 2023 sub-breakdown (in-care vs not-in-care deaths within the 132) was unreadable in extraction; only the top line is carried. The full CYDRA annual report PDF is the source for a follow-up read.
4. Vintage spread on headline figures is wide (2015–2026); the packet fences this honestly, but any downstream consumer must read the vintage lines, not the headline counts.
5. No MODELED figures this wave is acceptable, but the two MODELED-derivable conveniences (2023–24 placement-category sum ≈6,162; per-youth cost ratios) were kept inside Notes rather than counted as modeled figures — the counting convention is recorded here for audit consistency.

**Verdict: PASS-WITH-NOTES.** DRAFT only. No seal. No deployment. No production writes.
