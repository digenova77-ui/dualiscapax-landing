# MEDICAL SIMULATION ENCYCLOPEDIA — CARDIOVASCULAR DOMAIN ENTRY

**Document Control ID:** ED-ENC-CARDIO-004
**Status:** DRAFT — no seal (seal requires David and his father). Verdicts only. Nothing deploys; the launch gate holds.
**Graded against:** ED-ENC-20260929-GRANULARITY-STANDARD-V1 (DRAFT).
**Authoring swarm:** Cardiovascular domain swarm (David's direction, Sept 28, 2026: "we can devote different swarms to neurological oncological etc to start actually doing it in parallel"). Wave 3.

> **ATLAS NOTICE (standing protein-fold law).** This entry is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. It never answers treatment or diagnostic questions about any person. Any person-directed medical question is routed to the fixed refusal: *"This is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. Speak with your clinician."* Every claim below carries a provenance label (REPORTED / MODELED / UNKNOWN); the weakest label governs each composite.

**Source material for this disease:** No staged Google-Doc design papers exist for atrial fibrillation in the encyclopedia program (Wave 3 = new diseases; the five engine-registered models do not include an AF model). All REPORTED claims below derive from web research conducted 2026-09-29 (RCSB/NCBI structural records, ICD-11 MMS v2026-01 via findacode, the 2023 ACC/AHA/ACCP/HRS AF guideline), labeled per source. Nothing is asserted beyond what the cited source states.

---

## ED-ENC-FIELD-01 — ENTRY IDENTITY

| Item | Value |
|---|---|
| Entry ID | ED-ENC-CARDIO-004 |
| Canonical name | Atrial fibrillation |
| ICD-11 | BC81.3 — Atrial fibrillation (REPORTED — ICD-11 MMS v2026-01, via findacode); subtypes BC81.30 paroxysmal, BC81.31 persistent, BC81.32 permanent, BC81.33 pre-excited |
| MONDO | UNKNOWN — no MONDO ID banked for this entry |
| Owning domain swarm | Cardiovascular |
| Authoring swarm | Cardiovascular domain swarm, Wave 3 |
| Entry version | V1 (this document) |
| Chain-verdict history | None yet. Entry self-graded by the authoring swarm (PARTIAL — see self-grade section). Independent verdict-gating pending in ED-VERDICT-20260929-ENC-CARDIO-WAVE3-V1 |

---

## ED-ENC-FIELD-02 — CANONICAL DEFINITION

**Atrial fibrillation** is a supraventricular tachyarrhythmia in which the atria lose organized contraction and instead sustain chaotic electrical activity: disorganized atrial activation with rapid, irregular ventricular response, loss of atrioventricular synchrony, and atrial stasis — the stasis being the mechanistic link to cardioembolic stroke (bridge to ED-ENC-CARDIO-003). It is classified temporally (paroxysmal: self-terminating within 7 days; persistent: sustained beyond 7 days or requiring cardioversion; long-standing persistent; permanent: accepted rhythm) — the temporal pattern describing the disease's evolution, not four diseases.

A definition that could describe three other diseases would fail; this one specifies the chaotic-atrial-activity electrophysiology, the loss of AV synchrony, and the atrial-stasis-to-embolism link — together unique to AF. It deliberately excludes organized supraventricular arrhythmias (atrial flutter, AVNRT, atrial tachycardia) — fenced out of this entry's scope.

---

## ED-ENC-FIELD-03 — ETIOLOGY

**Causal vs associated — fenced explicitly.**

**Established causal/triggering categories:**
- **Pulmonary-vein triggers:** ectopic foci in the pulmonary-vein sleeves are the REPORTED dominant trigger of paroxysmal AF (Haïssaguerre et al., NEJM 1998 — the discovery that founded pulmonary-vein isolation). [REPORTED]
- **Atrial substrate:** structural remodeling — atrial dilatation and fibrosis — from hypertension, heart failure (bridge to ED-ENC-CARDIO-002), valvular disease, and aging creates the re-entrant substrate. [REPORTED]
- **Genetic contributors:** rare variants (e.g., SCN5A loss-of-function in familial AF; gain-of-function potassium-channel variants) are REPORTED causes in familial cases; common-variant GWAS loci (notably PITX2/4q25) are REPORTED associations, not deterministic causes — fenced as associations. [REPORTED — association level for GWAS]
- **Cardiotoxic/triggering exposures:** hyperthyroidism (REPORTED reversible cause), alcohol ("holiday heart" — REPORTED trigger), post-cardiac-surgery AF (REPORTED common transient form). [REPORTED]

**Risk-factor contributors (fenced):** hypertension, heart failure, diabetes, obesity, sleep apnea, chronic kidney disease, alcohol use — REPORTED contributors; the entry assigns no deterministic single-patient causality to any of them.

**Idiopathic boundary:** "lone AF" — AF in the structurally normal heart without an identified cause — was the REPORTED historical category; its boundaries have narrowed as imaging and genetics improved, but cases without an established cause remain (UNKNOWN — see F11).

---

## ED-ENC-FIELD-04 — PATHOPHYSIOLOGY AT FIVE SCALES

Each scale states: **knowns at this scale**, **inferences borrowed from another scale (labeled MODELED/UNKNOWN)**, and **UNKNOWNs**. No scale borrows authority silently.

### F04a — Molecular

**Knowns at this scale:**
- **Cardiac sodium channel (Nav1.5 / SCN5A):** the principal cardiac voltage-gated sodium channel mediating phase-0 depolarization. The human Nav1.5 E1784K structure (PDB 7DTC; NCBI structural record) shows the channel architecture relevant to conduction; SCN5A variants are REPORTED in familial AF and in overlapping conduction disease. [REPORTED — NCBI PDB 7DTC]
- **Potassium-channel remodeling:** downregulation of IK1/IKur and upregulation of constitutively active IK,ACh are REPORTED molecular features of the fibrillating atrium ("electrical remodeling"). [REPORTED]
- **Calcium-handling remodeling:** RyR2 hyperphosphorylation and diastolic calcium leak are REPORTED in AF models, producing delayed afterdepolarizations — the molecular basis of triggered activity. [REPORTED]
- **Fibrotic signaling:** TGF-β1–driven fibroblast activation and collagen deposition — the molecular substrate program. [REPORTED]
- **Factor Xa:** the coagulation convergence point (as in ED-ENC-CARDIO-003); the apixaban-bound structure (PDB 2P16 — Factor Xa + apixaban; Pinto et al., J Med Chem 2007) is banked here for the thromboembolic-prevention axis of the AF ladder. [REPORTED — RCSB 2P16]

**Borrowed inference (labeled):** that the specific ion-channel remodeling pattern measured in animal and explanted-human atria *causes* the individual's AF (rather than resulting from it) is inferred — MODELED; the direction of causality is partly UNKNOWN.

**UNKNOWNs at this scale:** the human Kv1.5 (KCNA5) structure — the proposed 6UWM was NOT verified in this entry's research and is deliberately not used; the target is recorded as UNKNOWN (F05/F06); in-situ kinetics of the remodeled channels in the fibrillating human atrium; which molecular program (trigger vs substrate) dominates in a given patient.

### F04b — Cellular

**Knowns at this scale:**
- Atrial myocyte action-potential shortening and triangulation (cellular electrical remodeling); calcium-transient alternans. [REPORTED]
- Fibroblast proliferation and myofibroblast differentiation; fibroblast–myocyte electrotonic coupling as a REPORTED arrhythmogenic mechanism. [REPORTED]
- Connexin remodeling (Cx40/Cx43 redistribution) → heterogeneous conduction. [REPORTED]
- Death/survival programs: atrial myocyte apoptosis and autophagy are REPORTED in chronic AF models. [REPORTED]
- Pulmonary-vein sleeve cells: distinct electrophysiology (shorter refractory periods) — the cellular basis of the dominant trigger. [REPORTED]

**Borrowed inference:** that fibroblast–myocyte coupling is *sufficient* to sustain re-entry in vivo is inferred from co-culture and modeling — MODELED.

**UNKNOWNs at this scale:** the ordered cellular sequence of "AF begets AF" (which remodels first — the trigger cells or the substrate); single-cell trajectories of human atrial remodeling (no trajectory banked — UNKNOWN).

### F04c — Tissue

**Knowns at this scale:**
- Atrial dilatation and interstitial fibrosis — the REPORTED tissue substrate; late-gadolinium-enhancement MRI fibrosis staging (Utah stages) is the REPORTED imaging correlate. [REPORTED]
- Re-entrant circuits: multiple wavelets (Moe/Allessie formulation) vs rotor/leading-circle mechanisms — REPORTED competing tissue-level models, both named, neither asserted as the sole mechanism. [REPORTED]
- Pulmonary-vein antrum and posterior left atrium as the dominant trigger geography. [REPORTED]
- Atrial stasis → thrombus formation, preferentially in the left atrial appendage — the REPORTED tissue link to stroke. [REPORTED]

**Borrowed inference:** that fibrosis *burden* on LGE-MRI predicts ablation outcome is inferred from correlation — MODELED.

**UNKNOWNs at this scale:** whether rotors or multiple wavelets dominate in a given patient's AF; the tissue determinants of progression from paroxysmal to persistent.

### F04d — Organ

**Knowns at this scale:**
- Loss of atrial kick (up to ~25% of cardiac output at high rates — REPORTED estimate), irregular ventricular response, rate-related cardiomyopathy (tachycardia-induced — REPORTED reversible). [REPORTED]
- Reserve and compensation: rate control preserves output; rhythm control restores synchrony — the two REPORTED organ-level strategies. [REPORTED]
- Failure modes: cardioembolic stroke (bridge to ED-ENC-CARDIO-003), heart failure (bridge to ED-ENC-CARDIO-002), tachycardia-mediated cardiomyopathy. [REPORTED]
- Classification: paroxysmal / persistent / long-standing persistent / permanent — the REPORTED temporal scheme (ICD-11 BC81.30–.33). [REPORTED]

**Borrowed inference:** none beyond observed clinical classification; the scheme is a REPORTED practice fact.

**UNKNOWNs at this scale:** organ-level predictors of which paroxysmal AF progresses to persistent; the determinants of individual stroke risk beyond the CHA₂DS₂-VASc clinical score.

### F04e — System

**Knowns at this scale:**
- AF is the most common sustained arrhythmia; prevalence rises steeply with age — a growing global burden. [REPORTED — Global Burden of Disease literature]
- Thromboembolic axis: AF causes roughly one in six ischaemic strokes in older populations (REPORTED estimate) — the systemic consequence that dominates the ladder. [REPORTED]
- Systemic risk-factor network: hypertension, obesity, sleep apnea, alcohol — the modifiable substrate network. [REPORTED]
- Anticoagulation benefit/harm: stroke reduction versus bleeding risk — the REPORTED systemic trade-off that the ladder manages. [REPORTED]

**Borrowed inference:** that population AF screening reduces stroke at scale is inferred from trials (STROKESTOP, mSToPS — REPORTED) — MODELED as a general claim; the entry does not assert it.

**UNKNOWNs at this scale:** the systemic mediators linking sleep apnea to AF; whether treating risk factors reverses established substrate (partially REPORTED for weight loss — fenced).

---

## ED-ENC-FIELD-05 — MOLECULAR TARGETS

| Common name | Gene | UniProt | PDB ID | Mechanistic role in F04 | Structure status |
|---|---|---|---|---|---|
| Nav1.5 (cardiac sodium channel) | SCN5A | Q14524 | 7DTC (human Nav1.5 E1784K) | Phase-0 depolarization; conduction/Familial-AF axis, F04a | REPORTED |
| Factor Xa | F10 | — (unfilled) | 2P16 (Factor Xa + apixaban) | Thromboembolic-prevention axis, F04a | REPORTED |
| Kv1.5 (ultrarapid delayed rectifier) | KCNA5 | — (unfilled) | UNKNOWN (6UWM not verified — deliberately not used) | Atrial-selective repolarization target, F04a | UNKNOWN — recorded as gap, not skipped |
| RyR2 (cardiac ryanodine receptor) | RYR2 | — (unfilled) | UNKNOWN (no PDB ID verified in this entry's research) | Diastolic calcium leak / triggered activity, F04a | UNKNOWN — recorded as gap |
| Vitamin K epoxide reductase | VKORC1 | — (unfilled) | UNKNOWN (no PDB ID verified in this entry's research) | Warfarin target, F09 | UNKNOWN — recorded as gap |

(UniProt ID for SCN5A sourced from the session's research tool output; remaining UniProt IDs deliberately left unfilled rather than written from memory — UNKNOWN. The Kv1.5/6UWM non-verification is preserved as a named research outcome, not a silent omission.)

---

## ED-ENC-FIELD-06 — 3D MODEL REFERENCES

The WebGL/Mol* pattern per the ALS 3D molecular guide (ED-MED-202A0907-DCLM-ALS-3D-MANIPULATOR-V1). Mol* link form: `https://molstar.org/viewer/?rcsb=<PDB>`. Manipulability is the bar: rotate, zoom, pan in any browser. A static image is not a 3D reference.

| Target | PDB | Mol* viewer link | RCSB/NCBI record |
|---|---|---|---|
| Nav1.5 E1784K | 7DTC | https://molstar.org/viewer/?rcsb=7DTC | ncbi.nlm.nih.gov/Structure/pdb/7DTC |
| Factor Xa + apixaban | 2P16 | https://molstar.org/viewer/?rcsb=2P16 | rcsb.org/structure/2P16 |
| Kv1.5 | — | UNKNOWN — 6UWM not verified, not used | recorded as gap (F05) |
| RyR2 | — | UNKNOWN — no structure verified | recorded as gap (F05) |
| VKORC1 | — | UNKNOWN — no structure verified | recorded as gap (F05) |

No DCLM-refined complex PDBs for AF targets are banked on Drive in this entry's research — UNKNOWN. (Mol* links follow the standard's own pattern but were not live smoke-tested in this session — see UNKNOWN register.)

---

## ED-ENC-FIELD-07 — SIMULATION SPECIFICATION

**What counts as a simulation** (the standard's bar): a deterministic execution of a disease model that emits verifiable state transitions — DiseaseModelSpec + parameter manifest + initial state + regime + integrator settings → full state trajectory + summary metrics. Dual-pipeline structure (Pole A kinetics ΔG → Kd → engagement, Pole B systems ODEs), fail-closed watchdog (<4.20 ms), regime honesty, metrics-only outputs are shadows, not simulations.

**No staged simulation material exists for atrial fibrillation.** The five engine-registered models include no AF model. **Therefore, this entry banks no simulation.** The specification below is what an AF simulation under this standard WOULD be — a normative scaffold, not a run:

- **DiseaseModelSpec:** Atrial-fibrillation dual-pipeline model. Pole A: atrial action-potential module (Nav1.5/SCN5A conductance from 7DTC geometry; IK1/IKur/IK,ACh remodeling parameters; RyR2 calcium-leak module), pulmonary-vein trigger module (ectopic focus generator). Pole B: atrial-tissue propagation network (fibrosis-burden field, connexin-heterogeneity field; rotor vs multiple-wavelet regime selectable and declared), atrial-mechanics module (loss of atrial kick → stasis index), left-atrial-appendage thrombus-formation module with Factor Xa–thrombin cascade cross-talk (apixaban occupancy from 2P16 geometry).
- **Parameter manifest:** REPORTED structural parameters (from the PDB complexes in F05), REPORTED electrophysiologic rates (conduction velocities, refractory periods from mapping studies), and named UNKNOWN parameters (rotor-vs-wavelet regime per patient, fibrosis-progression rates, individual stroke-risk coefficients beyond clinical scores) — each labeled per F12.
- **Regime:** declared at execution (CLOSED_LOOP / STANDALONE_AI / STANDALONE_SYSTEMS); a STANDALONE_AI result would never be presented as a closed-loop result.
- **Integrator:** fixed-step, deterministic, bit-identical trajectories.

This scaffold is DRAFT design — no model was executed for this entry. Nothing here is presented as a result.

---

## ED-ENC-FIELD-08 — HASH VERIFICATION RECORD

**No simulation was executed under this standard for this entry; therefore no hash exists.** The SHA-256 record covers (spec + parameters + initial state + regime + integrator + full trajectory) — with no executed simulation, there is nothing to hash, and this entry claims nothing.

**Hash discipline restated:** when an AF simulation is executed under the F07 scaffold, its hash will be banked here with the full reproducibility manifest. Until then this field stands open and confessed. This confessed absence is the single blocking gap for COMPLETE (see self-grade).

---

## ED-ENC-FIELD-09 — TREATMENT LADDER (DOCUMENTED, STAGED)

Atlas posture: third person, past tense of the literature, named sources. What the field does — never what any person should do. This ladder documents established knowledge; it is not advice and contains no second-person language.

**Stroke prevention.** Per the 2023 ACC/AHA/ACCP/HRS Guideline for the Diagnosis and Management of Atrial Fibrillation (Joglar et al., Circulation 2023; JACC 2024; DOI 10.1161/CIR.0000000000001193), the REPORTED ladder comprised: (1) stroke-risk stratification with the CHA₂DS₂-VASc score; (2) oral anticoagulation for patients at elevated risk — direct oral anticoagulants (apixaban, rivaroxaban, dabigatran, edoxaban) preferred over warfarin (the REPORTED trial base: RE-LY 2009, ROCKET-AF 2011, ARISTOTLE 2011, ENGAGE-AF 2013); (3) left atrial appendage occlusion as the REPORTED alternative for patients with contraindications to long-term anticoagulation. [REPORTED — Joglar et al., Circulation 2023]

**Rate vs rhythm control.** The REPORTED ladder comprised: (1) rate control (beta-blockers, non-dihydropyridine calcium-channel blockers, digoxin) as the initial strategy for many patients; (2) rhythm control (antiarrhythmic drugs — amiodarone, flecainide, propafenone, sotalol, dofetilide, dronedarone — or electrical cardioversion) for symptomatic patients; (3) catheter ablation — pulmonary-vein isolation — with the REPORTED evidence base shifting toward earlier ablation (EAST-AFNET 4, 2020 — early rhythm control reduced the composite of cardiovascular death, stroke, and hospitalization). [REPORTED — 2023 guideline; EAST-AFNET 4]

**Risk-factor and lifestyle management.** Weight loss, sleep-apnea treatment, alcohol reduction, and exercise were REPORTED as the guideline's fourth pillar (the "lifestyle and risk-factor modification" rung). [REPORTED — Joglar et al., Circulation 2023]

**Mechanistic ties to F04–F05:** anticoagulants act at the Factor Xa–thrombin axis (F05, 2P16 — apixaban geometry) interrupting the stasis-to-thrombus link (F04c); rate-control agents act at the AV node (no verified structures in this entry — named gap); antiarrhythmics act at ion channels including Nav1.5 (F05, 7DTC); ablation acts at the pulmonary-vein trigger geography (F04c). The Kv1.5 atrial-selective axis had no REPORTED ladder rung — named as a gap, not an opportunity.

---

## ED-ENC-FIELD-10 — PHARMACOLOGY — SLOT HELD, SEALED

**SEALED — Stage-1 pharmacology held; lift gated on Condition 6.**

Nothing more is written here. The slot's emptiness is the honest content. No simulation in this entry used pharmacology-stage material as an input; no entry content synthesizes what the sealed stage would contain. "The drug would probably…" is modeling around the seal — refused by construction.

---

## ED-ENC-FIELD-11 — UNKNOWN REGISTER

Per-field confessions. A field with no named UNKNOWNs would be an incomplete field.

- **F01:** MONDO ID not banked. Chain-verdict history empty — no independent scorer has graded this entry.
- **F02:** Organized supraventricular arrhythmias (flutter, AVNRT, atrial tachycardia) are named but fenced out.
- **F03:** "Lone AF" without an established cause; the causal status of GWAS loci (associations, not causes).
- **F04a:** Human Kv1.5 structure (6UWM not verified — deliberately unused); in-situ kinetics of remodeled channels; trigger-vs-substrate dominance per patient.
- **F04b:** The ordered cellular sequence of "AF begets AF"; single-cell trajectories of human atrial remodeling.
- **F04c:** Rotor vs multiple-wavelet dominance per patient; determinants of paroxysmal-to-persistent progression.
- **F04d:** Organ-level predictors of progression; individual stroke-risk determinants beyond CHA₂DS₂-VASc.
- **F04e:** Systemic mediators of the sleep-apnea–AF link; whether risk-factor treatment reverses established substrate.
- **F05:** No PDB verified in this entry for Kv1.5, RyR2, or VKORC1 (absence recorded as data). Several UniProt IDs deliberately left unfilled.
- **F06:** Mol* links follow the standard's own pattern but were not live smoke-tested in this session; structural records were reached via search-result pages, not direct record verification of every ID's current status.
- **F07:** No simulation executed; the scaffold is normative design, not a run.
- **F08:** No hash exists — confessed absence, the blocking gap.
- **F09:** Ladder reflects the 2023 ACC/AHA/ACCP/HRS guideline and named trials as retrieved via web search; guidelines evolve — the ladder is dated to its sources. Dosing detail deliberately omitted (atlas, not formulary).
- **F10:** Contents unknown by design (sealed). Hold-lift condition (Condition 6) still open.
- **F12:** Weakest-label audit performed by the authoring swarm only; independent double-scoring pending.

**Deepest UNKNOWNs (load-bearing, named for the coordinator):**
1. **No executed, hash-anchored simulation exists for atrial fibrillation under this standard.** This single gap is what blocks COMPLETE and caps the grade at PARTIAL.
2. **The tissue mechanism is genuinely contested** — rotors vs multiple wavelets are both REPORTED models; the entry names both and asserts neither.
3. **The Kv1.5 structure is unverified** — the proposed 6UWM was not confirmed and is deliberately unused; the atrial-selective target axis is a named gap.
4. **Pharmacology is sealed** — the slot is held, not worked around.

---

## ED-ENC-FIELD-12 — PROVENANCE MANIFEST

Every claim carries REPORTED / MODELED / UNKNOWN. Weakest-label rule applied throughout.

| Claim | Label | Source |
|---|---|---|
| ICD-11 BC81.3 (subtypes .30–.33) = Atrial fibrillation | REPORTED | ICD-11 MMS v2026-01 (findacode) |
| Canonical definition (chaotic atrial activity; stasis-to-embolism link; temporal classification) | REPORTED | established literature; 2023 AF guideline taxonomy |
| Pulmonary-vein triggers (Haïssaguerre 1998) | REPORTED | Haïssaguerre et al., NEJM 1998 |
| Atrial substrate (dilatation, fibrosis); SCN5A familial variants; PITX2 GWAS association | REPORTED | established literature (association level fenced for GWAS) |
| Reversible/triggering causes (hyperthyroidism, alcohol, post-surgical) | REPORTED | established literature |
| PDB 7DTC (human Nav1.5 E1784K) | REPORTED | NCBI structural record |
| PDB 2P16 (Factor Xa + apixaban; corrected ligand identity) | REPORTED | RCSB PDB record (Pinto et al., J Med Chem 2007) |
| UniProt Q14524 (SCN5A) | REPORTED | session research tool output |
| Electrical remodeling (IK1/IKur down, IK,ACh up); RyR2 calcium leak | REPORTED | established literature |
| Multiple wavelets vs rotor models (both named, neither asserted) | REPORTED | established literature (Moe/Allessie; rotor literature) |
| Left atrial appendage as dominant thrombus site | REPORTED | established literature |
| AF as most common sustained arrhythmia; ~1-in-6 stroke estimate | REPORTED | Global Burden of Disease / established literature |
| Fibrosis-burden predicting ablation outcome; screening benefit | MODELED | correlation/trial-inferred |
| Treatment ladder (F09) | REPORTED | Joglar et al., Circulation 2023 / JACC 2024 (2023 ACC/AHA/ACCP/HRS AF guideline, DOI 10.1161/CIR.0000000000001193); RE-LY 2009; ROCKET-AF 2011; ARISTOTLE 2011; ENGAGE-AF 2013; EAST-AFNET 4 2020 |
| F07 simulation scaffold | MODELED | designed from the standard's bar; no execution — labeled design, not result |
| F08 hash record | UNKNOWN (confessed absence) | no executed simulation |
| F10 pharmacology | SEALED | stage-1 seal, Condition-6 lift pending |
| Rotor/wavelet dominance; Kv1.5 structure; progression determinants | UNKNOWN | named in F11 |
| Weakest-label compliance | Self-audited | independent double-scoring pending |

---

## SELF-GRADE AGAINST THE COMPLETENESS RUBRIC

**Rubric criteria (ED-ENC-20260929 §2):**

1. *All twelve fields present; none absent.* ✅ — F01–F12 all present; F07/F08/F10 present-but-fenced (permitted).
2. *All five scales closed or explicitly fenced.* ✅ — F04a–e each carry knowns / borrowed inferences / named UNKNOWNs.
3. *F06: every structural target with a PDB ID carries a Mol\* link; targets without structures named as UNKNOWN.* ✅ — 2 structures linked via the standard's Mol* pattern; Kv1.5, RyR2, VKORC1 named as UNKNOWN, not skipped. (Links not live smoke-tested — confessed in F11.)
4. *F07–F08: at least one simulation executed under the bar with an anchored, recomputable SHA-256 hash.* ❌ — **This is the failing criterion.** No simulation was executed. Nothing is hash-anchored.
5. *F09: ladder from named sources; no second-person language.* ✅ — 2023 ACC/AHA/ACCP/HRS guideline and named trials cited; third person throughout.
6. *F10: slot present and correctly marked SEALED with the hold condition named.* ✅ — verbatim seal text, Condition 6 named.
7. *F12: every claim labeled; weakest-label rule applied; zero unlabeled claims.* ✅ (self-audit) — independent double-scoring still pending.

**Grade: PARTIAL.** Reasoning: schema-shaped with honestly populated load-bearing fields, but criterion 4 fails — no hash-anchored simulation exists, and the entry cannot honestly claim SUBSTANTIAL either, since SUBSTANTIAL requires ≥1 executed simulation and there is no executed simulation at all. The F07 scaffold is genuine design — the dual-pipeline AF model (Pole A atrial electrophysiology/calcium kinetics, Pole B tissue-propagation/stasis-thrombus network) — but design is not execution, and the standard is explicit: a scaffold without a run is not a simulation. Grading the design as a simulation would launder gloss into the arithmetic. So: PARTIAL, with the single blocking gap named — execute an AF simulation under the F07 scaffold, bank the trajectory, anchor the hash, and this entry moves toward SUBSTANTIAL (then COMPLETE once 3D links are smoke-tested and independent double-scoring lands).

**Self-grade confidence:** performed by the authoring swarm against the written rubric; per the standard's residual 5, the first independent double-scoring will test whether the rubric reproduces. This grade is provisional pending verdict-gating.

---

## CHAIN-OF-CUSTODY NOTES (for the coordinator)

- No staged design papers existed for this disease; all REPORTED claims derive from web research conducted 2026-09-29, labeled per source. PDB IDs were taken from RCSB/NCBI-indexed records with cited deposition literature; ICD-11 from the MMS v2026-01 via findacode; the 2023 AF guideline identified by DOI.
- The Kv1.5/6UWM non-verification is preserved as a named research outcome — the target is recorded UNKNOWN rather than asserted.
- The 2P16 ligand identity was corrected during research (apixaban, not rivaroxaban) and the correction is preserved here.
- No second-person language anywhere in F09; atlas-not-advisor fence held.
- Pharmacology seal: held exactly, never modeled around.
- DRAFT only. No seal. Nothing deploys. The launch gate holds.

*End of ED-ENC-CARDIO-004 V1 — DRAFT, no seal, gate holds.*
