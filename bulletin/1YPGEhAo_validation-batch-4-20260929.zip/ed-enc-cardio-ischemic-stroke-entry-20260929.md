# MEDICAL SIMULATION ENCYCLOPEDIA — CARDIOVASCULAR DOMAIN ENTRY

**Document Control ID:** ED-ENC-CARDIO-003
**Status:** DRAFT — no seal (seal requires David and his father). Verdicts only. Nothing deploys; the launch gate holds.
**Graded against:** ED-ENC-20260929-GRANULARITY-STANDARD-V1 (DRAFT).
**Authoring swarm:** Cardiovascular domain swarm (David's direction, Sept 28, 2026: "we can devote different swarms to neurological oncological etc to start actually doing it in parallel"). Wave 3.

> **ATLAS NOTICE (standing protein-fold law).** This entry is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. It never answers treatment or diagnostic questions about any person. Any person-directed medical question is routed to the fixed refusal: *"This is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. Speak with your clinician."* Every claim below carries a provenance label (REPORTED / MODELED / UNKNOWN); the weakest label governs each composite.

**Source material for this disease:** No staged Google-Doc design papers exist for ischemic stroke in the encyclopedia program (Wave 3 = new diseases; the five engine-registered models do not include a stroke model). All REPORTED claims below derive from web research conducted 2026-09-29 (RCSB PDB records, ICD-11 MMS v2026-01 via findacode, named guidelines and trials), labeled per source. Nothing is asserted beyond what the cited source states.

---

## ED-ENC-FIELD-01 — ENTRY IDENTITY

| Item | Value |
|---|---|
| Entry ID | ED-ENC-CARDIO-003 |
| Canonical name | Ischaemic stroke (cerebral ischaemic stroke) |
| ICD-11 | 8B11 — Cerebral ischaemic stroke (REPORTED — ICD-11 MMS v2026-01, via findacode) |
| MONDO | UNKNOWN — no MONDO ID banked for this entry |
| Owning domain swarm | Cardiovascular |
| Authoring swarm | Cardiovascular domain swarm, Wave 3 |
| Entry version | V1 (this document) |
| Chain-verdict history | None yet. Entry self-graded by the authoring swarm (PARTIAL — see self-grade section). Independent verdict-gating pending in ED-VERDICT-20260929-ENC-CARDIO-WAVE3-V1 |

---

## ED-ENC-FIELD-02 — CANONICAL DEFINITION

**Ischaemic stroke** is the acute focal infarction of brain tissue caused by the abrupt occlusion of a cerebral (or precerebral) artery — by in-situ atherothrombosis, artery-to-artery embolism, cardioembolism (most notably from atrial fibrillation — bridge to ED-ENC-CARDIO-004), small-vessel occlusion, or other determined causes — producing energy failure in the territory downstream, a penumbral zone of electrically silent but salvageable tissue, and, if unreperfused, completed infarction. It is classified by mechanism (the TOAST/ASCOD phenotypic scheme and the ICD-11 8B11 subcategories: large-artery atherosclerotic, cardioembolic, small-vessel, other determined, undetermined), not by size or location alone.

A definition that could describe three other diseases would fail; this one specifies the vascular-occlusion initiating event, the penumbra/completed-infarct tissue dynamics, and the mechanism-based classification — together unique to ischaemic stroke. It deliberately excludes haemorrhagic stroke and transient ischaemic attack (the REPORTED 8B40 sibling entity with transient deficit and no infarction) — fenced out of this entry's scope. The entry's scope is the ischaemic territory injury; the occluding thrombus's origin (cardiac, arterial, cryptogenic) is classified, not re-explained.

---

## ED-ENC-FIELD-03 — ETIOLOGY

**Causal vs associated — fenced explicitly.**

**Established causal categories (TOAST phenotypic scheme, REPORTED — established literature):**
- **Large-artery atherosclerosis:** carotid, vertebral, and intracranial atherosclerotic plaque with in-situ thrombosis or artery-to-artery embolism — shares the atherosclerotic biology with ED-ENC-CARDIO-001 in the cerebrovascular bed. [REPORTED]
- **Cardioembolism:** atrial fibrillation is the dominant cardioembolic source (bridge to ED-ENC-CARDIO-004); also left-ventricular thrombus, valvular vegetations, patent foramen ovale with paradoxical embolism. [REPORTED]
- **Small-vessel (lacunar) disease:** lipohyalinosis of penetrating arterioles in the context of chronic hypertension — the small-artery-occlusion category (REPORTED as ICD-11 8B11.3 sibling). [REPORTED]
- **Other determined causes:** arterial dissection (carotid/vertebral), vasculitis, hypercoagulable states, drug-associated vasospasm. [REPORTED]
- **Undetermined / cryptogenic:** no cause found after complete workup — a REPORTED category, and an honest boundary: ESUS (embolic stroke of undetermined source) trials (NAVIGATE ESUS, RESPECT ESUS) did not establish anticoagulation over antiplatelet therapy. [REPORTED]

**Established risk contributors (fenced):** hypertension (dominant modifiable), diabetes mellitus, hyperlipidemia, atrial fibrillation, smoking, and — by association — each is stated at the level the literature states it; the entry assigns no deterministic single-patient causality.

**Idiopathic boundary:** cryptogenic stroke after complete workup — why that patient thrombosed there, then — is UNKNOWN (see F11).

---

## ED-ENC-FIELD-04 — PATHOPHYSIOLOGY AT FIVE SCALES

Each scale states: **knowns at this scale**, **inferences borrowed from another scale (labeled MODELED/UNKNOWN)**, and **UNKNOWNs**. No scale borrows authority silently.

### F04a — Molecular

**Knowns at this scale:**
- **Ischaemic cascade:** ATP depletion → failure of Na⁺/K⁺-ATPase → cytotoxic edema; glutamate release → NMDA-receptor overactivation → calcium overload; free-radical generation; mitochondrial failure. The excitotoxic sequence is REPORTED from decades of experimental work — and its clinical translation (neuroprotection trials) has failed repeatedly, a confessed disconnect (F11). [REPORTED — experimental literature]
- **tPA–plasmin axis:** tissue plasminogen activator (PLAT) converts plasminogen → plasmin, which degrades fibrin. The catalytic domain structure (PDB 1RTF — human two-chain tPA catalytic domain with benzamidine bound; Renatus et al.) shows the trypsin-like serine-protease fold and the S1 specificity pocket. [REPORTED — RCSB 1RTF]
- **Factor Xa:** the convergence point of the intrinsic and extrinsic coagulation pathways; Factor Xa inhibition blocks thrombin generation. The apixaban-bound structure (PDB 2P16 — human Factor Xa in complex with the inhibitor apixaban; Pinto et al., J Med Chem 2007) shows the S1/S4 pocket occupancy by the pyrazolopyridine scaffold. (The corrected ligand identity is apixaban, not rivaroxaban — preserved from the research.) [REPORTED — RCSB 2P16]
- **Platelet activation:** ADP (P2Y12), thromboxane A2, and thrombin (PAR-1) signaling converge on GP IIb/IIIa-mediated aggregation. [REPORTED]
- **Reperfusion injury:** restored flow generates oxidative and inflammatory injury — the REPORTED molecular basis of haemorrhagic transformation risk after late reperfusion. [REPORTED]

**Borrowed inference (labeled):** that the excitotoxic cascade observed in rodent middle-cerebral-artery-occlusion models operates identically in human stroke is inferred — MODELED, and its repeated clinical failure is the evidence against the inference's completeness.

**UNKNOWNs at this scale:** why neuroprotection succeeds in animals and fails in humans (the deepest molecular gap of the field); in-situ kinetics of tPA–plasminogen at the human thrombus; the molecular determinants of haemorrhagic transformation.

### F04b — Cellular

**Knowns at this scale:**
- Neuronal energy failure → cytotoxic (cellular) edema, visible as diffusion restriction on MRI — the REPORTED cellular imaging signature. [REPORTED]
- Astrocyte swelling and glutamate-transporter failure; microglial activation within hours. [REPORTED]
- Endothelial activation and blood–brain-barrier breakdown; neutrophil transmigration during reperfusion. [REPORTED]
- Death/survival programs: apoptosis, necroptosis, and ferroptosis are REPORTED cell-death programs in ischaemic brain (experimental literature). [REPORTED]
- Penumbral cells: electrically silent, metabolically viable — the cellular substrate of salvage. [REPORTED]

**Borrowed inference:** that the penumbra's viability window measured in animals (~3–6 hours of flow) transfers to human patients is inferred — MODELED; the clinical time windows (thrombolysis up to 4.5 h, thrombectomy up to 24 h in selected patients) are REPORTED practice facts that only partially overlap the inference.

**UNKNOWNs at this scale:** the exact per-cell viability clock in human penumbra; the ordered cellular sequence of BBB breakdown; whether the penumbra dies by one dominant program or by mixed programs simultaneously.

### F04c — Tissue

**Knowns at this scale:**
- Core vs penumbra: the ischaemic core is dead tissue; the penumbra is salvageable — the REPORTED tissue construct driving reperfusion therapy. [REPORTED]
- Collateral circulation: leptomeningeal collaterals sustain the penumbra; collateral grade is the REPORTED tissue predictor of outcome and of treatment response. [REPORTED]
- Thrombus composition: red (fibrin/RBC-rich, cardioembolic-typical) vs white (platelet-rich, atherosclerotic-typical) — REPORTED histologic distinction with retrieval implications. [REPORTED]
- Oedema evolution: cytotoxic → vasogenic → malignant oedema in large infarcts. [REPORTED]
- Haemorrhagic transformation: petechial (HI1/HI2) to parenchymal haematoma (PH1/PH2) — the REPORTED tissue classification. [REPORTED]

**Borrowed inference:** that thrombus histology *predicts* retrievability in thrombectomy is inferred from correlation — MODELED.

**UNKNOWNs at this scale:** why some patients with excellent collaterals still infarct rapidly ("fast progressors"); the tissue determinants of malignant oedema.

### F04d — Organ

**Knowns at this scale:**
- Territory syndromes: middle-cerebral-artery (aphasia/neglect, hemiparesis), anterior-cerebral (leg-predominant), posterior circulation (visual, brainstem) — REPORTED clinical-anatomic mapping. [REPORTED]
- Reserve and compensation: collateral networks, ischaemic preconditioning (REPORTED experimental phenomenon). [REPORTED]
- Failure modes: completed infarction with permanent deficit, malignant oedema with herniation, haemorrhagic transformation, post-stroke epilepsy. [REPORTED]
- NIH Stroke Scale (NIHSS) is the REPORTED organ-level severity scale; the modified Rankin Scale (mRS) the REPORTED outcome scale. [REPORTED]

**Borrowed inference:** none beyond observed clinical-anatomic correlation; the scales are REPORTED practice facts.

**UNKNOWNs at this scale:** organ-level predictors of recovery beyond the acute phase; the determinants of post-stroke cognitive trajectories.

### F04e — System

**Knowns at this scale:**
- Stroke is the second leading cause of death and a leading cause of adult disability worldwide. [REPORTED — Global Burden of Disease literature]
- Cardiac axis: atrial fibrillation detection after stroke (prolonged monitoring yields REPORTED detection rates) drives secondary prevention. [REPORTED]
- Systemic complications: aspiration pneumonia, venous thromboembolism, dysphagia-related malnutrition. [REPORTED]
- Metabolic axis: diabetes and hyperglycemia worsen outcomes — the REPORTED association (glucose-lowering trials have not established outcome benefit; fenced). [REPORTED]

**Borrowed inference:** that post-stroke systemic inflammation *drives* secondary brain injury (rather than marking it) is inferred — MODELED.

**UNKNOWNs at this scale:** the systemic mediators of post-stroke immunosuppression; why some cryptogenic strokes never reveal a source despite prolonged monitoring.

---

## ED-ENC-FIELD-05 — MOLECULAR TARGETS

| Common name | Gene | UniProt | PDB ID | Mechanistic role in F04 | Structure status |
|---|---|---|---|---|---|
| Tissue plasminogen activator | PLAT | P00750 | 1RTF (two-chain catalytic domain + benzamidine) | Plasminogen → plasmin (fibrinolysis), F04a | REPORTED |
| Factor Xa | F10 | — (unfilled) | 2P16 (Factor Xa + apixaban) | Convergence point of coagulation; anticoagulant target, F04a | REPORTED |
| NMDA receptor (GluN1/GluN2) | GRIN1/GRIN2A | — (unfilled) | UNKNOWN (no PDB ID verified in this entry's research) | Excitotoxicity axis, F04a | UNKNOWN — recorded as gap, not skipped |
| P2Y12 receptor | P2RY12 | — (unfilled) | UNKNOWN (no PDB ID verified in this entry's research) | Antiplatelet-ladder target, F09 | UNKNOWN — recorded as gap |
| Thrombin | F2 | — (unfilled) | UNKNOWN (no PDB ID verified in this entry's research) | Coagulation effector | UNKNOWN — recorded as gap |

(UniProt ID for PLAT sourced from the session's research tool output; remaining UniProt IDs deliberately left unfilled rather than written from memory — UNKNOWN.)

---

## ED-ENC-FIELD-06 — 3D MODEL REFERENCES

The WebGL/Mol* pattern per the ALS 3D molecular guide (ED-MED-202A0907-DCLM-ALS-3D-MANIPULATOR-V1). Mol* link form: `https://molstar.org/viewer/?rcsb=<PDB>`. Manipulability is the bar: rotate, zoom, pan in any browser. A static image is not a 3D reference.

| Target | PDB | Mol* viewer link | RCSB record |
|---|---|---|---|
| tPA catalytic domain + benzamidine | 1RTF | https://molstar.org/viewer/?rcsb=1RTF | rcsb.org/structure/1RTF |
| Factor Xa + apixaban | 2P16 | https://molstar.org/viewer/?rcsb=2P16 | rcsb.org/structure/2P16 |
| NMDA receptor | — | UNKNOWN — no structure verified | recorded as gap (F05) |
| P2Y12 | — | UNKNOWN — no structure verified | recorded as gap (F05) |
| Thrombin | — | UNKNOWN — no structure verified | recorded as gap (F05) |

No DCLM-refined complex PDBs for stroke targets are banked on Drive in this entry's research — UNKNOWN. (Mol* links follow the standard's own pattern but were not live smoke-tested in this session — see UNKNOWN register.)

---

## ED-ENC-FIELD-07 — SIMULATION SPECIFICATION

**What counts as a simulation** (the standard's bar): a deterministic execution of a disease model that emits verifiable state transitions — DiseaseModelSpec + parameter manifest + initial state + regime + integrator settings → full state trajectory + summary metrics. Dual-pipeline structure (Pole A kinetics ΔG → Kd → engagement, Pole B systems ODEs), fail-closed watchdog (<4.20 ms), regime honesty, metrics-only outputs are shadows, not simulations.

**No staged simulation material exists for ischaemic stroke.** The five engine-registered models include no stroke model. **Therefore, this entry banks no simulation.** The specification below is what a stroke simulation under this standard WOULD be — a normative scaffold, not a run:

- **DiseaseModelSpec:** Ischaemic-stroke dual-pipeline model. Pole A: tPA–plasminogen fibrinolysis kinetics (competitive benzamidine-scaffold occupancy from 1RTF geometry), Factor Xa–thrombin cascade module (apixaban occupancy from 2P16 geometry), platelet-activation module (ADP/P2Y12, thromboxane, thrombin inputs). Pole B: territory perfusion ODE network — arterial occlusion site, collateral-flow module, core/penumbra two-compartment model with viability-clock state, BBB-breakdown module, haemorrhagic-transformation hazard module, oedema module; cross-talk from thrombus composition (red vs white) to fibrinolysis rate.
- **Parameter manifest:** REPORTED structural parameters (from the PDB complexes in F05), REPORTED clinical rates (reperfusion time-window data, collateral-grade distributions), and named UNKNOWN parameters (per-cell viability clocks, fast-vs-slow progressor partition, haemorrhagic-transformation coefficients) — each labeled per F12.
- **Regime:** declared at execution (CLOSED_LOOP / STANDALONE_AI / STANDALONE_SYSTEMS); a STANDALONE_AI result would never be presented as a closed-loop result.
- **Integrator:** fixed-step, deterministic, bit-identical trajectories.

This scaffold is DRAFT design — no model was executed for this entry. Nothing here is presented as a result.

---

## ED-ENC-FIELD-08 — HASH VERIFICATION RECORD

**No simulation was executed under this standard for this entry; therefore no hash exists.** The SHA-256 record covers (spec + parameters + initial state + regime + integrator + full trajectory) — with no executed simulation, there is nothing to hash, and this entry claims nothing.

**Hash discipline restated:** when a stroke simulation is executed under the F07 scaffold, its hash will be banked here with the full reproducibility manifest. Until then this field stands open and confessed. This confessed absence is the single blocking gap for COMPLETE (see self-grade).

---

## ED-ENC-FIELD-09 — TREATMENT LADDER (DOCUMENTED, STAGED)

Atlas posture: third person, past tense of the literature, named sources. What the field does — never what any person should do. This ladder documents established knowledge; it is not advice and contains no second-person language.

**Acute reperfusion.** Per the 2019 AHA/ASA Guideline for the Early Management of Patients With Acute Ischemic Stroke (Powers et al., Stroke 2019), the REPORTED ladder comprised: (1) intravenous alteplase (tPA) within 4.5 hours of last-known-well in eligible patients (the NINDS 1995 and ECASS III 2008 trials were the REPORTED evidence base); (2) mechanical thrombectomy with stent retrievers for large-vessel occlusion up to 6 hours (MR CLEAN, ESCAPE, SWIFT PRIME, REVASCAT — 2015; DAWN and DEFUSE 3 — 2018 extending the window to 24 hours in imaging-selected patients). Tenecteplase was REPORTED as an alternative thrombolytic in later practice (not in the 2019 guideline's main line — fenced as later REPORTED literature). [REPORTED — Powers et al., Stroke 2019; NINDS 1995; ECASS III 2008; MR CLEAN/ESCAPE/SWIFT PRIME/REVASCAT 2015; DAWN/DEFUSE 3 2018]

**Secondary prevention.** Per the 2021 AHA/ASA Guideline for the Prevention of Stroke in Patients With Stroke and TIA (Kleindorfer et al., Stroke 2021), the REPORTED ladder comprised: (1) antiplatelet therapy — aspirin, clopidogrel, or aspirin+extended-release dipyridamole; short-term dual antiplatelet therapy (aspirin+clopidogrel) for minor stroke/high-risk TIA (POINT 2018, CHANCE 2013); (2) anticoagulation for cardioembolic stroke with atrial fibrillation — direct oral anticoagulants preferred over warfarin (RE-LY 2009, ROCKET-AF 2011, ARISTOTLE 2011, ENGAGE-AF 2013); (3) high-intensity statin; (4) carotid revascularization for symptomatic high-grade stenosis; (5) blood-pressure and diabetes management. [REPORTED — Kleindorfer et al., Stroke 2021; POINT; CHANCE; RE-LY; ROCKET-AF; ARISTOTLE; ENGAGE-AF]

**Mechanistic ties to F04–F05:** alteplase/tenecteplase act at the PLAT–plasmin axis (F05, 1RTF); direct oral anticoagulants act at Factor Xa (F05, 2P16 — apixaban geometry) or thrombin; antiplatelets act at the platelet-activation module (F04a). The excitotoxic axis (F04a) had no REPORTED ladder rung — every neuroprotection trial failed, and the ladder confesses this rather than hiding it.

---

## ED-ENC-FIELD-10 — PHARMACOLOGY — SLOT HELD, SEALED

**SEALED — Stage-1 pharmacology held; lift gated on Condition 6.**

Nothing more is written here. The slot's emptiness is the honest content. No simulation in this entry used pharmacology-stage material as an input; no entry content synthesizes what the sealed stage would contain. "The drug would probably…" is modeling around the seal — refused by construction.

---

## ED-ENC-FIELD-11 — UNKNOWN REGISTER

Per-field confessions. A field with no named UNKNOWNs would be an incomplete field.

- **F01:** MONDO ID not banked. Chain-verdict history empty — no independent scorer has graded this entry.
- **F02:** TIA (8B40) and haemorrhagic stroke are named but fenced out — the definition does not cover them.
- **F03:** Cryptogenic stroke after complete workup; the ESUS treatment question (NAVIGATE ESUS, RESPECT ESUS — both negative for anticoagulation).
- **F04a:** The neuroprotection translation failure (animals → humans); in-situ tPA–plasminogen kinetics at the human thrombus; molecular determinants of haemorrhagic transformation.
- **F04b:** The per-cell human penumbral viability clock; the ordered sequence of BBB breakdown; the dominant cell-death program in human penumbra.
- **F04c:** Fast vs slow progressor determinants; determinants of malignant oedema.
- **F04d:** Organ-level predictors of recovery beyond the acute phase; determinants of post-stroke cognitive trajectories.
- **F04e:** Systemic mediators of post-stroke immunosuppression; why some cryptogenic strokes never reveal a source.
- **F05:** No PDB verified in this entry for the NMDA receptor, P2Y12, or thrombin (absence recorded as data). Several UniProt IDs deliberately left unfilled.
- **F06:** Mol* links follow the standard's own pattern but were not live smoke-tested in this session; RCSB records were reached via search-result pages, not direct record verification of every ID's current status.
- **F07:** No simulation executed; the scaffold is normative design, not a run.
- **F08:** No hash exists — confessed absence, the blocking gap.
- **F09:** Ladder reflects the 2019 acute and 2021 secondary-prevention AHA/ASA guidelines plus named trials as retrieved via web search; guidelines evolve — the ladder is dated to its sources. Tenecteplase is fenced as later literature outside the 2019 guideline's main line. Dosing detail deliberately omitted (atlas, not formulary).
- **F10:** Contents unknown by design (sealed). Hold-lift condition (Condition 6) still open.
- **F12:** Weakest-label audit performed by the authoring swarm only; independent double-scoring pending.

**Deepest UNKNOWNs (load-bearing, named for the coordinator):**
1. **No executed, hash-anchored simulation exists for ischaemic stroke under this standard.** This single gap is what blocks COMPLETE and caps the grade at PARTIAL.
2. **Neuroprotection is the field's central failure** — the excitotoxic cascade is REPORTED in animals and has failed in every human trial; the entry names the disconnect rather than resolving it.
3. **Cryptogenic stroke remains cryptogenic** — ESUS trials were negative; the entry does not invent an answer.
4. **Pharmacology is sealed** — the slot is held, not worked around.

---

## ED-ENC-FIELD-12 — PROVENANCE MANIFEST

Every claim carries REPORTED / MODELED / UNKNOWN. Weakest-label rule applied throughout.

| Claim | Label | Source |
|---|---|---|
| ICD-11 8B11 = Cerebral ischaemic stroke | REPORTED | ICD-11 MMS v2026-01 (findacode) |
| Canonical definition (occlusion → penumbra → infarction; mechanism-based classification) | REPORTED | established literature (TOAST/ASCOD scheme) |
| TOAST etiologic categories (large-artery, cardioembolic, small-vessel, other, undetermined) | REPORTED | established literature |
| ESUS trials negative for anticoagulation (NAVIGATE ESUS, RESPECT ESUS) | REPORTED | published trial results |
| PDB 1RTF (tPA catalytic domain + benzamidine) | REPORTED | RCSB PDB record (Renatus et al.) |
| PDB 2P16 (Factor Xa + apixaban; corrected ligand identity) | REPORTED | RCSB PDB record (Pinto et al., J Med Chem 2007) |
| UniProt P00750 (PLAT) | REPORTED | session research tool output |
| Ischaemic cascade (ATP failure → excitotoxicity → calcium overload) | REPORTED | experimental literature |
| Core/penumbra construct; collateral grade as outcome predictor | REPORTED | established literature |
| Thrombus red/white histologic distinction | REPORTED | established literature |
| NIHSS and mRS as severity/outcome scales | REPORTED | established literature |
| Animal-to-human penumbral window transfer | MODELED | inferred from experimental literature |
| Thrombus histology predicting retrievability | MODELED | correlation-inferred |
| Post-stroke inflammation driving secondary injury | MODELED | inferred; direction unestablished |
| Treatment ladder (F09) | REPORTED | Powers et al., Stroke 2019 (2019 AHA/ASA early-management guideline); Kleindorfer et al., Stroke 2021 (2021 AHA/ASA secondary-prevention guideline); NINDS 1995; ECASS III 2008; MR CLEAN/ESCAPE/SWIFT PRIME/REVASCAT 2015; DAWN/DEFUSE 3 2018; POINT 2018; CHANCE 2013; RE-LY 2009; ROCKET-AF 2011; ARISTOTLE 2011; ENGAGE-AF 2013 |
| F07 simulation scaffold | MODELED | designed from the standard's bar; no execution — labeled design, not result |
| F08 hash record | UNKNOWN (confessed absence) | no executed simulation |
| F10 pharmacology | SEALED | stage-1 seal, Condition-6 lift pending |
| Neuroprotection translation failure; fast/slow progressors; cryptogenic determinants | UNKNOWN | named in F11 |
| Weakest-label compliance | Self-audited | independent double-scoring pending |

---

## SELF-GRADE AGAINST THE COMPLETENESS RUBRIC

**Rubric criteria (ED-ENC-20260929 §2):**

1. *All twelve fields present; none absent.* ✅ — F01–F12 all present; F07/F08/F10 present-but-fenced (permitted).
2. *All five scales closed or explicitly fenced.* ✅ — F04a–e each carry knowns / borrowed inferences / named UNKNOWNs.
3. *F06: every structural target with a PDB ID carries a Mol\* link; targets without structures named as UNKNOWN.* ✅ — 2 structures linked via the standard's Mol* pattern; NMDA receptor, P2Y12, thrombin named as UNKNOWN, not skipped. (Links not live smoke-tested — confessed in F11.)
4. *F07–F08: at least one simulation executed under the bar with an anchored, recomputable SHA-256 hash.* ❌ — **This is the failing criterion.** No simulation was executed. Nothing is hash-anchored.
5. *F09: ladder from named sources; no second-person language.* ✅ — 2019 and 2021 AHA/ASA guidelines and named trials cited; third person throughout.
6. *F10: slot present and correctly marked SEALED with the hold condition named.* ✅ — verbatim seal text, Condition 6 named.
7. *F12: every claim labeled; weakest-label rule applied; zero unlabeled claims.* ✅ (self-audit) — independent double-scoring still pending.

**Grade: PARTIAL.** Reasoning: schema-shaped with honestly populated load-bearing fields, but criterion 4 fails — no hash-anchored simulation exists, and the entry cannot honestly claim SUBSTANTIAL either, since SUBSTANTIAL requires ≥1 executed simulation and there is no executed simulation at all. The F07 scaffold is genuine design — the dual-pipeline stroke model (Pole A fibrinolysis/cascade/platelet kinetics, Pole B core-penumbra/collateral/BBB/haemorrhage ODE network) — but design is not execution, and the standard is explicit: a scaffold without a run is not a simulation. Grading the design as a simulation would launder gloss into the arithmetic. So: PARTIAL, with the single blocking gap named — execute a stroke simulation under the F07 scaffold, bank the trajectory, anchor the hash, and this entry moves toward SUBSTANTIAL (then COMPLETE once 3D links are smoke-tested and independent double-scoring lands).

**Self-grade confidence:** performed by the authoring swarm against the written rubric; per the standard's residual 5, the first independent double-scoring will test whether the rubric reproduces. This grade is provisional pending verdict-gating.

---

## CHAIN-OF-CUSTODY NOTES (for the coordinator)

- No staged design papers existed for this disease; all REPORTED claims derive from web research conducted 2026-09-29, labeled per source. PDB IDs were taken from RCSB-indexed records with cited deposition literature; ICD-11 from the MMS v2026-01 via findacode.
- The 2P16 ligand identity was corrected during research (apixaban, not rivaroxaban) and the correction is preserved here — not the other way around.
- No second-person language anywhere in F09; atlas-not-advisor fence held.
- Pharmacology seal: held exactly, never modeled around.
- DRAFT only. No seal. Nothing deploys. The launch gate holds.

*End of ED-ENC-CARDIO-003 V1 — DRAFT, no seal, gate holds.*
