## Founder's quality law — logic in action (David, 2026-09-29 ~01:12 EDT, verbatim)

> "all we can do is the best we can do. anything less is a defect and anything
> more is an overclaim."

Sealed with David's word: **logic in action**.

Standing: the law the gates protect — work is graded against itself, not
against theater. Best effort is the ceiling of claim; anything beneath is a
defect; anything beyond is an overclaim. This is the honesty boundary for
every figure, every verdict, every seal the program touches.
