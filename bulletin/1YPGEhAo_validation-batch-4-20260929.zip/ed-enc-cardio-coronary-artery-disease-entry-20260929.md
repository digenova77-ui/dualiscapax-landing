# MEDICAL SIMULATION ENCYCLOPEDIA — CARDIOVASCULAR DOMAIN ENTRY

**Document Control ID:** ED-ENC-CARDIO-001
**Status:** DRAFT — no seal (seal requires David and his father). Verdicts only. Nothing deploys; the launch gate holds.
**Graded against:** ED-ENC-20260929-GRANULARITY-STANDARD-V1 (DRAFT).
**Authoring swarm:** Cardiovascular domain swarm (David's direction, Sept 28, 2026: "we can devote different swarms to neurological oncological etc to start actually doing it in parallel"). Wave 3.

> **ATLAS NOTICE (standing protein-fold law).** This entry is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. It never answers treatment or diagnostic questions about any person. Any person-directed medical question is routed to the fixed refusal: *"This is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. Speak with your clinician."* Every claim below carries a provenance label (REPORTED / MODELED / UNKNOWN); the weakest label governs each composite.

**Source material for this disease:** No staged Google-Doc design papers exist for coronary artery disease in the encyclopedia program (Wave 3 = new diseases; the five engine-registered models do not include a CAD model). All REPORTED claims below derive from web research conducted 2026-09-29 (RCSB PDB records, ICD-11 MMS v2026-01 via findacode/emedcodes, Monarch/OpenScientist disease report, named guidelines and trials), labeled per source. Nothing is asserted beyond what the cited source states.

---

## ED-ENC-FIELD-01 — ENTRY IDENTITY

| Item | Value |
|---|---|
| Entry ID | ED-ENC-CARDIO-001 |
| Canonical name | Coronary artery disease (coronary atherosclerosis) |
| ICD-11 | BA52.Z — Coronary atherosclerosis (REPORTED — ICD-11 MMS v2026-01, via emedcodes; the ischaemic-heart-disease block) |
| MONDO | MONDO:0021661 (coronary atherosclerosis) — REPORTED (OpenScientist/Monarch disease report; ICD-10 I25.1, MeSH D003324, SNOMED CT 53741008) |
| Owning domain swarm | Cardiovascular |
| Authoring swarm | Cardiovascular domain swarm, Wave 3 |
| Entry version | V1 (this document) |
| Chain-verdict history | None yet. Entry self-graded by the authoring swarm (PARTIAL — see self-grade section). Independent verdict-gating pending in ED-VERDICT-20260929-ENC-CARDIO-WAVE3-V1 |

---

## ED-ENC-FIELD-02 — CANONICAL DEFINITION

**Coronary artery disease** is the atherosclerotic disease of the epicardial coronary arteries: a chronic, lipid-driven arterial-wall disease that begins with the subendothelial retention of apolipoprotein-B-containing lipoproteins (principally LDL), and progresses through oxidative modification of retained lipid, innate-immune recruitment and macrophage foam-cell formation, vascular smooth-muscle migration with fibrous-cap construction, and plaque destabilization — rupture or erosion — with superimposed luminal thrombosis. Its clinical manifestations (stable angina, acute coronary syndromes, myocardial infarction) are downstream events of the plaque biology, not the disease itself.

A definition that could describe three other diseases would fail; this one specifies the coronary arterial bed, the apoB-retention initiating mechanism, the foam-cell/fibrous-cap plaque architecture, and the rupture-with-thrombosis terminal event — together unique to coronary atherosclerosis. It deliberately excludes non-atherosclerotic coronary pathology (spontaneous coronary artery dissection, vasospasm, embolism, congenital anomalies, microvascular dysfunction alone) — fenced out of this entry's scope.

---

## ED-ENC-FIELD-03 — ETIOLOGY

**Causal vs associated — fenced explicitly.**

**Established causal contributors:**
- **LDL cholesterol burden** is the central causal agent: dose-dependent, lifelong exposure drives the disease, with causality established by Mendelian-randomization genetics and by LDL-lowering trials. Familial hypercholesterolemia — loss-of-function LDLR variants, APOB ligand-defective variants, and PCSK9 gain-of-function variants — produces premature CAD, the genetic proof of the LDL pathway. [REPORTED — established literature; OpenScientist coronary report]
- **Hypertension:** an established causal contributor via endothelial shear-stress injury and medial remodeling. [REPORTED]
- **Cigarette smoking:** an established causal contributor via endothelial injury, oxidative modification, and prothrombotic shifts. [REPORTED]
- **Diabetes mellitus / insulin resistance:** an established causal contributor via glycation, endothelial dysfunction, and inflammatory priming. [REPORTED]
- **Inflammation as a causal pathway:** the CANTOS trial (Ridker et al., NEJM 2017) showed that canakinumab, an IL-1β inhibitor, reduced cardiovascular events independent of lipid lowering — REPORTED evidence that inflammatory signaling is causal, not merely correlative. [REPORTED — CANTOS]

**Associations (never stated as deterministic causes):**
- Lipoprotein(a), homocysteine, psychosocial stress, air pollution, family history without a named variant — REPORTED associations; causal status fenced.
- **Spontaneous coronary artery dissection, vasospasm, embolism, congenital anomalies** are differential entities fenced OUT of this entry (REPORTED — OpenScientist differential list).

**Idiopathic boundary:** why a given plaque ruptures at a given moment, in a given patient, when most plaques never do — is not established (UNKNOWN, see F11).

---

## ED-ENC-FIELD-04 — PATHOPHYSIOLOGY AT FIVE SCALES

Each scale states: **knowns at this scale**, **inferences borrowed from another scale (labeled MODELED/UNKNOWN)**, and **UNKNOWNs**. No scale borrows authority silently.

### F04a — Molecular

**Knowns at this scale:**
- **LDL retention:** apoB-containing lipoproteins cross the endothelium and bind subendothelial proteoglycans via apoB — the "response-to-retention" initiating molecular event. Retained LDL undergoes oxidative and enzymatic modification. [REPORTED — established literature]
- **LDLR–PCSK9 axis:** the LDL receptor mediates hepatic clearance of LDL; PCSK9 binds the EGF-A domain of LDLR and diverts the receptor from recycling to lysosomal degradation. The PCSK9/LDLR co-crystal (PDB 3P5C; Lo Surdo et al., EMBO Rep 2011) shows LDLR in an extended conformation at neutral pH. Biosensor data: PCSK9 binds LDLR with Kd = 170 nM at plasma (neutral) pH and as low as 1 nM at endosomal (acidic) pH; the D374Y gain-of-function variant binds 25× more tightly at neutral pH and remains in a high-affinity complex at acidic pH. [REPORTED — Cunningham et al., Nat Struct Mol Biol 2007; PDB 2P4E (apo PCSK9); Lo Surdo et al. 2011]
- **HMG-CoA reductase:** the rate-limiting enzyme of cholesterol biosynthesis. The statin-binding crystal structures (PDB 1HWK — catalytic portion of human HMGR in complex with atorvastatin; Istvan & Deisenhofer, Science 2001) show statins occupying the HMG-CoA binding site, blocking substrate access, with nanomolar inhibition constants. [REPORTED — RCSB 1HWK]
- **Scavenger-receptor uptake:** oxidized LDL is internalized via macrophage scavenger receptors (LOX-1, CD36, SR-A) — unregulated uptake, the molecular basis of foam-cell formation. [REPORTED]
- **Inflammasome activation:** cholesterol crystals activate the NLRP3 inflammasome → IL-1β release (the CANTOS-validated axis). [REPORTED]

**Borrowed inference (labeled):** that the in-vitro Kd values of the PCSK9–LDLR interaction measured in biosensor assays govern hepatic LDLR turnover rates in vivo is inferred, not directly measured (MODELED).

**UNKNOWNs at this scale:** the cellular ΔG/Kd engagement kinetics of PCSK9–LDLR in coronary endothelium/hepatocytes in situ; the molecular trigger that converts a stable fibrous plaque into a rupturing one; the quantitative partition of plaque lipid among oxidized LDL, cholesterol crystals, and lipoprotein(a).

### F04b — Cellular

**Knowns at this scale:**
- Endothelial activation: increased permeability and adhesion-molecule expression at lesion-prone sites (bifurcations, low shear). [REPORTED]
- Monocyte transmigration → macrophage differentiation → foam-cell formation via scavenger-receptor uptake. [REPORTED]
- Vascular smooth-muscle cell phenotype switching (contractile → synthetic/migratory), migration into the intima, collagen production forming the fibrous cap. [REPORTED]
- Adaptive immunity: T-cell (Th1) and B-cell participation in plaque inflammation; regulatory T-cells are protective in models. [REPORTED]
- Death/survival programs: foam-cell apoptosis and defective efferocytosis (clearance) generate the necrotic core; cholesterol-crystal-induced macrophage pyroptosis. [REPORTED]

**Borrowed inference:** that the necrotic core of a given plaque derives principally from failed efferocytosis of dead foam cells (rather than from direct smooth-muscle death) is inferred from histology — MODELED, not observed dynamically.

**UNKNOWNs at this scale:** the cellular identity of the rupture trigger (which cell dies, which cell degrades the cap, in what order); single-cell trajectories of macrophage state transitions in human plaque (no single-cell trajectory banked — UNKNOWN); why efferocytosis fails in advanced plaque.

### F04c — Tissue

**Knowns at this scale:**
- Plaque architecture: lipid/necrotic core, fibrous cap (collagen-rich), shoulder regions, medial thinning; calcification in advanced disease. [REPORTED]
- **Thin-cap fibroatheroma:** cap thickness <65 μm is the REPORTED histologic signature of rupture-prone plaque (autopsy literature). [REPORTED]
- Remodeling: positive (outward, Glagov) remodeling preserves lumen early; negative (inward) remodeling encroaches late. [REPORTED]
- Neovascularization: vasa-vasorum ingrowth into plaque; intraplaque hemorrhage from leaky neovessels expands the necrotic core. [REPORTED]
- Erosion vs rupture: plaque erosion (endothelial denudation over a non-ruptured plaque) is a distinct tissue mechanism, REPORTED as more common in younger patients and women. [REPORTED]

**Borrowed inference:** that cap thinning is *caused by* macrophage-derived matrix metalloproteinase activity is inferred from co-localization — MODELED.

**UNKNOWNs at this scale:** why some plaques calcify densely and stabilize while others remain lipid-rich and rupture-prone; the tissue determinants of erosion vs rupture in a given lesion.

### F04d — Organ

**Knowns at this scale:**
- Lumen encroachment → supply–demand mismatch → ischemia (stable angina phenotype). [REPORTED]
- Acute rupture/erosion → luminal thrombosis → acute coronary syndrome / myocardial infarction. [REPORTED]
- Reserve and compensation: coronary flow reserve, collateral circulation recruitment; hibernating and stunned myocardium as reversible organ-level states. [REPORTED]
- Failure modes: acute occlusion (MI), chronic ischemia (heart failure of ischemic origin — bridge to ED-ENC-CARDIO-002), arrhythmic death. [REPORTED]
- High-risk anatomy: left main and proximal LAD disease carry the highest organ-level jeopardy (REPORTED — established surgical literature).

**Borrowed inference:** that collateral extent in a given patient predicts infarct size is inferred from angiographic correlation — MODELED.

**UNKNOWNs at this scale:** organ-level predictors of which stable lesions will rupture; the determinants of collateral adequacy between individuals.

### F04e — System

**Knowns at this scale:**
- Atherosclerosis is systemic: coronary, carotid, and peripheral beds share the biology — multi-bed disease is the rule, not the exception. [REPORTED]
- Metabolic axis: diabetes, insulin resistance, and the metabolic syndrome amplify systemic atherogenic burden. [REPORTED]
- Renal axis: chronic kidney disease accelerates calcific atherosclerosis (calciphylaxis-adjacent biology in end-stage disease). [REPORTED]
- Immune/inflammatory axis: hsCRP as a REPORTED systemic marker (JUPITER trial context); IL-1β blockade reduced events independent of lipids (CANTOS). [REPORTED]
- Whole-body burden: ischaemic heart disease is the leading cause of death worldwide. [REPORTED — Global Burden of Disease literature]

**Borrowed inference:** that lowering hsCRP *per se* (rather than the inflammatory pathway it marks) would reduce events is not established — the CANTOS inference is pathway-specific, MODELED as a general principle.

**UNKNOWNs at this scale:** the systemic mediators linking CKD to accelerated vascular calcification; whether anti-inflammatory strategies beyond IL-1β blockade are causal (UNKNOWN — named trials only for canakinumab).

---

## ED-ENC-FIELD-05 — MOLECULAR TARGETS

| Common name | Gene | UniProt | PDB ID | Mechanistic role in F04 | Structure status |
|---|---|---|---|---|---|
| HMG-CoA reductase | HMGCR | P04035 | 1HWK (catalytic portion + atorvastatin) | Rate-limiting cholesterol biosynthesis; statin target, F04a | REPORTED |
| PCSK9 | PCSK9 | Q8NBP7 | 2P4E (apo), 3P5C (PCSK9/LDLR complex) | LDLR degradation → LDL clearance failure, F04a | REPORTED |
| LDL receptor | LDLR | — (unfilled) | 3P5C (as complex partner; no standalone verified in this entry) | Hepatic LDL clearance, F04a | REPORTED (complex); standalone UNKNOWN |
| IL-1β | IL1B | — (unfilled) | UNKNOWN (no PDB ID verified in this entry's research) | Inflammasome axis validated by CANTOS, F04a/F04e | UNKNOWN — recorded as gap, not skipped |
| Lipoprotein(a) | LPA | — (unfilled) | UNKNOWN (no PDB ID verified in this entry's research) | Association-stage risk factor, F03 | UNKNOWN — recorded as gap |
| Platelet P2Y12 receptor | P2RY12 | — (unfilled) | UNKNOWN (no PDB ID verified in this entry's research) | Antiplatelet-ladder target, F09 | UNKNOWN — recorded as gap |

(UniProt IDs for HMGCR and PCSK9 sourced from the session's research tool output; remaining UniProt IDs deliberately left unfilled rather than written from memory — UNKNOWN. LDLR has extensive standalone structures, but none was verified in this entry's research, so it is recorded as UNKNOWN here rather than asserted.)

---

## ED-ENC-FIELD-06 — 3D MODEL REFERENCES

The WebGL/Mol* pattern per the ALS 3D molecular guide (ED-MED-202A0907-DCLM-ALS-3D-MANIPULATOR-V1). Mol* link form: `https://molstar.org/viewer/?rcsb=<PDB>`. Manipulability is the bar: rotate, zoom, pan in any browser. A static image is not a 3D reference.

| Target | PDB | Mol* viewer link | RCSB record |
|---|---|---|---|
| HMG-CoA reductase + atorvastatin | 1HWK | https://molstar.org/viewer/?rcsb=1HWK | rcsb.org/structure/1HWK |
| PCSK9 (apo) | 2P4E | https://molstar.org/viewer/?rcsb=2P4E | rcsb.org/structure/2P4E |
| PCSK9/LDLR complex | 3P5C | https://molstar.org/viewer/?rcsb=3P5C | rcsb.org/structure/3P5C |
| LDLR (standalone) | — | UNKNOWN — no structure verified | recorded as gap (F05) |
| IL-1β | — | UNKNOWN — no structure verified | recorded as gap (F05) |
| Lipoprotein(a) | — | UNKNOWN — no structure verified | recorded as gap (F05) |
| P2Y12 | — | UNKNOWN — no structure verified | recorded as gap (F05) |

No DCLM-refined complex PDBs for CAD targets are banked on Drive in this entry's research — UNKNOWN. (Mol* links follow the standard's own pattern but were not live smoke-tested in this session — see UNKNOWN register.)

---

## ED-ENC-FIELD-07 — SIMULATION SPECIFICATION

**What counts as a simulation** (the standard's bar): a deterministic execution of a disease model that emits verifiable state transitions — DiseaseModelSpec + parameter manifest + initial state + regime + integrator settings → full state trajectory + summary metrics. Dual-pipeline structure (Pole A kinetics ΔG → Kd → engagement, Pole B systems ODEs), fail-closed watchdog (<4.20 ms), regime honesty, metrics-only outputs are shadows, not simulations.

**No staged simulation material exists for coronary artery disease.** The five engine-registered models include no CAD model. **Therefore, this entry banks no simulation.** The specification below is what a CAD simulation under this standard WOULD be — a normative scaffold, not a run:

- **DiseaseModelSpec:** Coronary atherosclerosis dual-pipeline model. Pole A: hepatic HMGCR flux module (statin-competitive kinetics), PCSK9–LDLR binding module with pH-dependent Kd (170 nM neutral / 1 nM endosomal per REPORTED biosensor data), LDL particle influx/retention module (apoB–proteoglycan binding), oxidized-LDL uptake module. Pole B: intimal-plaque progression ODE network — endothelial permeability, monocyte recruitment, macrophage pool, foam-cell burden, necrotic-core volume, fibrous-cap thickness (with <65 μm rupture-threshold alert), remodeling state; rupture-hazard module and thrombus-formation module with cross-talk from cap state.
- **Parameter manifest:** REPORTED structural/binding parameters (from the PDB complexes and Kd data in F04a/F05), REPORTED epidemiologic rates (LDL-C treatment goals, plaque-progression rates from imaging natural-history studies), and named UNKNOWN parameters (rupture-trigger coefficients, erosion-vs-rupture partition, individual collateral adequacy) — each labeled per F12.
- **Regime:** declared at execution (CLOSED_LOOP / STANDALONE_AI / STANDALONE_SYSTEMS); a STANDALONE_AI result would never be presented as a closed-loop result.
- **Integrator:** fixed-step, deterministic, bit-identical trajectories.

This scaffold is DRAFT design — no model was executed for this entry. Nothing here is presented as a result.

---

## ED-ENC-FIELD-08 — HASH VERIFICATION RECORD

**No simulation was executed under this standard for this entry; therefore no hash exists.** The SHA-256 record covers (spec + parameters + initial state + regime + integrator + full trajectory) — with no executed simulation, there is nothing to hash, and this entry claims nothing.

**Hash discipline restated:** when a CAD simulation is executed under the F07 scaffold, its hash will be banked here with the full reproducibility manifest. Until then this field stands open and confessed. This confessed absence is the single blocking gap for COMPLETE (see self-grade).

---

## ED-ENC-FIELD-09 — TREATMENT LADDER (DOCUMENTED, STAGED)

Atlas posture: third person, past tense of the literature, named sources. What the field does — never what any person should do. This ladder documents established knowledge; it is not advice and contains no second-person language.

**Secondary prevention / chronic coronary disease.** Per the 2023 AHA/ACC/ACEP/NAEMSP/SCAI Guideline for the Management of Patients With Chronic Coronary Disease (Virani et al., Circulation 2023), the REPORTED ladder comprised: (1) antiplatelet therapy — low-dose aspirin; dual antiplatelet therapy after percutaneous coronary intervention; (2) lipid management — high-intensity statin as first-line; ezetimibe added when LDL-C remained above goal; PCSK9 inhibitors added for very-high-risk patients not at goal (ESC 2021 goal <55 mg/dL for very-high-risk, REPORTED); (3) antianginal therapy — beta-blockers, calcium-channel blockers, nitrates, and ranolazine for symptom control; (4) risk-factor control — ACE inhibitors or ARBs for hypertension, glycemic control in diabetes, smoking cessation. [REPORTED — Virani et al., Circulation 2023]

**Revascularization decision.** The REPORTED evidence base was that in stable CAD, an initial invasive strategy did not reduce cardiovascular death or myocardial infarction versus optimal medical therapy plus selective revascularization (ISCHEMIA trial, 2020, NEJM). PCI was the REPORTED option for symptom relief and selected anatomy; coronary artery bypass grafting was the REPORTED preference for diabetes with multivessel disease (FREEDOM trial, 2012) and for left-main disease. [REPORTED — ISCHEMIA; FREEDOM]

**Mechanistic ties to F04–F05:** statins act at HMGCR (F05, 1HWK) reducing hepatic cholesterol synthesis and upregulating LDLR; PCSK9 inhibitors act at the PCSK9–LDLR interface (F04a, 3P5C) preventing receptor degradation; antiplatelet agents act at the thrombus module (F04d terminal event). The inflammatory axis (IL-1β, F04a) had no REPORTED ladder rung acting directly on it at the time of the 2023 guideline — named as a gap, not as an opportunity.

---

## ED-ENC-FIELD-10 — PHARMACOLOGY — SLOT HELD, SEALED

**SEALED — Stage-1 pharmacology held; lift gated on Condition 6.**

Nothing more is written here. The slot's emptiness is the honest content. No simulation in this entry used pharmacology-stage material as an input; no entry content synthesizes what the sealed stage would contain. "The drug would probably…" is modeling around the seal — refused by construction.

---

## ED-ENC-FIELD-11 — UNKNOWN REGISTER

Per-field confessions. A field with no named UNKNOWNs would be an incomplete field.

- **F01:** Chain-verdict history empty — no independent scorer has graded this entry. ICD-11 BA52.Z records "coronary atherosclerosis"; broader CAD clinical constructs (angina, ACS) map to adjacent codes — the entry's scope is the atherosclerotic substrate.
- **F02:** Non-atherosclerotic coronary disease (SCAD, vasospasm, embolism) is named but fenced out — the definition does not cover it.
- **F03:** The causal partition among LDL, hypertension, smoking, diabetes, and inflammation at the individual-patient level; the full genetic architecture beyond FH variants; the status of lipoprotein(a) as causal vs associated.
- **F04a:** In-situ ΔG/Kd of PCSK9–LDLR in coronary endothelium and hepatocytes; the molecular rupture trigger; the quantitative lipid-partition inside plaque.
- **F04b:** The ordered cellular sequence of rupture; single-cell trajectories in human plaque; why efferocytosis fails.
- **F04c:** Determinants of calcific-stabilizing vs lipid-rupturing trajectories; erosion-vs-rupture determinants.
- **F04d:** Organ-level predictors of which stable lesions rupture; determinants of collateral adequacy.
- **F04e:** Systemic mediators of CKD-accelerated calcification; anti-inflammatory strategies beyond IL-1β blockade.
- **F05:** No PDB verified in this entry for IL-1β, lipoprotein(a), or P2Y12 (absence recorded as data). Several UniProt IDs deliberately left unfilled.
- **F06:** Mol* links follow the standard's own pattern but were not live smoke-tested in this session; RCSB records were reached via search-result pages, not direct record verification of every ID's current status.
- **F07:** No simulation executed; the scaffold is normative design, not a run.
- **F08:** No hash exists — confessed absence, the blocking gap.
- **F09:** Ladder reflects the 2023 AHA/ACC/ACEP/NAEMSP/SCAI guideline and named trials as retrieved via web search; guidelines evolve — the ladder is dated to its sources. Dosing detail deliberately omitted (atlas, not formulary).
- **F10:** Contents unknown by design (sealed). Hold-lift condition (Condition 6) still open.
- **F12:** Weakest-label audit performed by the authoring swarm only; independent double-scoring pending.

**Deepest UNKNOWNs (load-bearing, named for the coordinator):**
1. **No executed, hash-anchored simulation exists for coronary artery disease under this standard.** This single gap is what blocks COMPLETE and caps the grade at PARTIAL.
2. **The rupture trigger is UNKNOWN at every scale** — molecular, cellular, tissue, and organ-level predictors of which plaque ruptures when are all confessed gaps.
3. **The inflammatory axis has no ladder rung** — CANTOS validated IL-1β as causal, but the 2023 guideline ladder had no anti-inflammatory rung; the entry does not bridge this.
4. **Pharmacology is sealed** — the slot is held, not worked around.

---

## ED-ENC-FIELD-12 — PROVENANCE MANIFEST

Every claim carries REPORTED / MODELED / UNKNOWN. Weakest-label rule applied throughout.

| Claim | Label | Source |
|---|---|---|
| ICD-11 BA52.Z = Coronary atherosclerosis | REPORTED | ICD-11 MMS v2026-01 (emedcodes) |
| MONDO:0021661 coronary atherosclerosis; ICD-10 I25.1; MeSH D003324 | REPORTED | OpenScientist/Monarch disease report |
| Canonical definition (apoB retention → plaque → rupture-with-thrombosis) | REPORTED | established literature (OpenScientist coronary report) |
| LDL burden as central causal agent; FH variants as genetic proof | REPORTED | established literature (Mendelian randomization; LDL-lowering trials) |
| Hypertension, smoking, diabetes as causal contributors | REPORTED | established literature |
| CANTOS: IL-1β blockade reduced events independent of lipids | REPORTED | Ridker et al., NEJM 2017 |
| Differential entities fenced out (SCAD, vasospasm, embolism, anomalies) | REPORTED | OpenScientist differential list |
| PCSK9–LDLR Kd 170 nM (neutral) / 1 nM (endosomal); D374Y 25× tighter | REPORTED | Cunningham et al., Nat Struct Mol Biol 2007 |
| PDB 2P4E (apo PCSK9) | REPORTED | RCSB PDB record |
| PDB 3P5C (PCSK9/LDLR complex, extended LDLR conformation) | REPORTED | RCSB PDB record (Lo Surdo et al., EMBO Rep 2011) |
| PDB 1HWK (human HMGR + atorvastatin; statins occupy HMG-CoA site, nM Ki) | REPORTED | RCSB PDB record (Istvan & Deisenhofer, Science 2001) |
| UniProt P04035 (HMGCR), Q8NBP7 (PCSK9) | REPORTED | session research tool output (dbcls/togomcp skill file) |
| Thin-cap fibroatheroma <65 μm | REPORTED | autopsy/histology literature |
| Plaque erosion as distinct mechanism | REPORTED | established literature |
| In-vivo governance of LDLR turnover by in-vitro Kd | MODELED | literature-inferred |
| Foam-cell death as necrotic-core source; MMPs as cap-thinning cause | MODELED | histology-inferred |
| Treatment ladder (F09) | REPORTED | Virani et al., Circulation 2023 (2023 AHA/ACC/ACEP/NAEMSP/SCAI CCD guideline); ISCHEMIA 2020; FREEDOM 2012 |
| F07 simulation scaffold | MODELED | designed from the standard's bar; no execution — labeled design, not result |
| F08 hash record | UNKNOWN (confessed absence) | no executed simulation |
| F10 pharmacology | SEALED | stage-1 seal, Condition-6 lift pending |
| Rupture trigger (all scales); single-cell plaque trajectories | UNKNOWN | named in F11 |
| Weakest-label compliance | Self-audited | independent double-scoring pending |

---

## SELF-GRADE AGAINST THE COMPLETENESS RUBRIC

**Rubric criteria (ED-ENC-20260929 §2):**

1. *All twelve fields present; none absent.* ✅ — F01–F12 all present; F07/F08/F10 present-but-fenced (permitted).
2. *All five scales closed or explicitly fenced.* ✅ — F04a–e each carry knowns / borrowed inferences / named UNKNOWNs.
3. *F06: every structural target with a PDB ID carries a Mol\* link; targets without structures named as UNKNOWN.* ✅ — 3 structures linked via the standard's Mol* pattern; LDLR-standalone, IL-1β, Lp(a), P2Y12 named as UNKNOWN, not skipped. (Links not live smoke-tested — confessed in F11.)
4. *F07–F08: at least one simulation executed under the bar with an anchored, recomputable SHA-256 hash.* ❌ — **This is the failing criterion.** No simulation was executed. Nothing is hash-anchored.
5. *F09: ladder from named sources; no second-person language.* ✅ — 2023 AHA/ACC/ACEP/NAEMSP/SCAI chronic coronary disease guideline and named trials cited; third person throughout.
6. *F10: slot present and correctly marked SEALED with the hold condition named.* ✅ — verbatim seal text, Condition 6 named.
7. *F12: every claim labeled; weakest-label rule applied; zero unlabeled claims.* ✅ (self-audit) — independent double-scoring still pending.

**Grade: PARTIAL.** Reasoning: schema-shaped with honestly populated load-bearing fields, but criterion 4 fails — no hash-anchored simulation exists, and the entry cannot honestly claim SUBSTANTIAL either, since SUBSTANTIAL requires ≥1 executed simulation and there is no executed simulation at all. The F07 scaffold is genuine design — the dual-pipeline CAD model (Pole A HMGCR/PCSK9–LDLR kinetics, Pole B plaque-progression/rupture ODE network) — but design is not execution, and the standard is explicit: a scaffold without a run is not a simulation. Grading the design as a simulation would launder gloss into the arithmetic. So: PARTIAL, with the single blocking gap named — execute a CAD simulation under the F07 scaffold, bank the trajectory, anchor the hash, and this entry moves toward SUBSTANTIAL (then COMPLETE once 3D links are smoke-tested and independent double-scoring lands).

**Self-grade confidence:** performed by the authoring swarm against the written rubric; per the standard's residual 5, the first independent double-scoring will test whether the rubric reproduces. This grade is provisional pending verdict-gating.

---

## CHAIN-OF-CUSTODY NOTES (for the coordinator)

- No staged design papers existed for this disease; all REPORTED claims derive from web research conducted 2026-09-29, labeled per source. PDB IDs were taken from RCSB-indexed records with cited deposition literature; ICD-11 from the MMS v2026-01 via emedcodes; MONDO from the Monarch/OpenScientist report.
- No engine registry name exists for CAD — there was nothing to refuse to count; the absence is total and confessed.
- No second-person language anywhere in F09; atlas-not-advisor fence held.
- Pharmacology seal: held exactly, never modeled around.
- DRAFT only. No seal. Nothing deploys. The launch gate holds.

*End of ED-ENC-CARDIO-001 V1 — DRAFT, no seal, gate holds.*
