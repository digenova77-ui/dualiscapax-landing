# MEDICAL SIMULATION ENCYCLOPEDIA — CARDIOVASCULAR DOMAIN ENTRY

**Document Control ID:** ED-ENC-CARDIO-002
**Status:** DRAFT — no seal (seal requires David and his father). Verdicts only. Nothing deploys; the launch gate holds.
**Graded against:** ED-ENC-20260929-GRANULARITY-STANDARD-V1 (DRAFT).
**Authoring swarm:** Cardiovascular domain swarm (David's direction, Sept 28, 2026: "we can devote different swarms to neurological oncological etc to start actually doing it in parallel"). Wave 3.

> **ATLAS NOTICE (standing protein-fold law).** This entry is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. It never answers treatment or diagnostic questions about any person. Any person-directed medical question is routed to the fixed refusal: *"This is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. Speak with your clinician."* Every claim below carries a provenance label (REPORTED / MODELED / UNKNOWN); the weakest label governs each composite.

**Source material for this disease:** No staged Google-Doc design papers exist for heart failure in the encyclopedia program (Wave 3 = new diseases; the five engine-registered models do not include an HF model). All REPORTED claims below derive from web research conducted 2026-09-29 (RCSB PDB records, ICD-11 MMS v2026-01 via findacode, named guidelines and trials), labeled per source. Nothing is asserted beyond what the cited source states.

---

## ED-ENC-FIELD-01 — ENTRY IDENTITY

| Item | Value |
|---|---|
| Entry ID | ED-ENC-CARDIO-002 |
| Canonical name | Heart failure (congestive heart failure) |
| ICD-11 | BD10 — Congestive heart failure (REPORTED — ICD-11 MMS v2026-01, via findacode; "a clinical syndrome characterised by abnormalities of ventricular function and neurohormonal regulation which are accompanied by effort intolerance and fluid retention") |
| MONDO | UNKNOWN — no MONDO ID banked for this entry |
| Owning domain swarm | Cardiovascular |
| Authoring swarm | Cardiovascular domain swarm, Wave 3 |
| Entry version | V1 (this document) |
| Chain-verdict history | None yet. Entry self-graded by the authoring swarm (PARTIAL — see self-grade section). Independent verdict-gating pending in ED-VERDICT-20260929-ENC-CARDIO-WAVE3-V1 |

---

## ED-ENC-FIELD-02 — CANONICAL DEFINITION

**Heart failure** is a clinical syndrome in which the heart is structurally or functionally abnormal such that it cannot pump blood — or fill with blood — at the rate required to meet tissue metabolic demand, or can do so only at abnormally elevated filling pressures; the defining physiology is pump/reservoir failure compounded by the activation of initially compensatory, ultimately maladaptive neurohormonal axes (the renin–angiotensin–aldosterone system, the sympathetic nervous system, and the natriuretic-peptide counter-regulatory system). It is classified by left-ventricular ejection fraction into reduced (HFrEF), mildly reduced, preserved (HFpEF), and improved phenotypes — one syndrome, divergent underlying mechanics.

A definition that could describe three other diseases would fail; this one specifies the syndrome structure (pump/fill failure at elevated filling pressures), the neurohormonal-axis driver of progression, and the EF-phenotype classification — together unique to heart failure. It does not define HF as a single molecular lesion, because it is not one.

---

## ED-ENC-FIELD-03 — ETIOLOGY

**Causal vs associated — fenced explicitly.**

**Established causal categories (each fenced):**
- **Ischemic cardiomyopathy** (coronary artery disease with infarction and chronic ischemia — bridge to ED-ENC-CARDIO-001): the most common cause in developed populations. [REPORTED]
- **Hypertension:** chronic pressure overload → hypertrophy → failure; an established causal contributor. [REPORTED]
- **Valvular disease:** aortic stenosis, mitral regurgitation, and other valve lesions as mechanical causes. [REPORTED]
- **Dilated cardiomyopathy:** idiopathic and familial forms — TTN truncating variants are the most common identified genetic cause of familial dilated cardiomyopathy; LMNA, MYH7, and others contribute. [REPORTED]
- **Cardiotoxic exposures:** anthracyclines (dose-dependent cardiotoxicity — REPORTED), alcohol, cocaine. [REPORTED]
- **Myocarditis** (including viral), **peripartum cardiomyopathy**, **tachycardia-induced cardiomyopathy** (reversible on rate control — REPORTED), **cardiac amyloidosis** (ATTR — REPORTED), **sarcoidosis**, congenital heart disease. [REPORTED]

**Risk-factor contributors (fenced):** diabetes mellitus, chronic kidney disease, obesity, atrial fibrillation, sleep apnea — REPORTED contributors; the causal direction for several (e.g., obesity → HFpEF) is REPORTED as established, but the entry does not assign them deterministic single-patient causality.

**Idiopathic boundary:** a substantial fraction of dilated cardiomyopathy remains idiopathic after full workup — the initiating injury is UNKNOWN in those cases (see F11).

---

## ED-ENC-FIELD-04 — PATHOPHYSIOLOGY AT FIVE SCALES

Each scale states: **knowns at this scale**, **inferences borrowed from another scale (labeled MODELED/UNKNOWN)**, and **UNKNOWNs**. No scale borrows authority silently.

### F04a — Molecular

**Knowns at this scale:**
- **Renin–angiotensin–aldosterone system (RAAS):** angiotensin-converting enzyme (ACE) converts angiotensin I → angiotensin II and degrades the vasodilator bradykinin. The ACE–lisinopril co-crystal (PDB 1O86; Natesh et al., Nature 2003) shows the zinc metallopeptidase active site with the inhibitor bound at 2.0 Å. Angiotensin II acts at the AT1 receptor (AGTR1), a GPCR; its antagonist-bound structure (PDB 4YAY — human AT1R with ZD7155, serial femtosecond crystallography; Zhang et al., Cell 2015) revealed the ligand-binding pocket and the basis for ARB binding modes. [REPORTED — RCSB 1O86, 4YAY]
- **Natriuretic-peptide counter-axis:** atrial/brain natriuretic peptides (ANP/BNP) oppose RAAS via NPR-A/NPR-B → cGMP. Neprilysin (neutral endopeptidase, MME), a zinc metallopeptidase, degrades natriuretic peptides, bradykinin, substance P, and endothelin; its inhibitor-bound structure (PDB 1DMT — extracellular domain with phosphoramidon at 2.1 Å; Oefner et al., J Mol Biol 2000) shows two folding domains embracing a large central cavity containing the active site. Sacubitril inhibits neprilysin → raises natriuretic-peptide levels (the ARNI mechanism). [REPORTED — RCSB 1DMT]
- **SGLT2:** the sodium–glucose cotransporter in the proximal renal tubule. The cryo-EM structure of the human SGLT2–MAP17 complex with empagliflozin in the outward-open state (PDB 7FEN; Niu et al., Nature 2022) details the protein–drug interactions; empagliflozin, dapagliflozin, and canagliflozin are SGLT2-selective. [REPORTED — RCSB 7FEN]
- **Calcium handling:** downregulation of SERCA2a (sarcoplasmic-reticulum Ca²⁺ reuptake) and hyperphosphorylation/leak of the ryanodine receptor (RyR2) are REPORTED molecular hallmarks of the failing cardiomyocyte. [REPORTED]
- **β-adrenergic desensitization:** chronic sympathetic drive → β-receptor downregulation and GRK-mediated uncoupling. [REPORTED]

**Borrowed inference (labeled):** the mechanism by which SGLT2 inhibition improves HF outcomes (ketone-shift, natriuresis, sympathetic modulation, direct myocardial effects — all proposed) is inferred from clinical outcomes, not observed at the molecular scale — MODELED, with the true mechanism UNKNOWN.

**UNKNOWNs at this scale:** which SGLT2i mechanism dominates the HF benefit; the molecular determinants of the HFpEF vs HFrEF split (no single molecular lesion separates them — named gap); in-situ kinetics of the neprilysin–natriuretic-peptide interaction in the failing heart.

### F04b — Cellular

**Knowns at this scale:**
- Cardiomyocyte hypertrophy (pathologic, not physiologic), apoptosis, and necrosis; calcium-handling failure at the cellular level (from F04a lesions). [REPORTED]
- Fibroblast activation → myofibroblast differentiation → collagen deposition (cellular source of interstitial fibrosis). [REPORTED]
- Endothelial dysfunction: reduced nitric-oxide bioavailability, microvascular dysfunction — prominent in HFpEF. [REPORTED]
- Inflammatory cell infiltration: macrophage and T-cell participation in remodeling. [REPORTED]
- Death/survival programs: necroptosis and ferroptosis have been REPORTED as contributing cardiomyocyte death programs alongside apoptosis in models. [REPORTED]

**Borrowed inference:** that fibroblast activation is *driven by* cardiomyocyte stress signals (rather than by parallel independent stimuli) is inferred — MODELED.

**UNKNOWNs at this scale:** the regenerative capacity of the adult human cardiomyocyte (near-zero in the REPORTED literature, but the exact proliferative ceiling is UNKNOWN); the ordered cellular sequence of the HFrEF → HFpEF transition in patients who evolve between phenotypes.

### F04c — Tissue

**Knowns at this scale:**
- Interstitial and replacement fibrosis; chamber remodeling — eccentric (volume-overload, HFrEF) vs concentric (pressure-overload, HFpEF) patterns. [REPORTED]
- Wall stress governed by Laplace's law (stress ∝ pressure × radius / wall thickness) — the tissue-mechanical driver of progressive dilatation. [REPORTED]
- Microvascular rarefaction; titin isoform shifts increasing passive stiffness in HFpEF. [REPORTED]
- Atrial tissue remodeling (dilatation, fibrosis) as the substrate for atrial fibrillation — bridge to ED-ENC-CARDIO-004. [REPORTED]

**Borrowed inference:** that Laplace-governed wall stress is the *cause* of progressive remodeling (rather than a correlate of it) is a tissue-scale inference — MODELED.

**UNKNOWNs at this scale:** why some hypertrophied ventricles compensate for decades while others dilate rapidly; the tissue determinants of reversibility (HF with improved EF).

### F04d — Organ

**Knowns at this scale:**
- Ventricular systolic dysfunction (HFrEF) and diastolic dysfunction (HFpEF); elevated left-ventricular end-diastolic pressure; atrial enlargement; functional mitral regurgitation from annular dilatation. [REPORTED]
- Reserve and compensation: the Frank–Starling mechanism initially preserves stroke volume, then becomes maladaptive; neurohormonal support initially maintains perfusion, then drives remodeling. [REPORTED]
- Failure modes: pulmonary congestion and edema, right-ventricular failure, low-output states, arrhythmic death. [REPORTED]
- Functional classification: NYHA classes I–IV are the REPORTED organ-level functional scale (synonym list in ICD-11 BD10). [REPORTED — ICD-11 MMS v2026-01, findacode]

**Borrowed inference:** none beyond observed physiology; the NYHA classes are a REPORTED practice fact.

**UNKNOWNs at this scale:** organ-level predictors of which compensated patients decompensate when; the determinants of recovery in HF with improved EF.

### F04e — System

**Knowns at this scale:**
- Systemic neurohormonal activation: RAAS, sympathetic, vasopressin — sodium and water retention, vasoconstriction. [REPORTED]
- Cardiorenal interaction: reduced perfusion and venous congestion impair renal function; diuretic resistance in advanced disease. [REPORTED]
- Skeletal muscle: exercise intolerance, muscle wasting, and cardiac cachexia as systemic manifestations. [REPORTED]
- Hepatic congestion, gut edema with malabsorption, and systemic inflammatory activation. [REPORTED]
- Whole-body burden: heart failure affects tens of millions worldwide and is a leading cause of hospitalization in older adults. [REPORTED — Global Burden of Disease literature]

**Borrowed inference:** that systemic inflammation *drives* progression (rather than marking it) is inferred — MODELED.

**UNKNOWNs at this scale:** the systemic mediators of cardiac cachexia; why diuretic resistance develops in some patients and not others.

---

## ED-ENC-FIELD-05 — MOLECULAR TARGETS

| Common name | Gene | UniProt | PDB ID | Mechanistic role in F04 | Structure status |
|---|---|---|---|---|---|
| Neprilysin (neutral endopeptidase) | MME | — (unfilled) | 1DMT (extracellular domain + phosphoramidon) | Degrades natriuretic peptides; sacubitril target (ARNI), F04a | REPORTED |
| Angiotensin II type 1 receptor | AGTR1 | P30556 | 4YAY (AT1R + ZD7155) | Angiotensin II signaling; ARB target, F04a | REPORTED |
| ACE | ACE | P12821 | 1O86 (ACE + lisinopril) | Ang I → Ang II conversion; ACE-inhibitor target, F04a | REPORTED |
| SGLT2 | SLC5A2 | — (unfilled) | 7FEN (hSGLT2–MAP17 + empagliflozin) | Renal glucose/sodium reabsorption; gliflozin target, F04a | REPORTED |
| β1-adrenergic receptor | ADRB1 | — (unfilled) | UNKNOWN (no PDB ID verified in this entry's research) | Sympathetic drive; beta-blocker target, F09 | UNKNOWN — recorded as gap, not skipped |
| Mineralocorticoid receptor | NR3C2 | — (unfilled) | UNKNOWN (no PDB ID verified in this entry's research) | Aldosterone signaling; MRA target, F09 | UNKNOWN — recorded as gap |

(UniProt IDs for AGTR1 and ACE sourced from the session's research tool output; remaining UniProt IDs deliberately left unfilled rather than written from memory — UNKNOWN.)

---

## ED-ENC-FIELD-06 — 3D MODEL REFERENCES

The WebGL/Mol* pattern per the ALS 3D molecular guide (ED-MED-202A0907-DCLM-ALS-3D-MANIPULATOR-V1). Mol* link form: `https://molstar.org/viewer/?rcsb=<PDB>`. Manipulability is the bar: rotate, zoom, pan in any browser. A static image is not a 3D reference.

| Target | PDB | Mol* viewer link | RCSB record |
|---|---|---|---|
| Neprilysin + phosphoramidon | 1DMT | https://molstar.org/viewer/?rcsb=1DMT | rcsb.org/structure/1DMT |
| AT1R + ZD7155 | 4YAY | https://molstar.org/viewer/?rcsb=4YAY | rcsb.org/structure/4YAY |
| ACE + lisinopril | 1O86 | https://molstar.org/viewer/?rcsb=1O86 | rcsb.org/structure/1O86 |
| hSGLT2–MAP17 + empagliflozin | 7FEN | https://molstar.org/viewer/?rcsb=7FEN | rcsb.org/structure/7FEN |
| β1-adrenergic receptor | — | UNKNOWN — no structure verified | recorded as gap (F05) |
| Mineralocorticoid receptor | — | UNKNOWN — no structure verified | recorded as gap (F05) |

No DCLM-refined complex PDBs for HF targets are banked on Drive in this entry's research — UNKNOWN. (Mol* links follow the standard's own pattern but were not live smoke-tested in this session — see UNKNOWN register.)

---

## ED-ENC-FIELD-07 — SIMULATION SPECIFICATION

**What counts as a simulation** (the standard's bar): a deterministic execution of a disease model that emits verifiable state transitions — DiseaseModelSpec + parameter manifest + initial state + regime + integrator settings → full state trajectory + summary metrics. Dual-pipeline structure (Pole A kinetics ΔG → Kd → engagement, Pole B systems ODEs), fail-closed watchdog (<4.20 ms), regime honesty, metrics-only outputs are shadows, not simulations.

**No staged simulation material exists for heart failure.** The five engine-registered models include no HF model (IND-CRIT-001 models ICU hemodynamics — a managed state, not heart failure as a disease; the standard carries this as residual 2). **Therefore, this entry banks no simulation.** The specification below is what an HF simulation under this standard WOULD be — a normative scaffold, not a run:

- **DiseaseModelSpec:** Heart failure dual-pipeline model. Pole A: RAAS module (renin → Ang I → ACE kinetics → Ang II; AT1R engagement via Hill function), neprilysin–natriuretic-peptide degradation module (sacubitril-competitive kinetics), SGLT2 reabsorption module (gliflozin occupancy), cardiomyocyte calcium-handling module (SERCA2a/RyR2 state). Pole B: ventricular remodeling ODE network — chamber radius, wall thickness (Laplace stress feedback), fibrosis burden, ejection fraction, end-diastolic pressure; cardiorenal cross-talk module (perfusion → sodium retention); congestion module.
- **Parameter manifest:** REPORTED structural parameters (from the PDB complexes in F05), REPORTED clinical rates (GDMT trial event rates, remodeling rates from imaging studies), and named UNKNOWN parameters (SGLT2i mechanism coefficients, individual remodeling trajectories, diuretic-resistance onset) — each labeled per F12.
- **Regime:** declared at execution (CLOSED_LOOP / STANDALONE_AI / STANDALONE_SYSTEMS); a STANDALONE_AI result would never be presented as a closed-loop result.
- **Integrator:** fixed-step, deterministic, bit-identical trajectories.

This scaffold is DRAFT design — no model was executed for this entry. Nothing here is presented as a result.

---

## ED-ENC-FIELD-08 — HASH VERIFICATION RECORD

**No simulation was executed under this standard for this entry; therefore no hash exists.** The SHA-256 record covers (spec + parameters + initial state + regime + integrator + full trajectory) — with no executed simulation, there is nothing to hash, and this entry claims nothing.

**Hash discipline restated:** when an HF simulation is executed under the F07 scaffold, its hash will be banked here with the full reproducibility manifest. Until then this field stands open and confessed. This confessed absence is the single blocking gap for COMPLETE (see self-grade).

---

## ED-ENC-FIELD-09 — TREATMENT LADDER (DOCUMENTED, STAGED)

Atlas posture: third person, past tense of the literature, named sources. What the field does — never what any person should do. This ladder documents established knowledge; it is not advice and contains no second-person language.

**HFrEF — guideline-directed medical therapy (GDMT).** Per the 2022 AHA/ACC/HFSA Guideline for the Management of Heart Failure (Heidenreich et al., Circulation 2022), the REPORTED four-pillar ladder was: (1) an angiotensin receptor–neprilysin inhibitor (ARNI; sacubitril/valsartan) preferred over ACE inhibitors or ARBs (PARADIGM-HF, 2014, NEJM — sacubitril/valsartan reduced cardiovascular death and HF hospitalization versus enalapril); (2) an evidence-based beta-blocker (metoprolol succinate, carvedilol, or bisoprolol); (3) a mineralocorticoid-receptor antagonist (spironolactone or eplerenone; RALES 1999, EPHESUS 2003); (4) an SGLT2 inhibitor (dapagliflozin — DAPA-HF 2019; empagliflozin — EMPEROR-Reduced 2020). Loop diuretics were the REPORTED mainstay for congestion relief. [REPORTED — Heidenreich et al., Circulation 2022; PARADIGM-HF; DAPA-HF; EMPEROR-Reduced]

**HFpEF.** The REPORTED ladder centered on SGLT2 inhibitors (empagliflozin — EMPEROR-Preserved 2021; dapagliflozin — DELIVER 2022) and diuretics for congestion, with comorbidity management (hypertension, atrial fibrillation, diabetes) as the surrounding practice. [REPORTED — 2022 guideline; EMPEROR-Preserved; DELIVER]

**Devices and advanced options.** Implantable cardioverter-defibrillators and cardiac resynchronization therapy were REPORTED for selected patients meeting criteria; hydralazine plus isosorbide dinitrate was the REPORTED option for self-described African-American patients with persistent symptoms despite GDMT (A-HeFT, 2004, NEJM). [REPORTED]

**Mechanistic ties to F04–F05:** ARNI acts at the neprilysin/AT1R pair (F05, 1DMT/4YAY) — simultaneously raising natriuretic peptides and blocking angiotensin II signaling; ACE inhibitors act at 1O86; SGLT2 inhibitors act at 7FEN with the HF mechanism itself still UNKNOWN at the molecular scale (named gap); beta-blockers and MRAs act at receptors with no verified structures in this entry (F05 gaps). The four-pillar GDMT was a combination whose full interaction is documented clinically but not resolved molecularly — the entry does not invent the resolution.

---

## ED-ENC-FIELD-10 — PHARMACOLOGY — SLOT HELD, SEALED

**SEALED — Stage-1 pharmacology held; lift gated on Condition 6.**

Nothing more is written here. The slot's emptiness is the honest content. No simulation in this entry used pharmacology-stage material as an input; no entry content synthesizes what the sealed stage would contain. "The drug would probably…" is modeling around the seal — refused by construction.

---

## ED-ENC-FIELD-11 — UNKNOWN REGISTER

Per-field confessions. A field with no named UNKNOWNs would be an incomplete field.

- **F01:** MONDO ID not banked. Chain-verdict history empty — no independent scorer has graded this entry.
- **F02:** The definition spans HFrEF, HFmrEF, HFpEF, and HFimpEF; the HFpEF end of the syndrome is mechanistically the least resolved — named gap.
- **F03:** The initiating injury in idiopathic dilated cardiomyopathy; the causal partition among contributors at the individual level.
- **F04a:** Which SGLT2i mechanism dominates the HF benefit; the molecular HFrEF/HFpEF split; in-situ neprilysin kinetics in the failing heart.
- **F04b:** Adult cardiomyocyte proliferative ceiling; the ordered cellular sequence of phenotype evolution.
- **F04c:** Why some ventricles compensate for decades and others dilate rapidly; determinants of reversibility.
- **F04d:** Organ-level predictors of decompensation timing; determinants of recovery in HFimpEF.
- **F04e:** Systemic mediators of cardiac cachexia; determinants of diuretic resistance.
- **F05:** No PDB verified in this entry for the β1-adrenergic receptor or the mineralocorticoid receptor (absence recorded as data). Several UniProt IDs deliberately left unfilled.
- **F06:** Mol* links follow the standard's own pattern but were not live smoke-tested in this session; RCSB records were reached via search-result pages, not direct record verification of every ID's current status.
- **F07:** No simulation executed; the scaffold is normative design, not a run. IND-CRIT-001 is not an HF model (standard residual 2 — not counted).
- **F08:** No hash exists — confessed absence, the blocking gap.
- **F09:** Ladder reflects the 2022 AHA/ACC/HFSA guideline and named trials as retrieved via web search; guidelines evolve — the ladder is dated to its sources. Dosing detail deliberately omitted (atlas, not formulary).
- **F10:** Contents unknown by design (sealed). Hold-lift condition (Condition 6) still open.
- **F12:** Weakest-label audit performed by the authoring swarm only; independent double-scoring pending.

**Deepest UNKNOWNs (load-bearing, named for the coordinator):**
1. **No executed, hash-anchored simulation exists for heart failure under this standard.** This single gap is what blocks COMPLETE and caps the grade at PARTIAL.
2. **The SGLT2-inhibitor HF mechanism is UNKNOWN at the molecular scale** — one of the four GDMT pillars works by a mechanism the entry cannot resolve, and it confesses this.
3. **HFpEF has no unifying molecular lesion** — the phenotype split between HFrEF and HFpEF is not resolved at F04a, and the entry does not invent one.
4. **Pharmacology is sealed** — the slot is held, not worked around.

---

## ED-ENC-FIELD-12 — PROVENANCE MANIFEST

Every claim carries REPORTED / MODELED / UNKNOWN. Weakest-label rule applied throughout.

| Claim | Label | Source |
|---|---|---|
| ICD-11 BD10 = Congestive heart failure (syndrome definition quoted) | REPORTED | ICD-11 MMS v2026-01 (findacode) |
| Canonical definition (syndrome structure, neurohormonal driver, EF phenotypes) | REPORTED | established literature; 2022 HF guideline taxonomy |
| Etiologic categories (ischemic, hypertensive, valvular, DCM/TTN, cardiotoxic, myocarditis, peripartum, tachycardia-induced, ATTR amyloid) | REPORTED | established literature |
| PDB 1O86 (ACE + lisinopril, 2.0 Å) | REPORTED | RCSB PDB record (Natesh et al., Nature 2003) |
| PDB 4YAY (human AT1R + ZD7155, XFEL) | REPORTED | RCSB PDB record (Zhang et al., Cell 2015) |
| PDB 1DMT (neprilysin + phosphoramidon, 2.1 Å) | REPORTED | RCSB PDB record (Oefner et al., J Mol Biol 2000) |
| PDB 7FEN (hSGLT2–MAP17 + empagliflozin, cryo-EM) | REPORTED | Nature 2022 data-availability statement (Niu et al.) |
| UniProt P30556 (AGTR1), P12821 (ACE) | REPORTED | session research tool output |
| SERCA2a downregulation, RyR2 leak; β-adrenergic desensitization | REPORTED | established literature |
| Laplace-governed wall stress; eccentric vs concentric remodeling | REPORTED | established physiology |
| NYHA classes I–IV | REPORTED | ICD-11 MMS v2026-01 synonym list |
| SGLT2i mechanism proposals (ketone, natriuresis, sympathetic, direct) | MODELED | literature-inferred; true mechanism UNKNOWN |
| Treatment ladder (F09) | REPORTED | Heidenreich et al., Circulation 2022 (2022 AHA/ACC/HFSA HF guideline); PARADIGM-HF 2014; RALES 1999; EPHESUS 2003; DAPA-HF 2019; EMPEROR-Reduced 2020; EMPEROR-Preserved 2021; DELIVER 2022; A-HeFT 2004 |
| F07 simulation scaffold | MODELED | designed from the standard's bar; no execution — labeled design, not result |
| F08 hash record | UNKNOWN (confessed absence) | no executed simulation |
| F10 pharmacology | SEALED | stage-1 seal, Condition-6 lift pending |
| HFpEF molecular lesion; cachexia mediators; diuretic-resistance determinants | UNKNOWN | named in F11 |
| Weakest-label compliance | Self-audited | independent double-scoring pending |

---

## SELF-GRADE AGAINST THE COMPLETENESS RUBRIC

**Rubric criteria (ED-ENC-20260929 §2):**

1. *All twelve fields present; none absent.* ✅ — F01–F12 all present; F07/F08/F10 present-but-fenced (permitted).
2. *All five scales closed or explicitly fenced.* ✅ — F04a–e each carry knowns / borrowed inferences / named UNKNOWNs.
3. *F06: every structural target with a PDB ID carries a Mol\* link; targets without structures named as UNKNOWN.* ✅ — 4 structures linked via the standard's Mol* pattern; β1-AR and MR named as UNKNOWN, not skipped. (Links not live smoke-tested — confessed in F11.)
4. *F07–F08: at least one simulation executed under the bar with an anchored, recomputable SHA-256 hash.* ❌ — **This is the failing criterion.** No simulation was executed. IND-CRIT-001 is an ICU hemodynamics state, not an HF disease model, and was not counted. Nothing is hash-anchored.
5. *F09: ladder from named sources; no second-person language.* ✅ — 2022 AHA/ACC/HFSA guideline and named trials cited; third person throughout.
6. *F10: slot present and correctly marked SEALED with the hold condition named.* ✅ — verbatim seal text, Condition 6 named.
7. *F12: every claim labeled; weakest-label rule applied; zero unlabeled claims.* ✅ (self-audit) — independent double-scoring still pending.

**Grade: PARTIAL.** Reasoning: schema-shaped with honestly populated load-bearing fields, but criterion 4 fails — no hash-anchored simulation exists, and the entry cannot honestly claim SUBSTANTIAL either, since SUBSTANTIAL requires ≥1 executed simulation and there is no executed simulation at all. The F07 scaffold is genuine design — the dual-pipeline HF model (Pole A RAAS/neprilysin/SGLT2/calcium kinetics, Pole B remodeling/cardiorenal/congestion ODE network) — but design is not execution, and the standard is explicit: a scaffold without a run is not a simulation. Grading the design as a simulation would launder gloss into the arithmetic. So: PARTIAL, with the single blocking gap named — execute an HF simulation under the F07 scaffold, bank the trajectory, anchor the hash, and this entry moves toward SUBSTANTIAL (then COMPLETE once 3D links are smoke-tested and independent double-scoring lands).

**Self-grade confidence:** performed by the authoring swarm against the written rubric; per the standard's residual 5, the first independent double-scoring will test whether the rubric reproduces. This grade is provisional pending verdict-gating.

---

## CHAIN-OF-CUSTODY NOTES (for the coordinator)

- No staged design papers existed for this disease; all REPORTED claims derive from web research conducted 2026-09-29, labeled per source. PDB IDs were taken from RCSB-indexed records with cited deposition literature; ICD-11 from the MMS v2026-01 via findacode.
- IND-CRIT-001 was NOT counted as an HF simulation — it models ICU hemodynamics (a managed state per the standard's residual 2), not heart failure as a disease entity.
- No second-person language anywhere in F09; atlas-not-advisor fence held.
- Pharmacology seal: held exactly, never modeled around.
- DRAFT only. No seal. Nothing deploys. The launch gate holds.

*End of ED-ENC-CARDIO-002 V1 — DRAFT, no seal, gate holds.*
