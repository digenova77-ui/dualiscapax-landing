# RTE-Learn — Concept Registration

**Document:** `ED-CONCEPT-20260929-RTE-LEARN-V1`
**Status:** DRAFT — concept entered, development dispatched
**Registered:** 2026-09-29 ~01:06 EDT, from David's own words

## The concept (David, verbatim)

> "enter the concept of the RTE-Learn"
>
> "every age. every level. every level of primary through to completion of high school. baked in Iris Tutor. every faculty of post secondary. every program. every course concept from year 1 through PhD with Specialization."
>
> "the gauntlet. from the STUDENT perspective"

## Reading

- RTE-Learn is a new RTE seat in the suite — alongside RTE-Health, RTE-Teach, RTE-Ice, and the rest.
- Where RTE-Teach is the teacher's seat, RTE-Learn is the other side of the desk: the learner's seat.
- **The gauntlet:** the entire educational journey modeled end to end — kindergarten through high-school completion, then every post-secondary faculty, every program, every course concept from year 1 through PhD with specialization. From the student's perspective, education is a gauntlet: every level a gate, every transition a trial. The RTE models the run.
- **Iris Tutor baked in** at every level — not an add-on, part of the seat itself.
- Dual-inside reading: the student runs the gauntlet; the system is the gauntlet. The seat holds both — the runner and the course.

## Standing constraints

- Trinity verdict-gated (design included — ED-LAW-20260929-DESIGN-TRINITY-V1).
- DRAFT only — no seal, no deployment, launch gate holds.
- Real student data stays sealed; the seat models on public figures and the banked education wave (Wave 3: 60 figures) until David says otherwise.
- Persons sealed, patterns free.
- David's eyes are final visual QA.

## The pairing — Teach/Learn (David, 2026-09-29 ~01:07 EDT, verbatim)

> "if we have Teach already then it's Teach/Learn"
>
> "pretty good combo in the same field but explicitly divided from each other"

Standing: RTE-Teach and RTE-Learn are a named pair — same field (education),
explicitly divided from each other, the two sides of the desk. The teacher's
seat and the learner's seat. This is the fractal dual-pipe principle wearing
product clothes: always two things being considered, at whatever depth.
Neither seat bleeds into the other — each sealed, per the RTE sealing rule —
but together they hold the whole field.

## The bridge — information between the two entities (David, 2026-09-29 ~01:08 EDT, verbatim)

> "the information passed back and forth between the two entities here could become magical"

Standing: Teach and Learn are sealed from each other — but information passes
between them, and that flow is where the magic lives. The constraint that
makes it safe: what crosses the bridge is patterns, never persons. The
teacher's seat can see the shape of the gauntlet through the learner's eyes;
the learner's Iris Tutor can carry the teacher's intent — and neither side's
personal data ever crosses. Sealed seats, open patterns: that's the trick
that makes the magic lawful.

## Elevation over lockstep (David, 2026-09-29 ~01:09 EDT, verbatim)

> "so a first year University student like my daughter can choose first year
> University things. but if she elevates the second year while she's still in
> first year that's the path I would like her to have."

Standing design principle: the gauntlet is not lockstep. The seat follows the
learner, not the calendar. A first-year runner may reach into second-year
material — and the seat, and Iris Tutor with it, goes where the learner
reaches. Gates are real; the runner may still run ahead of them. Elevation is
a path the seat must always leave open.

## The tutor's prime directive (David, 2026-09-29 ~01:11 EDT, verbatim — on his daughter)

> "she aspires to be the best she can and I don't think we could have modelled
> anything better than that, to tell you the truth."

> "guide their road, don't guide their destination. let them choose. and give
> them the voice of reason that hopefully leads them the right way, even when
> the road is dark and you're all alone."

Standing: this is Iris Tutor's prime directive, in the founder's words. The
tutor guides the road, never the destination. The learner chooses — always.
The tutor is the voice of reason beside them, especially when the road is
dark and they're all alone. Aspiration is the model; the seat's whole job is
to keep the road walkable.
