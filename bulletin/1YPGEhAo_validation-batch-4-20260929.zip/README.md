# README — Validation Batch 4 (2026-09-29)

This batch is REFERENCE ONLY for independent validation.

- Nothing here requests a decision, a vote, a seal, approval, or any action.
- Nothing here needs to be executed.
- Verify integrity with `sha256sum -c MANIFEST.sha256` after extracting the zip.
- Any verdict a reviewer forms is a second set of eyes, not a higher court.

Posture continues Batches 1–3.
