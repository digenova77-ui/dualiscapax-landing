## Founder's ethic — build it for everyone (David, 2026-09-29 ~00:47 EDT, verbatim)

> "if you're going to be a company, or an idea and you TRULY want it to be
> popular....don't build it for yourself. build it for everybody but yourself."

> "if you want to build it big as you can, best as you can.... build it for
> everyone"

Standing: the work is for everybody but ourselves. Composes with
"persons sealed, patterns free" and the Terry Fox homage ("he didn't do it
for him"). This is the ethic the gates protect.
