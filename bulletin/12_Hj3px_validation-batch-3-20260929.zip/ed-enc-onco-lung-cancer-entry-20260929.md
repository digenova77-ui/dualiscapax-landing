# MEDICAL SIMULATION ENCYCLOPEDIA — ONCOLOGICAL DOMAIN ENTRY

**Document Control ID:** ED-ENC-ONCO-004
**Status:** DRAFT — no seal (seal requires David and his father). Verdicts only. Nothing deploys; the launch gate holds.
**Graded against:** ED-ENC-20260929-GRANULARITY-STANDARD-V1 (DRAFT).
**Authoring swarm:** Oncological domain swarm (David's direction, Sept 28, 2026: "we can devote different swarms to neurological oncological etc to start actually doing it in parallel"). Wave 2.

> **ATLAS NOTICE (standing protein-fold law).** This entry is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. It never answers treatment or diagnostic questions about any person. Any person-directed medical question is routed to the fixed refusal: *"This is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. Speak with your clinician."* Every claim below carries a provenance label (REPORTED / MODELED / UNKNOWN); the weakest label governs each composite.

**Source material for this disease:** No staged Google-Doc design papers exist for lung cancer in the encyclopedia program (Wave 2 = new diseases). All REPORTED claims below derive from web research conducted 2026-09-29 (RCSB PDB records, ICD-11 MMS v2026-01 via findacode, NCCN NSCLC Version 7.2025 / Version 8.2025 via published update summaries, peer-reviewed literature as named), labeled per source. Nothing is asserted beyond what the cited source states.

---

## ED-ENC-FIELD-01 — ENTRY IDENTITY

| Item | Value |
|---|---|
| Entry ID | ED-ENC-ONCO-004 |
| Canonical name | Lung cancer (malignant neoplasms of bronchus or lung) |
| ICD-11 | 2C25 (Malignant neoplasms of bronchus or lung); 2C25.0 = adenocarcinoma; 2C25.1 = small cell carcinoma; 2C25.2 = squamous cell carcinoma; 2C25.3 = large cell carcinoma; 2C25.4 = carcinoid/neuroendocrine (typical/atypical) — REPORTED (ICD-11 MMS v2026-01, via findacode; chapter 2 neoplasms) |
| MONDO | UNKNOWN — no MONDO ID banked for this entry |
| Owning domain swarm | Oncological |
| Authoring swarm | Oncological domain swarm, Wave 2 |
| Entry version | V1 (this document) |
| Chain-verdict history | None yet. Entry self-graded by the authoring swarm (PARTIAL — see self-grade section). Independent verdict-gating pending in ED-VERDICT-20260929-ENC-ONCO-WAVE2-V1 |

**Definitional note for this entry:** "Lung cancer" spans two disease families with near-opposite biology — non-small-cell lung cancer (NSCLC: adenocarcinoma, squamous, large cell) and small-cell lung cancer (SCLC) — and within NSCLC adenocarcinoma, a further split between actionable driver-mutation states (EGFR, ALK, ROS1, KRAS G12C, BRAF, MET exon 14, RET, NTRK) and driver-negative disease. This entry partitions molecular targets and the treatment ladder along those splits; the SCLC family is documented with its own biology and ladder, not folded into the NSCLC framework.

---

## ED-ENC-FIELD-02 — CANONICAL DEFINITION

**Lung cancer** is a malignant epithelial neoplasm of the bronchus or lung — a family of diseases defined at the molecular scale by two principal divisions. **Non-small-cell lung cancer (NSCLC)** arises from bronchial/alveolar epithelial cells (adenocarcinoma from glandular/distal airway cells, squamous from metaplastic bronchial epithelium, large cell undifferentiated) and, in a large minority, is driven by a single actionable oncogenic driver mutation or fusion (EGFR exon 19 deletion/L858R, ALK fusion, ROS1 fusion, KRAS G12C, BRAF V600E, MET exon 14 skipping, RET/NTRK fusions) — kinase-addicted states with ligand-independent or fusion-constitutive signaling and matched targeted therapies. **Small-cell lung cancer (SCLC)** is a neuroendocrine carcinoma with near-universal TP53 and RB1 loss, extremely high proliferative index, early and explosive dissemination, and no established single actionable driver kinase — historically managed by cytotoxic chemotherapy with immunotherapy in defined settings. Tobacco smoke is the causal exposure for the majority of both families, but never-smoker driver-positive NSCLC (EGFR, ALK, ROS1 — REPORTED at ~15% of lung cancer in European/African populations, ~35% in East Asian populations per the Harvard review) is a biologically distinct disease that must be fenced separately from smoking-associated carcinogenesis. [REPORTED — NCCN NSCLC v7.2025 update; StatPearls lung cancer; Harvard Medical School lung-cancer review]

A definition that could describe three other diseases would fail; this one specifies the bronchial/alveolar epithelial origin, the NSCLC/SCLC biological split, the driver-addiction vs driver-negative partition inside NSCLC, the never-smoker driver-positive fence, and the contrasting dissemination behaviors — together unique to lung cancer.

---

## ED-ENC-FIELD-03 — ETIOLOGY

**Smoking vs never-smoker vs occupational — fenced separately.**

**Tobacco smoke (causal, the majority):** cigarette smoking is the established causal exposure for the majority of lung cancer in both families. The molecular consequence is a high tumor-mutational burden from carcinogen-induced DNA damage (polycyclic aromatic hydrocarbons, nitrosamines). [REPORTED — established literature]

**Never-smoker driver-positive NSCLC (biologically distinct):** never-smokers develop lung cancer in which actionable driver mutations/fusions dominate — EGFR (exon 19 deletion, L858R), ALK (EML4-ALK and variant fusions), ROS1 fusions — with lower mutational burden. REPORTED proportions: ~15% of lung cancer in European/African populations, ~35% in East Asian populations (Harvard Medical School review). These tumors are **not** caused by tobacco; they are fenced as a separate etiologic class. [REPORTED]

**Radon and occupational exposures:** radon (the leading cause in never-smokers), asbestos (synergistic with smoking), and air pollution are REPORTED risk factors — established as risk associations, with radon causally implicated in never-smoker disease. [REPORTED — established literature]

**Causal vs associated:** tobacco smoke and radon are causal exposures. The driver mutations (EGFR, ALK, ROS1, KRAS G12C) are causal molecular drivers in the tumors that carry them. Air-pollution and occupational associations are risk modulators.

**Idiopathic boundary:** the first transforming event in any individual tumor — which bronchial cell, which genomic catastrophe first — is not established (UNKNOWN).

---

## ED-ENC-FIELD-04 — PATHOPHYSIOLOGY AT FIVE SCALES

Each scale states: **knowns at this scale**, **inferences borrowed from another scale (labeled MODELED/UNKNOWN)**, and **UNKNOWNs**.

### F04a — Molecular

**Knowns at this scale (partitioned by disease family):**
- **EGFR axis (NSCLC):** Exon 19 deletions and the L858R point mutation produce ligand-independent EGFR kinase activation; the T790M gatekeeper mutation is the classic acquired-resistance mechanism to first-generation inhibitors. Structural basis REPORTED: EGFR kinase domain with gefitinib (PDB 2ITY; Yun et al., Cancer Cell 2007 — a structural template for EGFR-directed inhibitor design), EGFR kinase with erlotinib (PDB 1M17), the EGFR L858R mutant kinase with inhibitor (PDB 4LQM). [REPORTED — RCSB PDB; Yun et al. 2007]
- **ALK axis (NSCLC):** EML4-ALK and variant fusions produce constitutive ALK kinase activity. Structural basis REPORTED: the ALK kinase domain in complex with crizotinib (PDB 2XP2; Cui et al., J Med Chem 2011), ALK with ceritinib (PDB 4MKC), ALK with brigatinib (PDB 5J7H), ALK with lorlatinib (PDB 4CLI/4CLJ). [REPORTED — RCSB PDB; Cui et al. 2011]
- **KRAS G12C (NSCLC):** the G12C mutation creates a covalent-inhibition handle in the switch-II pocket. Structural basis REPORTED: KRAS G12C (PDB 6OIM) — shared structural reference with the program's colorectal entry. [REPORTED — RCSB PDB]
- **ROS1, BRAF V600E, MET exon 14 skipping, RET, NTRK fusions:** REPORTED actionable driver states in NSCLC with matched targeted therapies (crizotinib-class for ROS1, dabrafenib-based for BRAF V600E, capmatinib-class for MET exon 14, selpercatinib-class for RET, larotrectinib-class for NTRK); no PDB IDs verified in this entry's research — named as targets, structures as UNKNOWN. [REPORTED — NCCN NSCLC v7.2025; Healio NSCLC practice summaries]
- **SCLC axis:** near-universal TP53 and RB1 loss with extreme proliferative index; no established single actionable driver kinase. Structural references for the p53 DBD (PDB 1TUP, 5LGY) and RB pocket–E2F (PDB 1O9K) are shared program references; their roles in SCLC are REPORTED at the pathway level. [REPORTED — established literature]
- **Immune axis:** PD-L1 expression and tumor-mutational burden modulate responsiveness to PD-1/PD-L1 blockade in driver-negative NSCLC and in SCLC (REPORTED practice); the molecular determinants of response in any individual tumor are UNKNOWN.

**Borrowed inference:** that a detected driver mutation is the *initiating* lesion (rather than an early cooperating event) is inferred from oncogene-addiction behavior under targeted therapy — MODELED (strong clinical inference, not observed initiation).

**UNKNOWNs at this scale:** quantitative in-situ engagement kinetics for each inhibitor (PDB structures are kinase–inhibitor complexes; cellular kinetics UNKNOWN); the full resistance-mutation spectrum for each driver beyond the classic gatekeepers; the molecular basis of driver-negative NSCLC's heterogeneity.

### F04b — Cellular

**Knowns at this scale:**
- Origin populations: adenocarcinoma from glandular/distal airway epithelium; squamous from metaplastic bronchial epithelium; SCLC from pulmonary neuroendocrine cells. [REPORTED]
- Driver-addicted cell programs: EGFR-mutant and ALK-fusion cells exhibit oncogene addiction — withdrawal of driver signaling induces apoptosis, the cellular basis of targeted-therapy response. [REPORTED — established mechanism]
- SCLC cell programs: near-complete checkpoint loss (TP53/RB1) produces the highest proliferative index among common solid tumors, with rapid doubling and early intravasation. [REPORTED]
- Resistance cell-states: T790M-positive EGFR cells under first-generation inhibition; ALK gatekeeper/solvent-front mutants (e.g., G1202R class) under earlier-generation ALK inhibition; histologic transformation (NSCLC→SCLC) as a rare resistance program under EGFR inhibition. [REPORTED — established resistance literature]

**Borrowed inference:** that a tumor's driver classification predicts its dominant resistance program is inferred from population resistance patterns (MODELED).

**UNKNOWNs at this scale:** the tumor-initiating cell in each family; single-cell dynamics of resistance emergence under osimertinib or alectinib (no single-cell trajectory banked — UNKNOWN); the cellular basis of brain tropism in driver-positive NSCLC.

### F04c — Tissue

**Knowns at this scale:**
- Architecture: adenocarcinoma grows along alveolar walls (lepidic) or invasively; squamous carcinoma arises centrally in bronchi with necrosis/cavitation; SCLC presents as a bulky central mass with massive nodal involvement. [REPORTED]
- Local extent: tumor size, bronchial/vascular invasion, and nodal stations are the tissue-scale facts of TNM staging. [REPORTED]
- The airway itself is the tissue of first failure: endobronchial obstruction, post-obstructive pneumonia, hemoptysis. [REPORTED]

**Borrowed inference:** that central vs peripheral location predicts histology (squamous/SCLC central, adenocarcinoma peripheral) is an epidemiologic association applied at tissue scale — MODELED as a rule of thumb, not a mechanism.

**UNKNOWNs at this scale:** tissue determinants of which driver-positive tumors remain indolent vs disseminate early; the stromal contribution to immunotherapy response in driver-negative NSCLC.

### F04d — Organ

**Knowns at this scale:**
- Organ-level dysfunction: the lung's gas-exchange reserve is large, so early disease is often asymptomatic — the organ-scale fact that explains late presentation; dyspnea, cough, hemoptysis, and post-obstructive collapse mark progressive organ failure. [REPORTED]
- Failure modes: malignant pleural effusion, superior vena cava syndrome (SCLC), airway obstruction, massive hemoptysis. [REPORTED]
- Staging is organ-anatomic: TNM (tumor, node, metastasis) defines stage I–IV; SCLC additionally uses the limited/extensive two-stage system in practice. [REPORTED]

**Borrowed inference:** none beyond what staging observes.

**UNKNOWNs at this scale:** organ-level predictors of which stage I tumors will recur after complete resection; the determinants of pleural vs parenchymal failure patterns.

### F04e — System

**Knowns at this scale:**
- Dissemination: NSCLC metastasizes to brain, bone, adrenal, liver; driver-positive NSCLC shows notable brain tropism (a system-scale fact with CNS-penetrant drug-design consequences). SCLC disseminates early and widely — brain, liver, bone, marrow — with paraneoplastic syndromes (SIADH, Lambert–Eaton, Cushing's) as system-scale endocrine/neurologic manifestations. [REPORTED — established literature]
- Whole-body burden: SCLC's explosive dissemination is the reason surgery has minimal role and systemic therapy is the backbone from diagnosis. [REPORTED]
- Systemic axes: circulating tumor DNA is a REPORTED measurable systemic correlate; its therapy-guiding role (vs prognostic) is UNKNOWN.

**Borrowed inference:** that brain tropism is *caused by* specific molecular features (rather than correlated) is inferred (MODELED — mediators incompletely established).

**UNKNOWNs at this scale:** systemic mediators of brain tropism; drivers of SCLC's uniquely rapid dissemination; the immune axis in driver-positive NSCLC (immunotherapy's limited role there is REPORTED practice; the mechanistic basis is UNKNOWN).

---

## ED-ENC-FIELD-05 — MOLECULAR TARGETS

| Common name | Gene | UniProt | PDB ID | Mechanistic role in F04 | Structure status |
|---|---|---|---|---|---|
| EGFR kinase domain | EGFR | — | 2ITY (EGFR + gefitinib; Yun et al., Cancer Cell 2007), 1M17 (EGFR + erlotinib), 4LQM (EGFR L858R + inhibitor) | Driver kinase, F04a | REPORTED |
| ALK kinase domain | ALK | — | 2XP2 (ALK + crizotinib; Cui et al., J Med Chem 2011), 4MKC (ALK + ceritinib), 5J7H (ALK + brigatinib), 4CLI/4CLJ (ALK + lorlatinib) | Fusion driver kinase, F04a | REPORTED |
| KRAS G12C | KRAS | — | 6OIM (shared program reference) | Driver, F04a | REPORTED |
| ROS1 | ROS1 | — | UNKNOWN (no PDB ID verified in this entry's research) | Fusion driver, F04a | UNKNOWN — recorded as gap |
| BRAF (V600E) | BRAF | — | UNKNOWN (no PDB ID verified in this entry's research) | Driver, F04a | UNKNOWN — recorded as gap |
| MET (exon 14) | MET | — | UNKNOWN (no PDB ID verified in this entry's research) | Driver, F04a | UNKNOWN — recorded as gap |
| RET / NTRK | RET / NTRK | — | UNKNOWN (no PDB ID verified in this entry's research) | Fusion drivers, F04a | UNKNOWN — recorded as gap |
| p53 DBD / RB pocket | TP53 / RB1 | P04637 / P06400 | 1TUP, 5LGY / 1O9K (shared program references) | SCLC checkpoint loss, F04a | REPORTED (pathway-level role in SCLC) |

(UniProt IDs deliberately left unfilled where not verified in this session — UNKNOWN rather than written from memory.)

---

## ED-ENC-FIELD-06 — 3D MODEL REFERENCES

The WebGL/Mol* pattern per the ALS 3D molecular guide (ED-MED-202A0907-DCLM-ALS-3D-MANIPULATOR-V1). Mol* link form: `https://molstar.org/viewer/?rcsb=<PDB>`. Manipulability is the bar: rotate, zoom, pan in any browser. A static image is not a 3D reference.

| Target | PDB | Mol* viewer link | RCSB record |
|---|---|---|---|
| EGFR kinase + gefitinib | 2ITY | https://molstar.org/viewer/?rcsb=2ITY | rcsb.org/structure/2ITY |
| EGFR kinase + erlotinib | 1M17 | https://molstar.org/viewer/?rcsb=1M17 | rcsb.org/structure/1M17 |
| EGFR L858R + inhibitor | 4LQM | https://molstar.org/viewer/?rcsb=4LQM | rcsb.org/structure/4LQM |
| ALK + crizotinib | 2XP2 | https://molstar.org/viewer/?rcsb=2XP2 | rcsb.org/structure/2XP2 |
| ALK + ceritinib | 4MKC | https://molstar.org/viewer/?rcsb=4MKC | rcsb.org/structure/4MKC |
| ALK + brigatinib | 5J7H | https://molstar.org/viewer/?rcsb=5J7H | rcsb.org/structure/5J7H |
| ALK + lorlatinib | 4CLI / 4CLJ | https://molstar.org/viewer/?rcsb=4CLI ; https://molstar.org/viewer/?rcsb=4CLJ | rcsb.org/structure/4CLI ; rcsb.org/structure/4CLJ |
| KRAS G12C | 6OIM | https://molstar.org/viewer/?rcsb=6OIM | rcsb.org/structure/6OIM |
| ROS1, BRAF, MET, RET, NTRK | — | UNKNOWN — no structures verified | recorded as gaps (F05) |

No DCLM-refined complex PDBs for lung-cancer targets are banked on Drive in this entry's research — UNKNOWN. (Mol* links follow the standard's own pattern but were not live smoke-tested in this session — see UNKNOWN register.)

---

## ED-ENC-FIELD-07 — SIMULATION SPECIFICATION

**What counts as a simulation** (the standard's bar): a deterministic execution of a disease model that emits verifiable state transitions — DiseaseModelSpec + parameter manifest + initial state + regime + integrator settings → full state trajectory + summary metrics. Dual-pipeline structure (Pole A kinetics ΔG → Kd → engagement, Pole B systems ODEs), fail-closed watchdog (<4.20 ms), regime honesty, metrics-only outputs are shadows, not simulations.

**No staged simulation material exists for lung cancer.** No engine-registered lung model is named in this entry's research. **Therefore, this entry banks no simulation.** The specification below is what a lung-cancer simulation under this standard WOULD be — a normative scaffold, not a run:

- **DiseaseModelSpec:** Lung-cancer dual-pipeline model, driver-parameterized. Pole A: EGFR-mutant kinase activation/inhibition kinetics (exon-19-del/L858R active state, T790M resistance state; structural basis 2ITY/1M17/4LQM), ALK-fusion constitutive-kinase module (structural basis 2XP2/4MKC/5J7H/4CLI), KRAS-G12C switch-II module (structural basis 6OIM), SCLC TP53/RB1-null checkpoint-collapse module. Pole B: airway-tissue compartment module, lymphatic dissemination module, brain-tropic metastasis module (driver-positive NSCLC), explosive-dissemination module (SCLC); cross-talk term driver-state → metastatic program.
- **Parameter manifest:** REPORTED structural parameters (from the PDB complexes in F05 where binding is characterized), REPORTED clinical rates (adjuvant-benefit magnitudes, e.g., osimertinib and alectinib category-1 adjuvant frameworks; metastatic response rates from established trials), and named UNKNOWN parameters (resistance-emergence rates per driver, brain-tropism coefficients, SCLC dissemination rates) — each labeled per F12.
- **Regime:** declared at execution (CLOSED_LOOP / STANDALONE_AI / STANDALONE_SYSTEMS); a STANDALONE_AI result would never be presented as a closed-loop result.
- **Integrator:** fixed-step, deterministic, bit-identical trajectories.

This scaffold is DRAFT design — no model was executed for this entry. Nothing here is presented as a result.

---

## ED-ENC-FIELD-08 — HASH VERIFICATION RECORD

**No simulation was executed under this standard for this entry; therefore no hash exists.** The SHA-256 record covers (spec + parameters + initial state + regime + integrator + full trajectory) — with no executed simulation, there is nothing to hash, and this entry claims nothing.

**Hash discipline restated:** when a lung-cancer simulation is executed under the F07 scaffold, its hash will be banked here with the full reproducibility manifest. Until then this field stands open and confessed. This confessed absence is the single blocking gap for COMPLETE (see self-grade).

---

## ED-ENC-FIELD-09 — TREATMENT LADDER (DOCUMENTED, STAGED)

Atlas posture: third person, past tense of the literature, named sources. What the field does — never what any person should do. Partitioned by driver state, as the disease requires. This ladder documents established knowledge; it is not advice and contains no second-person language.

**Molecular testing as the gateway.** Broad molecular profiling for actionable drivers (EGFR, ALK, ROS1, KRAS, BRAF, MET, RET, NTRK, PD-L1) was the REPORTED gateway to the entire NSCLC ladder. [REPORTED — NCCN NSCLC v7.2025]

**Resectable NSCLC, adjuvant.** For resected EGFR exon 19 deletion or L858R-positive stage IB–IIIA disease, adjuvant osimertinib was the REPORTED category-1 preferred option (NCCN v7.2025). For resected ALK-positive stage II–IIIA disease, adjuvant alectinib was the REPORTED category-1 preferred option (v7.2025 update). Adjuvant platinum-based chemotherapy with or without immunotherapy (pembrolizumab, atezolizumab in defined populations) completed the resectable framework. [REPORTED — NCCN NSCLC v7.2025 update summary]

**Unresectable stage II/III NSCLC.** Concurrent chemoradiation followed by consolidation immunotherapy (durvalumab) was the REPORTED framework for unresectable disease without progression after chemoradiation; molecularly targeted consolidation applied in driver-positive subsets per evolving guidance. [REPORTED — established practice; PACIFIC framework]

**Metastatic NSCLC, driver-positive.** First-line targeted therapy by alteration was the REPORTED standard: osimertinib for sensitizing EGFR mutations (preferred first-line per Healio/established practice); alectinib or lorlatinib preferred for ALK-positive disease (NCCN v8.2025 reportedly elevated lorlatinib; alectinib/brigatinib retained); crizotinib-class for ROS1; KRAS G12C inhibitors; BRAF-, MET-, RET-, NTRK-directed agents in their biomarker subsets. [REPORTED — NCCN NSCLC v7/v8.2025 update summaries; Healio NSCLC practice summaries]

**Metastatic NSCLC, driver-negative.** PD-L1– and histology-guided chemoimmunotherapy was the REPORTED standard: pembrolizumab monotherapy or pembrolizumab–chemotherapy combinations by PD-L1 strata and histology; subsequent rungs per established practice. [REPORTED — NCCN NSCLC v7.2025]

**SCLC.** Platinum–etoposide chemotherapy was the REPORTED backbone; immunotherapy (atezolizumab/durvalumab) added in extensive-stage disease per established practice; thoracic radiotherapy and prophylactic cranial irradiation in defined limited-stage settings. [REPORTED — established literature; fenced at practice level — regimen specifics beyond the named classes are UNKNOWN in this entry's research]

**Mechanistic ties to F04–F05:** osimertinib/gefitinib/erlotinib engage the EGFR kinase (F05, PDB 2ITY/1M17/4LQM); crizotinib/ceritinib/brigatinib/lorlatinib engage ALK (F05, PDB 2XP2/4MKC/5J7H/4CLI); KRAS G12C inhibitors engage the switch-II pocket (F05, PDB 6OIM). SCLC's TP53/RB1-null biology has no REPORTED ladder rung acting directly on it — named as a gap, not an opportunity.

**Version currency:** the ladder reflects NCCN NSCLC v7.2025 / v8.2025 update summaries and established practice as retrieved 2026-09-29; guideline versions evolve — the ladder is dated to its sources (see F11).

---

## ED-ENC-FIELD-10 — PHARMACOLOGY — SLOT HELD, SEALED

**SEALED — Stage-1 pharmacology held; lift gated on Condition 6.**

Nothing more is written here. The slot's emptiness is the honest content. No simulation in this entry used pharmacology-stage material as an input; no entry content synthesizes what the sealed stage would contain. "The drug would probably…" is modeling around the seal — refused by construction.

---

## ED-ENC-FIELD-11 — UNKNOWN REGISTER

Per-field confessions. A field with no named UNKNOWNs would be an incomplete field.

- **F01:** MONDO ID not banked. Chain-verdict history empty — no independent scorer has graded this entry.
- **F02:** The definition's driver partition reflects the targeted-therapy era; driver-negative NSCLC remains biologically heterogeneous and is defined by exclusion — a known gap.
- **F03:** First transforming event in any individual tumor; full partition of never-smoker etiologies beyond radon.
- **F04a:** In-situ engagement kinetics for each inhibitor (PDB complexes are in-vitro structures); full resistance-mutation spectrum beyond classic gatekeepers; molecular basis of driver-negative heterogeneity.
- **F04b:** Tumor-initiating cell per family; single-cell dynamics of resistance emergence under osimertinib/alectinib; cellular basis of brain tropism.
- **F04c:** Tissue determinants of indolent vs early-disseminating driver-positive tumors; stromal contribution to immunotherapy response.
- **F04d:** Organ-level predictors of recurrence after complete resection; pleural vs parenchymal failure determinants.
- **F04e:** Systemic mediators of brain tropism; drivers of SCLC's rapid dissemination; immune axis in driver-positive NSCLC.
- **F05:** No PDB verified in this entry for ROS1, BRAF, MET, RET, or NTRK (absence recorded as data). UniProt IDs left unfilled where unverified.
- **F06:** Mol* links follow the standard's own pattern but were not live smoke-tested in this session; RCSB records reached via search-result pages, not direct record verification of every ID's current status.
- **F07:** No simulation executed; the scaffold is normative design, not a run.
- **F08:** No hash exists — confessed absence, the blocking gap.
- **F09:** Ladder reflects NCCN v7/v8.2025 update summaries and established practice as retrieved 2026-09-29; dosing detail deliberately omitted (atlas, not formulary); SCLC regimen specifics beyond named classes are UNKNOWN in this entry's research; version currency decays — the ladder is dated.
- **F10:** Contents unknown by design (sealed). Hold-lift condition (Condition 6) still open.
- **F12:** Weakest-label audit performed by the authoring swarm only; independent double-scoring pending.

**Deepest UNKNOWNs (load-bearing, named for the coordinator):**
1. **No executed, hash-anchored simulation exists for lung cancer under this standard.** No engine-registered lung model is even named in this entry's research. This single gap is what blocks COMPLETE and caps the grade at PARTIAL.
2. **SCLC has no REPORTED single actionable driver kinase** — the family with the most explosive biology is the family with the poorest structural-target coverage in this entry, and the entry does not pretend otherwise.
3. **Brain tropism in driver-positive NSCLC is described but not mechanistically explained** — the mediators are UNKNOWN, which limits any honest metastatic-program model.
4. **Pharmacology is sealed** — the slot is held, not worked around.

---

## ED-ENC-FIELD-12 — PROVENANCE MANIFEST

Every claim carries REPORTED / MODELED / UNKNOWN. Weakest-label rule applied throughout.

| Claim | Label | Source |
|---|---|---|
| ICD-11 2C25 and subcodes 2C25.0–2C25.4 | REPORTED | ICD-11 MMS v2026-01 (findacode) |
| NSCLC/SCLC split; driver-addiction partition | REPORTED | NCCN NSCLC v7.2025; established literature |
| Never-smoker proportions (~15% European/African, ~35% East Asian) | REPORTED | Harvard Medical School lung-cancer review |
| Tobacco causality; radon/asbestos/pollution risk | REPORTED | established literature |
| PDB 2ITY (EGFR + gefitinib; Yun et al., Cancer Cell 2007) | REPORTED | RCSB PDB record |
| PDB 1M17 (EGFR + erlotinib) | REPORTED | RCSB PDB record |
| PDB 4LQM (EGFR L858R + inhibitor) | REPORTED | RCSB PDB record |
| PDB 2XP2 (ALK + crizotinib; Cui et al., J Med Chem 2011) | REPORTED | RCSB PDB record |
| PDB 4MKC, 5J7H, 4CLI/4CLJ (ALK + ceritinib/brigatinib/lorlatinib) | REPORTED | RCSB PDB record |
| PDB 6OIM (KRAS G12C; shared program reference) | REPORTED | RCSB PDB record |
| Driver→initiation determinism | MODELED | clinical inference (oncogene addiction under therapy) |
| Central/peripheral location rule of thumb | MODELED | epidemiologic association applied at tissue scale |
| Treatment ladder (F09) | REPORTED | NCCN NSCLC v7/v8.2025 update summaries; Healio practice summaries; established literature |
| F07 simulation scaffold | MODELED | designed from the standard's bar; no execution — labeled design, not result |
| F08 hash record | UNKNOWN (confessed absence) | no executed simulation |
| F10 pharmacology | SEALED | stage-1 seal, Condition-6 lift pending |
| Resistance spectra; tropism mediators; SCLC dissemination drivers | UNKNOWN | named in F11 |
| Weakest-label compliance | Self-audited | independent double-scoring pending |

---

## SELF-GRADE AGAINST THE COMPLETENESS RUBRIC

**Rubric criteria (ED-ENC-20260929 §2):**

1. *All twelve fields present; none absent.* ✅ — F01–F12 all present; F07/F08/F10 present-but-fenced (permitted).
2. *All five scales closed or explicitly fenced.* ✅ — F04a–e each carry knowns / borrowed inferences / named UNKNOWNs.
3. *F06: every structural target with a PDB ID carries a Mol\* link; targets without structures named as UNKNOWN.* ✅ — 9 structures linked via the standard's Mol* pattern; ROS1/BRAF/MET/RET/NTRK named as UNKNOWN, not skipped. (Links not live smoke-tested — confessed in F11.)
4. *F07–F08: at least one simulation executed under the bar with an anchored, recomputable SHA-256 hash.* ❌ — **This is the failing criterion.** No simulation was executed. Nothing is hash-anchored.
5. *F09: ladder from named sources; no second-person language.* ✅ — NCCN v7/v8.2025 update summaries and established literature cited; third person throughout; driver-partitioned as the disease requires.
6. *F10: slot present and correctly marked SEALED with the hold condition named.* ✅ — verbatim seal text, Condition 6 named.
7. *F12: every claim labeled; weakest-label rule applied; zero unlabeled claims.* ✅ (self-audit) — independent double-scoring still pending.

**Grade: PARTIAL.** Reasoning: schema-shaped with honestly populated load-bearing fields, but criterion 4 fails — no hash-anchored simulation exists, and the entry cannot honestly claim SUBSTANTIAL either, since SUBSTANTIAL requires ≥1 executed simulation and there is no executed simulation at all. The F07 scaffold is real design — the driver-parameterized dual-pipeline lung-cancer model (EGFR/ALK/KRAS/SCLC Pole A, airway/brain-tropic/explosive-dissemination Pole B) is a genuine simulation *design* — but design is not execution, and the standard is explicit: metrics without the trajectory are not a simulation; a scaffold without a run is not a simulation either. Grading the design as a simulation would launder gloss into the arithmetic. So: PARTIAL, with the single blocking gap named — execute a lung-cancer simulation under the F07 scaffold (the EGFR axis has the richest structural basis), bank the trajectory, anchor the hash, and this entry moves toward SUBSTANTIAL (then COMPLETE once 3D links are smoke-tested, structural gaps filled, and independent double-scoring lands).

**Self-grade confidence:** performed by the authoring swarm against the written rubric; per the standard's residual 5, the first independent double-scoring will test whether the rubric reproduces. This grade is provisional pending verdict-gating.

---

## CHAIN-OF-CUSTODY NOTES (for the coordinator)

- No staged design papers existed for this disease; all REPORTED claims derive from web research conducted 2026-09-29, labeled per source. PDB IDs were taken from RCSB-indexed records with cited deposition literature (2ITY, 1M17, 4LQM, 2XP2, 4MKC, 5J7H, 4CLI/4CLJ verified); ICD-11 from the MMS v2026-01 via findacode.
- No engine-registered lung model is named in this entry's research — nothing was counted as a simulation.
- No second-person language anywhere in F09; atlas-not-advisor fence held.
- Pharmacology seal: held exactly, never modeled around.
- DRAFT only. No seal. Nothing deploys. The launch gate holds.

*End of ED-ENC-ONCO-004 V1 — DRAFT, no seal, gate holds.*
