# MEDICAL SIMULATION ENCYCLOPEDIA — ONCOLOGICAL DOMAIN ENTRY

**Document Control ID:** ED-ENC-ONCO-002
**Status:** DRAFT — no seal (seal requires David and his father). Verdicts only. Nothing deploys; the launch gate holds.
**Graded against:** ED-ENC-20260929-GRANULARITY-STANDARD-V1 (DRAFT).
**Authoring swarm:** Oncological domain swarm (David's direction, Sept 28, 2026: "we can devote different swarms to neurological oncological etc to start actually doing it in parallel"). Wave 2.

> **ATLAS NOTICE (standing protein-fold law).** This entry is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. It never answers treatment or diagnostic questions about any person. Any person-directed medical question is routed to the fixed refusal: *"This is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. Speak with your clinician."* Every claim below carries a provenance label (REPORTED / MODELED / UNKNOWN); the weakest label governs each composite.

**Source material for this disease:** No staged Google-Doc design papers exist for osteosarcoma in the encyclopedia program (Wave 2 = new diseases; the five engine-registered models include IND-OSTEO-001 osteosarcoma, but no staged design paper). All REPORTED claims below derive from web research conducted 2026-09-29 (RCSB PDB records, ICD-11 MMS via findacode, NCCN patient guideline, peer-reviewed and textbook literature as named), labeled per source. Nothing is asserted beyond what the cited source states.

---

## ED-ENC-FIELD-01 — ENTRY IDENTITY

| Item | Value |
|---|---|
| Entry ID | ED-ENC-ONCO-002 |
| Canonical name | Osteosarcoma |
| ICD-11 | 2B51 (Osteosarcoma, primary site) — REPORTED (ICD-11 MMS v2026-01, via findacode; block 2B50–2B5Z = Malignant mesenchymal neoplasms) |
| MONDO | UNKNOWN — no MONDO ID banked for this entry |
| Owning domain swarm | Oncological |
| Authoring swarm | Oncological domain swarm, Wave 2 |
| Entry version | V1 (this document) |
| Chain-verdict history | None yet. Entry self-graded by the authoring swarm (PARTIAL — see self-grade section). Independent verdict-gating pending in ED-VERDICT-20260929-ENC-ONCO-WAVE2-V1 |

---

## ED-ENC-FIELD-02 — CANONICAL DEFINITION

**Osteosarcoma** is a primary malignant mesenchymal neoplasm in which the neoplastic cells directly produce osteoid — immature woven bone matrix — the single histopathologic requirement for the diagnosis. It arises from primitive mesenchymal cells with osteoblastic differentiation capacity, characteristically in the metaphyses of long bones (distal femur, proximal tibia, proximal humerus) during the adolescent growth spurt, and progresses by local cortical destruction with soft-tissue extension and early hematogenous dissemination, overwhelmingly to the lungs. Its genomic signature is chromosomal instability and near-universal disruption of the TP53 and RB1 tumor-suppressor pathways rather than a single dominant oncogenic kinase. [REPORTED — WHO histologic classification of bone tumors (central/intramedullary/surface schema); oncohemakey osteosarcoma review; conventional subtype = ~80–90% of cases, high-grade]

A definition that could describe three other diseases would fail; this one specifies the mesenchymal (not epithelial) origin, the osteoid-production requirement, the metaphyseal adolescent presentation, the TP53/RB1-instability genomic signature, and the pulmonary hematogenous dissemination pattern — together unique to osteosarcoma.

---

## ED-ENC-FIELD-03 — ETIOLOGY

**Sporadic vs hereditary vs secondary — fenced separately.**

**Sporadic disease (the large majority):** driven by acquired somatic disruption of cell-cycle checkpoints (TP53, RB1 pathway) with chromosomal instability in a rapidly proliferating growth-plate mesenchymal population. No single environmental cause is established; the epidemiologic association with skeletal growth velocity (taller stature, earlier onset in females tracking pubertal timing) is REPORTED as association, not cause. [REPORTED — oncohemakey bone-tumor review: ~70% of tumor specimens show chromosomal abnormality involving tumor-suppressor genes or DNA helicases]

**Hereditary predisposition (each fenced):**
- **Li–Fraumeni syndrome** (germline TP53): markedly elevated osteosarcoma risk. [REPORTED]
- **Hereditary retinoblastoma** (germline RB1): survivors carry elevated second-primary osteosarcoma risk. [REPORTED]
- **Rothmund–Thomson syndrome** (RECQL4 DNA helicase), Bloom syndrome, Werner syndrome — rare DNA-helicase/repair disorders with osteosarcoma association. [REPORTED]
- **Familial clustering** suggesting genetic predisposition is REPORTED in the literature; the full genetic architecture of sporadic susceptibility is UNKNOWN.

**Secondary (acquired) forms:**
- **Ionizing radiation:** the established environmental cause, implicated in ~2% of osteosarcomas; risk correlates with radiation dose and latency after primary irradiation. [REPORTED — statperson review: "the only environmental agent known to cause osteosarcoma in human is ionising radiation"]
- **Paget's disease of bone:** secondary osteosarcoma in older adults arising in pagetic bone. [REPORTED]
- **Benign bone disorders** (fibrous dysplasia, bone dysplasia) as rare precursors. [REPORTED — association]

**Causal vs associated:** TP53/RB1 loss and ionizing radiation are causal drivers/established causes. Growth velocity, stature, and benign bone disorders are **associations/risk modulators**, never stated as deterministic causes.

**Idiopathic boundary:** the first transforming event in a sporadic tumor — which cell in the growth-plate niche, and which genomic catastrophe first — is not established (UNKNOWN, see F11).

---

## ED-ENC-FIELD-04 — PATHOPHYSIOLOGY AT FIVE SCALES

Each scale states: **knowns at this scale**, **inferences borrowed from another scale (labeled MODELED/UNKNOWN)**, and **UNKNOWNs**. No scale borrows authority silently.

### F04a — Molecular

**Knowns at this scale:**
- **TP53 pathway disruption:** near-universal in conventional high-grade osteosarcoma — by TP53 mutation/deletion or by MDM2 amplification (the alternative p53-inactivation route, characteristic of low-grade/parosteal variants and a subset of conventional disease). The MDM2–p53 interface is structurally characterized: the N-terminal domain of MDM2 presents a deep hydrophobic cleft into which the p53 transactivation-domain peptide (Phe19, Trp23, Leu26) inserts as an amphipathic α-helix (PDB 1YCR; Kussie et al., Science 1996). MDM2 amplification is, in certain cancers, a common event contributing to p53 inactivation. [REPORTED — RCSB 1YCR; Kussie et al. 1996; BJC review of the p53–MDM2 pathway]
- **RB1 pathway disruption:** RB1 loss or functional inactivation (via CDK-mediated hyperphosphorylation) releases E2F transcription factors from pocket-domain repression, deregulating the G1/S transition. Structural basis REPORTED: the retinoblastoma pocket domain (A–B cyclin folds) bound to the E2F-1 core binding peptide at the A–B interface (PDB 1O9K; Xiao et al., PNAS 2003); the pocket is the major focus of tumorigenic mutations. [REPORTED — RCSB 1O9K; Xiao et al. 2003]
- **p53 DNA-binding domain:** loss-of-function/dominant-negative missense mutations in the DBD disable checkpoint enforcement. Structural basis REPORTED: p53 core domain–DNA complex (PDB 1TUP), Lys120-acetylated p53 DBD with BAX response element (PDB 5LGY) — shared structural references with the program's colorectal entry. [REPORTED — RCSB PDB]
- **Chromosomal instability / kataegis:** conventional osteosarcoma genomes are among the most rearranged in human cancer; chromothripsis and kataegis are REPORTED features. No single dominant oncogenic kinase defines the disease — a molecular-scale fact that distinguishes it from kinase-addicted carcinomas. [REPORTED — established literature]
- **MDM2/CDK4 co-amplification** in parosteal (low-grade surface) osteosarcoma is the molecular hallmark of that variant. [REPORTED]

**Borrowed inference (labeled):** that the observed TP53/RB1 lesions are the *initiating* lesions (rather than early passengers in an unstable genome) is inferred from their near-universality and from germline predisposition syndromes — MODELED (literature-inferred), not directly observed.

**UNKNOWNs at this scale:** the quantitative ΔG/Kd engagement kinetics of the MDM2–p53 and RB–E2F interactions *in osteosarcoma cells* (the PDB structures are in-vitro complexes; cellular kinetics are UNKNOWN); the full catalog of driver events in any single tumor (instability obscures the driver/passenger partition); whether specific DNA-helicase defects (RECQL4 et al.) leave a distinct molecular signature.

### F04b — Cellular

**Knowns at this scale:**
- Origin population: primitive mesenchymal cells of the metaphysis with osteoblastic differentiation capacity; the defining cellular behavior is **direct production of osteoid by malignant cells** — the diagnostic requirement. [REPORTED — WHO/oncohemakey]
- Differentiation programs: conventional osteosarcoma subdivides by predominant matrix into osteoblastic, chondroblastic, and fibroblastic — with no significant differences in clinical outcome among the three (REPORTED — WHO classification via oncohemakey); rarer variants: small cell, telangiectatic, multifocal (worse prognosis). [REPORTED]
- Cell-state transitions: high-grade intramedullary tumor cells invade cortex, enter soft tissue, and intravasate; therapy-selected chemoresistant subpopulations emerge under MAP chemotherapy. The histologic response to neoadjuvant chemotherapy (percent viable tumor / necrosis) is the cellular-scale readout that predicts outcome. [REPORTED]
- Death/survival programs: TP53 loss disables apoptosis/senescence; MDM2 amplification raises the apoptotic threshold without TP53 mutation. [REPORTED — inferred at cellular scale from F04a lesions]

**Borrowed inference:** that a given tumor's osteoid production *derives from* its named molecular lesions is inferred, not observed as causation (MODELED).

**UNKNOWNs at this scale:** the identity of the true tumor-initiating cell within the growth-plate niche; the single-cell dynamics of chemoresistance emergence under MAP (no single-cell trajectory banked — UNKNOWN); the cellular basis of pulmonary tropism.

### F04c — Tissue

**Knowns at this scale:**
- Architecture disruption: tumor originates in the intramedullary metaphysis (~80% of cases in the metaphysis of long bones), destroys cortex from within, elevates periosteum (Codman triangle), extends into soft tissue; radiographic sunburst periosteal reaction is the tissue-scale imaging signature. [REPORTED — oncohemakey review]
- Variants by tissue compartment: conventional (intramedullary, high-grade) vs surface — parosteal (low-grade, low metastatic potential), periosteal (intermediate, ~20% metastatic rate), high-grade surface. Extraosseous osteosarcoma arises in soft tissue, generally after prior radiation. [REPORTED]
- Microenvironment: malignant osteoid interwoven with sarcomatous stroma; neovascularization; the growth-plate niche as the tissue of origin. [REPORTED]
- Compartmentalization: the cortex and periosteum are the tissue barriers whose breach defines local extent; skip metastases (discontinuous intramedullary foci) are a tissue-scale fact with surgical consequence. [REPORTED]

**Borrowed inference:** that the metaphyseal location is *caused by* growth-plate proliferative activity is inferred from epidemiology (MODELED association, not a tissue-scale mechanism).

**UNKNOWNs at this scale:** the tissue-scale determinants of why some tumors remain intramedullary while others breach early; the stromal contribution to chemoresistance in situ.

### F04d — Organ

**Knowns at this scale:**
- Organ-level dysfunction: the affected long bone loses structural integrity — pain, swelling, pathologic fracture; joint involvement when tumor crosses the epiphysis/articular surface. [REPORTED]
- Reserve and compensation: bone has limited functional reserve against a destructive metaphyseal lesion; limb function is the organ-level outcome that limb-salvage surgery preserves. [REPORTED]
- Failure modes: pathologic fracture, neurovascular encasement precluding salvage, local recurrence after inadequate margins. [REPORTED]
- Staging is organ-anatomic: MSTS surgical staging (grade + local extent) is the most used among orthopedic oncologists; AJCC/UICC (grade, size, skip metastases, nodal status, metastasis type) is applied by registries — both REPORTED as the two systems in use, with their differences named, not harmonized. [REPORTED — uspharmacist osteosarcoma review]

**Borrowed inference:** none beyond what staging observes; the MSTS vs AJCC coexistence is a REPORTED practice fact.

**UNKNOWNs at this scale:** organ-level predictors of which tumors will fracture vs remain stable; the determinants of local recurrence after histologically clear margins.

### F04e — System

**Knowns at this scale:**
- Dissemination: **hematogenous, lungs first** — pulmonary metastases are the dominant systemic pattern; bone-to-bone metastases occur; lymphatic spread is rare (a system-scale fact distinguishing sarcoma from carcinoma). [REPORTED]
- Whole-body burden: at presentation, a large fraction of patients harbor radiographically occult micrometastases — the historical 80–90% recurrence rate with surgery alone is the evidence for this system-scale fact, and the reason adjuvant/neoadjuvant chemotherapy transformed survival. [REPORTED — uspharmacist review]
- Metastasectomy: resection of pulmonary metastases is an established component of management in selected patients. [REPORTED]
- Systemic axes: alkaline phosphatase and LDH elevations are REPORTED systemic correlates tracked at baseline and restaging (droracle treatment algorithm); their mechanistic role as drivers vs consequences is UNKNOWN.

**Borrowed inference:** "micrometastatic disease present at diagnosis" is inferred from the surgery-alone recurrence history — MODELED (strong historical inference, not directly observed).

**UNKNOWNs at this scale:** the systemic mediators of pulmonary tropism; why some patients develop isolated resectable lung disease and others diffuse spread; the immune axis in osteosarcoma (role of the immune microenvironment in progression and therapy response — UNKNOWN).

---

## ED-ENC-FIELD-05 — MOLECULAR TARGETS

| Common name | Gene | UniProt | PDB ID | Mechanistic role in F04 | Structure status |
|---|---|---|---|---|---|
| p53 DNA-binding domain | TP53 | P04637 | 1TUP (core domain–DNA), 5LGY (acetylated DBD–BAX element) | Checkpoint loss, F04a; near-universal pathway disruption | REPORTED |
| MDM2–p53 complex | MDM2 / TP53 | — | 1YCR (MDM2 N-terminal domain + p53 TAD peptide) | Alternative p53 inactivation via amplification, F04a | REPORTED |
| RB pocket–E2F complex | RB1 | P06400 | 1O9K (pocket domain + E2F-1 peptide) | G1/S deregulation, F04a | REPORTED |
| CDK4 | CDK4 | — | UNKNOWN (no PDB ID verified in this entry's research) | Parosteal co-amplification with MDM2, F04a | UNKNOWN — recorded as gap, not skipped |
| VEGFR family (sorafenib/regorafenib/cabozantinib targets) | — | — | UNKNOWN (no PDB ID verified in this entry's research) | Second-line kinase-inhibitor targets, F09 | UNKNOWN — recorded as gap |

(UniProt IDs for MDM2/CDK4 deliberately left unfilled rather than written from memory — UNKNOWN.)

---

## ED-ENC-FIELD-06 — 3D MODEL REFERENCES

The WebGL/Mol* pattern per the ALS 3D molecular guide (ED-MED-202A0907-DCLM-ALS-3D-MANIPULATOR-V1). Mol* link form: `https://molstar.org/viewer/?rcsb=<PDB>`. Manipulability is the bar: rotate, zoom, pan in any browser. A static image is not a 3D reference.

| Target | PDB | Mol* viewer link | RCSB record |
|---|---|---|---|
| MDM2 + p53 TAD | 1YCR | https://molstar.org/viewer/?rcsb=1YCR | rcsb.org/structure/1YCR |
| RB pocket + E2F-1 peptide | 1O9K | https://molstar.org/viewer/?rcsb=1O9K | rcsb.org/structure/1O9K |
| p53 core domain–DNA | 1TUP | https://molstar.org/viewer/?rcsb=1TUP | rcsb.org/structure/1TUP |
| p53 DBD (acetylated)–BAX element | 5LGY | https://molstar.org/viewer/?rcsb=5LGY | rcsb.org/structure/5LGY |
| CDK4 | — | UNKNOWN — no structure verified | recorded as gap (F05) |
| VEGFR family | — | UNKNOWN — no structure verified | recorded as gap (F05) |

No DCLM-refined complex PDBs for osteosarcoma targets are banked on Drive in this entry's research — UNKNOWN. (Mol* links follow the standard's own pattern but were not live smoke-tested in this session — see UNKNOWN register.)

---

## ED-ENC-FIELD-07 — SIMULATION SPECIFICATION

**What counts as a simulation** (the standard's bar): a deterministic execution of a disease model that emits verifiable state transitions — DiseaseModelSpec + parameter manifest + initial state + regime + integrator settings → full state trajectory + summary metrics. Dual-pipeline structure (Pole A kinetics ΔG → Kd → engagement, Pole B systems ODEs), fail-closed watchdog (<4.20 ms), regime honesty, metrics-only outputs are shadows, not simulations.

**No staged simulation material exists for osteosarcoma.** The engine registry's IND-OSTEO-001 model is a registered model name, not an executed simulation with a trajectory in this entry's research. **Therefore, this entry banks no simulation.** The specification below is what an osteosarcoma simulation under this standard WOULD be — a normative scaffold, not a run:

- **DiseaseModelSpec:** Osteosarcoma dual-pipeline model. Pole A: TP53/MDM2 interaction kinetics (wild-type vs amplified-MDM2 vs mutant-TP53 states), RB–E2F G1/S checkpoint module with CDK-mediated phosphorylation switch, osteoid-production program module, chromosomal-instability burden accumulator. Pole B: growth-plate metaphyseal niche module, pulmonary metastatic-niche colonization module, systemic burden module; cross-talk term checkpoint-state → metastatic competence.
- **Parameter manifest:** REPORTED structural parameters (from the PDB complexes in F05 where binding is characterized), REPORTED clinical rates (histologic-response thresholds, e.g. ≥90% necrosis = good response; 5-year survival ~63–65% in modern series), and named UNKNOWN parameters (micrometastatic seeding rates, chemoresistance emergence rates, stromal contribution coefficients) — each labeled per F12.
- **Regime:** declared at execution (CLOSED_LOOP / STANDALONE_AI / STANDALONE_SYSTEMS); a STANDALONE_AI result would never be presented as a closed-loop result.
- **Integrator:** fixed-step, deterministic, bit-identical trajectories.

This scaffold is DRAFT design — no model was executed for this entry. Nothing here is presented as a result.

---

## ED-ENC-FIELD-08 — HASH VERIFICATION RECORD

**No simulation was executed under this standard for this entry; therefore no hash exists.** The SHA-256 record covers (spec + parameters + initial state + regime + integrator + full trajectory) — with no executed simulation, there is nothing to hash, and this entry claims nothing.

**Hash discipline restated:** when an osteosarcoma simulation is executed under the F07 scaffold, its hash will be banked here with the full reproducibility manifest. Until then this field stands open and confessed. This confessed absence is the single blocking gap for COMPLETE (see self-grade).

---

## ED-ENC-FIELD-09 — TREATMENT LADDER (DOCUMENTED, STAGED)

Atlas posture: third person, past tense of the literature, named sources. What the field does — never what any person should do. This ladder documents established knowledge; it is not advice and contains no second-person language.

**Localized high-grade disease.** The REPORTED standard per the NCCN Guidelines for Patients: Bone Cancer (2026) combined neoadjuvant chemotherapy, surgical resection with wide margins, and adjuvant chemotherapy. Neoadjuvant preferred options were cisplatin + doxorubicin, or MAP (high-dose methotrexate, cisplatin, doxorubicin, with leucovorin rescue); other recommended options included doxorubicin + cisplatin + ifosfamide + high-dose methotrexate. [REPORTED — NCCN Bone Cancer patient guideline 2026; cancertherapyadvisor bone-cancer review]

**Surgery.** Wide excision with limb-salvage surgery was the REPORTED preferred surgical approach when achievable; amputation remained the requisite option for tumors not amenable to limb-sparing resection. [REPORTED — established literature; NCCN patient guide]

**Histologic response as the decision point.** The REPORTED practice assessed percent viable tumor after neoadjuvant chemotherapy: good response (<10% viable tumor / ≥90% necrosis) vs poor response (≥10% viable). Five-year disease-free survival was REPORTED as significantly higher for good responders (67.9%) than poor responders (51.3%). Good responders continued the same regimen; for poor responders, switching regimens was a category-3 consideration. [REPORTED — droracle treatment algorithm summarizing established practice]

**Metastatic / relapsed disease.** Second-line drug therapy options per the NCCN 2026 patient guideline: preferred — high-dose ifosfamide (± etoposide), regorafenib, sorafenib, cabozantinib; other recommended — cyclophosphamide + topotecan, gemcitabine ± docetaxel, everolimus + sorafenib, cyclophosphamide + etoposide, carboplatin + etoposide + ifosfamide; used in some cases — radium-223 for relapsed/refractory disease beyond second line. Resection of pulmonary metastases was an established component of management in selected patients. [REPORTED — NCCN Bone Cancer patient guideline 2026; oncohemakey]

**Mechanistic ties to F04–F05:** MAP chemotherapy acts at the cellular proliferation/survival programs (F04b); multi-kinase inhibitors (sorafenib, regorafenib, cabozantinib) target angiogenic/proliferative kinase signaling in the tumor–stroma compartment (F04c); the TP53/MDM2 and RB/E2F lesions (F04a–F05) currently have no REPORTED ladder rung acting directly on them — named as a gap, not as an opportunity.

---

## ED-ENC-FIELD-10 — PHARMACOLOGY — SLOT HELD, SEALED

**SEALED — Stage-1 pharmacology held; lift gated on Condition 6.**

Nothing more is written here. The slot's emptiness is the honest content. No simulation in this entry used pharmacology-stage material as an input; no entry content synthesizes what the sealed stage would contain. "The drug would probably…" is modeling around the seal — refused by construction.

---

## ED-ENC-FIELD-11 — UNKNOWN REGISTER

Per-field confessions. A field with no named UNKNOWNs would be an incomplete field.

- **F01:** MONDO ID not banked. Chain-verdict history empty — no independent scorer has graded this entry.
- **F02:** The definition centers conventional high-grade intramedullary disease; surface variants (parosteal/periosteal) and extraosseous osteosarcoma are named but not represented in the definition's core — a known gap.
- **F03:** The first transforming event in sporadic disease; the full genetic architecture of susceptibility; the quantitative partition of cases among TP53-mutant vs MDM2-amplified vs RB1-driven routes.
- **F04a:** Cellular ΔG/Kd kinetics of the MDM2–p53 and RB–E2F interactions (PDB structures are in-vitro complexes); the driver/passenger partition inside chromothriptic genomes; DNA-helicase molecular signatures.
- **F04b:** True tumor-initiating cell identity in the growth-plate niche; single-cell dynamics of chemoresistance emergence under MAP; cellular basis of pulmonary tropism.
- **F04c:** Determinants of early cortical breach vs prolonged intramedullary confinement; stromal contribution to chemoresistance in situ.
- **F04d:** Organ-level predictors of pathologic fracture; determinants of local recurrence after clear margins.
- **F04e:** Systemic mediators of pulmonary tropism; divergence between isolated resectable lung disease and diffuse spread; the immune axis in osteosarcoma.
- **F05:** No PDB verified in this entry for CDK4 or the VEGFR family (absence recorded as data). UniProt IDs for MDM2/CDK4 deliberately left unfilled.
- **F06:** Mol* links follow the standard's own pattern but were not live smoke-tested in this session; RCSB records were reached via search-result pages, not direct record verification of every ID's current status.
- **F07:** No simulation executed; the scaffold is normative design, not a run. IND-OSTEO-001 is a registered model name, not an executed trajectory in this entry's research.
- **F08:** No hash exists — confessed absence, the blocking gap.
- **F09:** Ladder reflects the NCCN Bone Cancer patient guideline (2026) and established literature as retrieved via web search; guideline versions evolve — the ladder is dated to its sources. Dosing detail deliberately omitted (atlas, not formulary).
- **F10:** Contents unknown by design (sealed). Hold-lift condition (Condition 6) still open.
- **F12:** Weakest-label audit performed by the authoring swarm only; independent double-scoring pending.

**Deepest UNKNOWNs (load-bearing, named for the coordinator):**
1. **No executed, hash-anchored simulation exists for osteosarcoma under this standard.** The engine registry name IND-OSTEO-001 is not a trajectory. This single gap is what blocks COMPLETE and caps the grade at PARTIAL.
2. **No predictive biomarker for MAP response** — histologic response is assessed after the fact, not predicted before it.
3. **The TP53/MDM2 and RB/E2F lesions have no REPORTED ladder rung acting directly on them** — the molecular scale and the treatment ladder are disconnected, and the entry does not bridge them.
4. **Pharmacology is sealed** — the slot is held, not worked around.

---

## ED-ENC-FIELD-12 — PROVENANCE MANIFEST

Every claim carries REPORTED / MODELED / UNKNOWN. Weakest-label rule applied throughout.

| Claim | Label | Source |
|---|---|---|
| ICD-11 2B51 = Osteosarcoma, primary site (block 2B50–2B5Z malignant mesenchymal neoplasms) | REPORTED | ICD-11 MMS v2026-01 (findacode) |
| Canonical definition (osteoid production requirement, metaphyseal, TP53/RB1-instability signature) | REPORTED | WHO histologic classification; oncohemakey osteosarcoma review |
| Conventional subtype ~80–90% of cases, high-grade; metaphyseal location ~80% | REPORTED | oncohemakey review |
| Sporadic chromosomal abnormality ~70% of specimens | REPORTED | oncohemakey bone-tumor review |
| Li–Fraumeni, RB1, Rothmund–Thomson, Bloom, Werner predisposition | REPORTED | established literature (slideshare bone-tumor review; statperson review) |
| Ionizing radiation ~2% of cases; only established environmental cause | REPORTED | statperson review |
| PDB 1YCR (MDM2–p53; Kussie et al., Science 1996) | REPORTED | RCSB PDB record |
| PDB 1O9K (RB pocket–E2F-1; Xiao et al., PNAS 2003) | REPORTED | RCSB PDB record |
| PDB 1TUP, 5LGY (p53 DBD complexes) | REPORTED | RCSB PDB (shared with program's CRC entry) |
| TP53/RB1 lesions as initiating events | MODELED | literature-inferred (near-universality + germline syndromes) |
| Histologic response thresholds; 67.9% vs 51.3% DFS | REPORTED | established practice (droracle treatment algorithm) |
| Treatment ladder (F09) | REPORTED | NCCN Guidelines for Patients: Bone Cancer, 2026; cancertherapyadvisor; oncohemakey |
| F07 simulation scaffold | MODELED | designed from the standard's bar; no execution — labeled design, not result |
| F08 hash record | UNKNOWN (confessed absence) | no executed simulation |
| F10 pharmacology | SEALED | stage-1 seal, Condition-6 lift pending |
| Micrometastases at presentation; pulmonary tropism mediators; MAP-response biomarkers | UNKNOWN | named in F11 |
| Weakest-label compliance | Self-audited | independent double-scoring pending |

---

## SELF-GRADE AGAINST THE COMPLETENESS RUBRIC

**Rubric criteria (ED-ENC-20260929 §2):**

1. *All twelve fields present; none absent.* ✅ — F01–F12 all present; F07/F08/F10 present-but-fenced (permitted).
2. *All five scales closed or explicitly fenced.* ✅ — F04a–e each carry knowns / borrowed inferences / named UNKNOWNs.
3. *F06: every structural target with a PDB ID carries a Mol\* link; targets without structures named as UNKNOWN.* ✅ — 4 structures linked via the standard's Mol* pattern; CDK4, VEGFR named as UNKNOWN, not skipped. (Links not live smoke-tested — confessed in F11.)
4. *F07–F08: at least one simulation executed under the bar with an anchored, recomputable SHA-256 hash.* ❌ — **This is the failing criterion.** No simulation was executed. IND-OSTEO-001 is a registry name, not a trajectory. Nothing is hash-anchored.
5. *F09: ladder from named sources; no second-person language.* ✅ — NCCN Bone Cancer patient guideline 2026 and established literature cited; third person throughout.
6. *F10: slot present and correctly marked SEALED with the hold condition named.* ✅ — verbatim seal text, Condition 6 named.
7. *F12: every claim labeled; weakest-label rule applied; zero unlabeled claims.* ✅ (self-audit) — independent double-scoring still pending.

**Grade: PARTIAL.** Reasoning: schema-shaped with honestly populated load-bearing fields, but criterion 4 fails — no hash-anchored simulation exists, and the entry cannot honestly claim SUBSTANTIAL either, since SUBSTANTIAL requires ≥1 executed simulation ("hash unanchored or 3D missing") and there is no executed simulation at all. The F07 scaffold is real design — the dual-pipeline osteosarcoma model (TP53/MDM2–RB/E2F Pole A, growth-plate/pulmonary-niche Pole B) is a genuine simulation *design* — but design is not execution, and the standard is explicit: metrics without the trajectory are not a simulation; a scaffold without a run is not a simulation either. Grading the design as a simulation would launder gloss into the arithmetic. So: PARTIAL, with the single blocking gap named — execute an osteosarcoma simulation under the F07 scaffold, bank the trajectory, anchor the hash, and this entry moves toward SUBSTANTIAL (then COMPLETE once 3D links are smoke-tested and independent double-scoring lands).

**Self-grade confidence:** performed by the authoring swarm against the written rubric; per the standard's residual 5, the first independent double-scoring will test whether the rubric reproduces. This grade is provisional pending verdict-gating.

---

## CHAIN-OF-CUSTODY NOTES (for the coordinator)

- No staged design papers existed for this disease; all REPORTED claims derive from web research conducted 2026-09-29, labeled per source. PDB IDs were taken from RCSB-indexed records with cited deposition literature; ICD-11 from the MMS v2026-01 via findacode.
- The engine registry name IND-OSTEO-001 was NOT counted as a simulation — a registry name is not a trajectory.
- The Terry Fox homage token (design-nuances-homage-tokens-20260929.md) is PRESENTATION-LAYER ONLY: it does not touch this entry's paper, schema, or the medical standard. No tribute content appears anywhere in this entry.
- No second-person language anywhere in F09; atlas-not-advisor fence held.
- Pharmacology seal: held exactly, never modeled around.
- DRAFT only. No seal. Nothing deploys. The launch gate holds.

*End of ED-ENC-ONCO-002 V1 — DRAFT, no seal, gate holds.*
