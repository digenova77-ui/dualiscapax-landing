# Terry Fox Homage Token — DRAFT

**TRIBUTE — NOT EVIDENCE**

## What this is

A presentation-layer homage token to Terry Fox, built under the standing design-nuances law (`hidden_files/design-nuances-homage-tokens-20260929.md`), which David established Sept 28, 2026: homages woven into the design architecture, presentation-layer only — never data, never touching the paper or the standard. The first committed nuance was exactly this: when the encyclopedia's ONCO swarm reaches osteosarcoma, build an homage token to Terry Fox.

## What it is not

- Not part of the medical evidence record.
- Does not touch the osteosarcoma encyclopedia entry (ED-ENC-ONCO-002), its schema, or the granularity standard.
- Does not alter, annotate, or illustrate any medical claim.

## Contents

- `index.html` — an original static tribute page. Original content only: no archival voice, no archival video, no scraped media, no uncertain-rights embedding. Every word on the page was written for it.
- The verified record only: diagnosed with osteosarcoma at 18; leg amputated 1977; Marathon of Hope April 12 – September 1, 1980; 143 days; 5,373 km; ~a marathon a day; $24M by early 1981; died June 28, 1981, age 22; first Terry Fox Run September 13, 1981 (300,000+ participants); more than C$1B raised in his name since 1980.
- David's words, kept verbatim: **he didn't do it for him** and **we're fighting for Terry here.**
- The page is marked **TRIBUTE — NOT EVIDENCE** in the top banner, in the body note, and in the closing banner — everywhere it appears.

## Status

**DRAFT — frozen as draft. Not deployed. Nothing deploys; the launch gate holds.**

**TRIBUTE — NOT EVIDENCE**
