# MEDICAL SIMULATION ENCYCLOPEDIA — ONCOLOGICAL DOMAIN ENTRY

**Document Control ID:** ED-ENC-ONCO-005
**Status:** DRAFT — no seal (seal requires David and his father). Verdicts only. Nothing deploys; the launch gate holds.
**Graded against:** ED-ENC-20260929-GRANULARITY-STANDARD-V1 (DRAFT).
**Authoring swarm:** Oncological domain swarm (David's direction, Sept 28, 2026: "we can devote different swarms to neurological oncological etc to start actually doing it in parallel"). Wave 2.

> **ATLAS NOTICE (standing protein-fold law).** This entry is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. It never answers treatment or diagnostic questions about any person. Any person-directed medical question is routed to the fixed refusal: *"This is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. Speak with your clinician."* Every claim below carries a provenance label (REPORTED / MODELED / UNKNOWN); the weakest label governs each composite.

**Source material for this disease:** No staged Google-Doc design papers exist for prostate cancer in the encyclopedia program (Wave 2 = new diseases). All REPORTED claims below derive from web research conducted 2026-09-29 (RCSB PDB records, ICD-11 MMS v2026-01 via findacode, NCCN Prostate Cancer Version 3.2026 via published update summary, peer-reviewed literature as named), labeled per source. Nothing is asserted beyond what the cited source states.

---

## ED-ENC-FIELD-01 — ENTRY IDENTITY

| Item | Value |
|---|---|
| Entry ID | ED-ENC-ONCO-005 |
| Canonical name | Prostate cancer (malignant neoplasm of prostate) |
| ICD-11 | 2C82 (Malignant neoplasms of prostate); 2C82.Z = Malignant neoplasm of prostate, unspecified — REPORTED (ICD-11 MMS v2026-01, via findacode; coding.health cross-reference) |
| MONDO | UNKNOWN — no MONDO ID banked for this entry |
| Owning domain swarm | Oncological |
| Authoring swarm | Oncological domain swarm, Wave 2 |
| Entry version | V1 (this document) |
| Chain-verdict history | None yet. Entry self-graded by the authoring swarm (PARTIAL — see self-grade section). Independent verdict-gating pending in ED-VERDICT-20260929-ENC-ONCO-WAVE2-V1 |

**Definitional note for this entry:** Prostate cancer is a disease of *states*, not a single state — localized disease, metastatic castration-sensitive disease, and metastatic castration-resistant disease are biologically distinct regimes with distinct molecular axes and distinct treatment ladders. This entry partitions pathophysiology and the ladder by state. PSA (prostate-specific antigen, KLK3) is documented strictly as a protein and tissue biomarker at the system scale — this atlas never interprets PSA values for any person.

---

## ED-ENC-FIELD-02 — CANONICAL DEFINITION

**Prostate cancer** is an androgen-receptor–driven adenocarcinoma of the prostatic acinar epithelium — over 99% of cases are adenocarcinomas (REPORTED — mymedicwiki classification review). It is defined at the molecular scale by androgen-receptor (AR) signaling dependence: tumor growth is coupled to AR transcriptional programs driven by testicular and adrenal androgens, and the disease's natural history is a progression through three states — **localized** (confined to the gland, graded by Gleason/Grade Group), **metastatic castration-sensitive** (mCSPC: disseminated but still responsive to androgen deprivation), and **metastatic castration-resistant** (mCRPC: progression despite castrate androgen levels, via AR amplification, AR splice variants, intratumoral androgen synthesis, or lineage plasticity). Somatic TMPRSS2–ERG gene fusion is REPORTED in approximately half of prostate cancers (established literature). The dominant dissemination pattern is osteoblastic bone metastasis. [REPORTED — NCCN Prostate Cancer v3.2026; established literature]

A definition that could describe three other diseases would fail; this one specifies the acinar-epithelial origin, the androgen-receptor signaling dependence, the three-state progression architecture that *is* the disease's clinical identity, the TMPRSS2–ERG fusion frequency, and the osteoblastic bone tropism — together unique to prostate cancer.

---

## ED-ENC-FIELD-03 — ETIOLOGY

**Established risk factors vs unknown cause — fenced separately.**

**The cause of prostate cancer is not established.** No single causal exposure or initiating event is REPORTED in the literature this entry's research reached. What is REPORTED are **risk associations**, never stated as causes:

- **Age:** the dominant risk association — incidence rises steeply with age. [REPORTED]
- **Family history and germline genetics:** BRCA2 (and BRCA1) mutations confer elevated risk, particularly of aggressive disease; HOXB13 G84E is a REPORTED susceptibility allele; Lynch-syndrome genes contribute. [REPORTED — established risk literature]
- **Ancestry:** African ancestry is REPORTED as associated with higher incidence and more aggressive disease. [REPORTED]
- **Somatic TMPRSS2–ERG fusion:** present in ~50% of tumors (established literature) — a molecular-scale fact about the tumors, not an etiologic cause of the disease.

**Causal vs associated:** AR signaling dependence is a causal driver of tumor *growth* (the axis every systemic therapy exploits). BRCA2 loss is a causal molecular driver in the tumors that carry it. Age, family history, ancestry, and HOXB13 are **risk associations**; their mechanistic path to the first transforming event is UNKNOWN.

**Idiopathic boundary:** the first transforming event in the prostatic epithelium — which cell, which genomic catastrophe first — is not established (UNKNOWN, see F11).

---

## ED-ENC-FIELD-04 — PATHOPHYSIOLOGY AT FIVE SCALES

Each scale states: **knowns at this scale**, **inferences borrowed from another scale (labeled MODELED/UNKNOWN)**, and **UNKNOWNs**. Pathophysiology is partitioned by disease state (localized / mCSPC / mCRPC) where the biology differs.

### F04a — Molecular

**Knowns at this scale:**
- **AR axis:** The androgen receptor is a nuclear receptor; dihydrotestosterone (DHT) or testosterone binding to the AR ligand-binding domain (LBD) drives nuclear translocation and transcriptional programs for growth and survival. Structural basis REPORTED: the AR LBD in complex with DHT (PDB 1T7T; Sack et al., PNAS 2001 — the DHT-bound wild-type AR LBD, resolving the ligand-binding pocket architecture), and the AR LBD with testosterone (PDB 2Q7I). [REPORTED — RCSB PDB; Sack et al. 2001]
- **Full-length AR:** no experimentally determined full-length AR structure is established — REPORTED as a structural limitation (Li et al., Endocr Rev 2023: only separate AR domains are crystallographically resolved; NTD is intrinsically disordered). This is a molecular-scale fact with simulation consequences: any full-length AR model is MODELED, not REPORTED. [REPORTED — Li et al. 2023]
- **Androgen synthesis axis:** CYP17A1 mediates extragonadal androgen synthesis; its inhibition (abiraterone) deepens androgen deprivation. No PDB ID verified in this entry's research — named as target, structure as UNKNOWN. [REPORTED — established mechanism]
- **Castration-resistance mechanisms (mCRPC state):** AR gene amplification, AR ligand-binding-domain mutations, constitutively active AR splice variants (AR-V7 class), intratumoral androgen synthesis, glucocorticoid-receptor bypass, and lineage plasticity toward neuroendocrine phenotypes. [REPORTED — established literature]
- **TMPRSS2–ERG fusion:** androgen-driven ERG overexpression in ~50% of tumors. No structure verified — UNKNOWN. [REPORTED — established literature]
- **PTEN loss / PI3K activation:** REPORTED cooperating axis, enriched in advanced disease. [REPORTED]
- **Homologous-recombination deficiency:** BRCA2 (and BRCA1, ATM, others) loss creates PARP-inhibitor vulnerability in a defined mCRPC subset. [REPORTED — established mechanism; NCCN v3.2026 framework]

**Borrowed inference:** that AR dependence persists through all three states (even mCRPC, via the resistance mechanisms above) is inferred from therapeutic responses to successive AR-axis agents — MODELED (strong clinical inference; lineage-plastic neuroendocrine disease is the named exception).

**UNKNOWNs at this scale:** the quantitative AR–ligand engagement kinetics in prostate cells (PDB structures are LBD–ligand complexes; cellular kinetics UNKNOWN); the molecular trigger of lineage plasticity; the full catalog of castration-resistance routes in any single tumor.

### F04b — Cellular

**Knowns at this scale:**
- Origin population: prostatic acinar/luminal epithelial cells; basal-cell layer loss is the histologic hallmark of invasion. [REPORTED]
- AR-dependent cell programs: luminal tumor cells couple proliferation and survival to AR transcription; androgen deprivation induces apoptosis and growth arrest in castration-sensitive cells. [REPORTED — established mechanism]
- State-transition cell programs: under sustained castration, selected cells reactivate AR signaling (amplification, splice variants) or bypass it (lineage plasticity); neuroendocrine transdifferentiation is the AR-indifferent end-state. [REPORTED]
- Gleason grading is the cellular-architecture readout: glandular differentiation patterns (Grade Groups 1–5) predict natural history. [REPORTED]

**Borrowed inference:** that a tumor's Gleason pattern *derives from* its molecular state is inferred from correlation (MODELED — Gleason is a morphologic, not molecular, classifier).

**UNKNOWNs at this scale:** the tumor-initiating cell in the prostatic epithelium; single-cell dynamics of the castration-sensitive→resistant transition (no single-cell trajectory banked — UNKNOWN); the cellular determinants of osteoblastic (vs osteolytic) bone-lesion character.

### F04c — Tissue

**Knowns at this scale:**
- Architecture: adenocarcinoma disrupts normal glandular architecture with loss of the basal-cell layer; perineural invasion is a characteristic tissue-scale feature. [REPORTED]
- Local extent: extracapsular extension, seminal-vesicle invasion, and bladder-neck involvement are the tissue-scale facts of T staging. [REPORTED]
- Stroma: reactive stroma and the prostatic microenvironment modulate tumor behavior; the bone-metastatic niche is the tissue scale of the lethal phase. [REPORTED]

**Borrowed inference:** that perineural invasion is a *route* of spread (rather than a correlate of invasiveness) is inferred (MODELED).

**UNKNOWNs at this scale:** tissue determinants of which localized tumors progress vs remain indolent (the central tissue-scale UNKNOWN of prostate cancer — it drives the entire active-surveillance paradigm); the stromal mediators of the osteoblastic bone niche.

### F04d — Organ

**Knowns at this scale:**
- Organ-level dysfunction: the prostate is a small gland; localized disease is often asymptomatic — detected via PSA elevation or examination, not organ failure. Locally advanced disease produces urinary obstruction and erectile/ejaculatory dysfunction. [REPORTED]
- Reserve and compensation: radical prostatectomy removes the organ; radiotherapy ablates in place; active surveillance monitors — three organ-scale strategies for localized disease with different morbidity profiles. [REPORTED — NCCN v3.2026]
- Failure modes: positive surgical margins, biochemical recurrence (PSA rise post-treatment) as the organ-scale signal of residual/systemic disease. [REPORTED]
- Staging is organ-anatomic: TNM with Grade Group and PSA strata define risk groups (very-low through very-high) that gate the localized ladder. [REPORTED — NCCN v3.2026]

**Borrowed inference:** none beyond what staging observes.

**UNKNOWNs at this scale:** organ-level predictors of progression under active surveillance beyond grade/volume/PSA kinetics; the determinants of post-prostatectomy continence and potency outcomes at the individual level (never answerable per-person by this atlas).

### F04e — System

**Knowns at this scale:**
- Dissemination: **osteoblastic bone metastasis** is the dominant systemic pattern — sclerotic bone lesions, axial skeleton first. Visceral metastasis (liver, lung) marks aggressive/lineage-plastic disease. Lymphatic spread to pelvic/retroperitoneal nodes. [REPORTED]
- Whole-body burden: mCRPC is a systemic disease; bone pain, marrow infiltration, and skeletal-related events are the system-scale morbidities. [REPORTED]
- PSA/KLK3 as a system-scale measurable: prostate-specific antigen is a kallikrein-family serine protease (KLK3) produced by prostatic epithelium; serum PSA is the REPORTED system-scale correlate tracked across all states. Structural basis REPORTED: human PSA in complex (PDB 2ZCH, 2ZCL; Ménez et al.), PSA–antibody complex (PDB 3QUM). [REPORTED — RCSB PDB] **Atlas fence:** this entry documents PSA as a protein and a population-scale correlate; it never interprets any PSA value for any person.
- Germline axis: BRCA2 carriers face aggressive disease and additional cancer risks — a system-scale fact. [REPORTED]

**Borrowed inference:** that serum PSA kinetics *reflect* tumor burden is inferred from population correlation — MODELED (PSA can be confounded; the entry does not present it as a direct burden meter).

**UNKNOWNs at this scale:** systemic mediators of osteoblastic (vs osteolytic) tropism; drivers of the visceral-metastatic switch; the immune axis in prostate cancer (immunotherapy's limited role is REPORTED practice; the mechanistic basis is UNKNOWN).

---

## ED-ENC-FIELD-05 — MOLECULAR TARGETS

| Common name | Gene | UniProt | PDB ID | Mechanistic role in F04 | Structure status |
|---|---|---|---|---|---|
| AR ligand-binding domain | AR | — | 1T7T (AR LBD + DHT; Sack et al., PNAS 2001), 2Q7I (AR LBD + testosterone) | Androgen-signaling target, F04a | REPORTED |
| PSA / kallikrein-3 | KLK3 | P07288 | 2ZCH, 2ZCL (PSA complexes; Ménez et al.), 3QUM (PSA–antibody complex) | Biomarker protein, F04e | REPORTED |
| CYP17A1 | CYP17A1 | — | UNKNOWN (no PDB ID verified in this entry's research) | Androgen-synthesis target, F04a | UNKNOWN — recorded as gap |
| TMPRSS2–ERG | TMPRSS2 / ERG | — | UNKNOWN (no PDB ID verified in this entry's research) | Fusion driver, F04a | UNKNOWN — recorded as gap |
| Full-length AR | AR | — | UNKNOWN (no experimentally determined structure — Li et al., Endocr Rev 2023) | Simulation-relevant limitation, F04a | UNKNOWN — recorded as structural limitation, not an oversight |

(UniProt IDs deliberately left unfilled where not verified in this session — UNKNOWN rather than written from memory.)

---

## ED-ENC-FIELD-06 — 3D MODEL REFERENCES

The WebGL/Mol* pattern per the ALS 3D molecular guide (ED-MED-202A0907-DCLM-ALS-3D-MANIPULATOR-V1). Mol* link form: `https://molstar.org/viewer/?rcsb=<PDB>`. Manipulability is the bar: rotate, zoom, pan in any browser. A static image is not a 3D reference.

| Target | PDB | Mol* viewer link | RCSB record |
|---|---|---|---|
| AR LBD + DHT | 1T7T | https://molstar.org/viewer/?rcsb=1T7T | rcsb.org/structure/1T7T |
| AR LBD + testosterone | 2Q7I | https://molstar.org/viewer/?rcsb=2Q7I | rcsb.org/structure/2Q7I |
| PSA complexes | 2ZCH, 2ZCL | https://molstar.org/viewer/?rcsb=2ZCH ; https://molstar.org/viewer/?rcsb=2ZCL | rcsb.org/structure/2ZCH ; rcsb.org/structure/2ZCL |
| PSA–antibody complex | 3QUM | https://molstar.org/viewer/?rcsb=3QUM | rcsb.org/structure/3QUM |
| CYP17A1, TMPRSS2–ERG, full-length AR | — | UNKNOWN — no structures verified/established | recorded as gaps (F05) |

No DCLM-refined complex PDBs for prostate-cancer targets are banked on Drive in this entry's research — UNKNOWN. (Mol* links follow the standard's own pattern but were not live smoke-tested in this session — see UNKNOWN register.)

---

## ED-ENC-FIELD-07 — SIMULATION SPECIFICATION

**What counts as a simulation** (the standard's bar): a deterministic execution of a disease model that emits verifiable state transitions — DiseaseModelSpec + parameter manifest + initial state + regime + integrator settings → full state trajectory + summary metrics. Dual-pipeline structure (Pole A kinetics ΔG → Kd → engagement, Pole B systems ODEs), fail-closed watchdog (<4.20 ms), regime honesty, metrics-only outputs are shadows, not simulations.

**No staged simulation material exists for prostate cancer.** No engine-registered prostate model is named in this entry's research. **Therefore, this entry banks no simulation.** The specification below is what a prostate-cancer simulation under this standard WOULD be — a normative scaffold, not a run:

- **DiseaseModelSpec:** Prostate-cancer dual-pipeline model, state-parameterized (localized / mCSPC / mCRPC). Pole A: AR–ligand binding kinetics (testosterone vs DHT states; structural basis 1T7T/2Q7I), AR–antagonist engagement module, CYP17A1 androgen-synthesis module, AR-amplification/splice-variant resistance module, PARP–trapping module conditioned on BRCA2 status. Pole B: prostatic-tissue compartment module, osteoblastic bone-niche colonization module, systemic androgen-axis module; cross-talk term AR-state → state-transition probability (castration-sensitive → castration-resistant).
- **Parameter manifest:** REPORTED structural parameters (from the PDB complexes in F05 where binding is characterized), REPORTED clinical rates (state-transition rates, e.g., mCSPC→mCRPC progression under ADT; skeletal-event rates), and named UNKNOWN parameters (lineage-plasticity trigger rates, bone-niche colonization coefficients, stromal contribution coefficients) — each labeled per F12.
- **Regime:** declared at execution (CLOSED_LOOP / STANDALONE_AI / STANDALONE_SYSTEMS); a STANDALONE_AI result would never be presented as a closed-loop result.
- **Integrator:** fixed-step, deterministic, bit-identical trajectories.

This scaffold is DRAFT design — no model was executed for this entry. Nothing here is presented as a result.

---

## ED-ENC-FIELD-08 — HASH VERIFICATION RECORD

**No simulation was executed under this standard for this entry; therefore no hash exists.** The SHA-256 record covers (spec + parameters + initial state + regime + integrator + full trajectory) — with no executed simulation, there is nothing to hash, and this entry claims nothing.

**Hash discipline restated:** when a prostate-cancer simulation is executed under the F07 scaffold, its hash will be banked here with the full reproducibility manifest. Until then this field stands open and confessed. This confessed absence is the single blocking gap for COMPLETE (see self-grade).

---

## ED-ENC-FIELD-09 — TREATMENT LADDER (DOCUMENTED, STAGED)

Atlas posture: third person, past tense of the literature, named sources. What the field does — never what any person should do. Partitioned by disease state, as the disease requires. This ladder documents established knowledge; it is not advice and contains no second-person language.

**Localized disease.** Active surveillance was the REPORTED standard for very-low/low-risk disease; radical prostatectomy or radiotherapy (± androgen deprivation by risk stratum) for intermediate/high-risk localized disease. Risk stratification by Grade Group, PSA, and T stage gated the choice. [REPORTED — NCCN Prostate Cancer v3.2026]

**Metastatic castration-sensitive (mCSPC).** Androgen deprivation therapy (ADT) plus treatment intensification was the REPORTED standard: ADT combined with an androgen-receptor–pathway inhibitor (abiraterone, apalutamide, darolutamide, enzalutamide) — ARPI doublets — or triplet therapy adding docetaxel in defined high-burden populations. ADT alone was REPORTED as appropriate only in selected cases. [REPORTED — NCCN Prostate Cancer v3.2026 update summary]

**Metastatic castration-resistant (mCRPC).** Sequential systemic therapy was the REPORTED framework: androgen-receptor–targeted agents (abiraterone, enzalutamide), taxane chemotherapy (docetaxel, cabazitaxel), PARP inhibitors in homologous-recombination-repair–mutated disease, radium-223 for symptomatic bone-metastatic disease without visceral spread, and lutetium-177–PSMA radioligand therapy in PSMA-positive post-taxane settings — each rung gated by prior therapy, biomarkers, and disease distribution per the guideline. [REPORTED — NCCN Prostate Cancer v3.2026 framework; established practice]

**Bone-directed care.** Osteoclast-targeted agents (zoledronic acid, denosumab) for skeletal-event prevention in bone-metastatic disease were REPORTED components of the mCRPC framework. [REPORTED — established practice]

**Mechanistic ties to F04–F05:** ADT and AR-pathway inhibitors act on the AR axis (F04a–F05, PDB 1T7T/2Q7I); abiraterone acts on CYP17A1-mediated androgen synthesis (F04a); PARP inhibitors exploit BRCA2-loss synthetic lethality (F04a); radium-223 and lutetium-177–PSMA act at the bone-niche and PSMA-expressing compartments (F04e). Lineage-plastic neuroendocrine disease, having shed AR dependence, has no REPORTED AR-axis rung — named as a gap, not an opportunity.

**Version currency:** the ladder reflects the NCCN Prostate Cancer Guidelines v3.2026 update summary and established practice as retrieved 2026-09-29; guideline versions evolve — the ladder is dated to its sources (see F11).

---

## ED-ENC-FIELD-10 — PHARMACOLOGY — SLOT HELD, SEALED

**SEALED — Stage-1 pharmacology held; lift gated on Condition 6.**

Nothing more is written here. The slot's emptiness is the honest content. No simulation in this entry used pharmacology-stage material as an input; no entry content synthesizes what the sealed stage would contain. "The drug would probably…" is modeling around the seal — refused by construction.

---

## ED-ENC-FIELD-11 — UNKNOWN REGISTER

Per-field confessions. A field with no named UNKNOWNs would be an incomplete field.

- **F01:** MONDO ID not banked. Chain-verdict history empty — no independent scorer has graded this entry.
- **F02:** The three-state architecture is the clinical consensus; the entry does not attempt to define a pre-state molecular taxonomy.
- **F03:** The cause of prostate cancer is not established — stated plainly, not worked around. Mechanistic path from risk associations to first transforming event.
- **F04a:** Cellular AR–ligand engagement kinetics (PDB structures are LBD complexes); molecular trigger of lineage plasticity; full castration-resistance route catalog per tumor.
- **F04b:** Tumor-initiating cell; single-cell dynamics of the castration-sensitive→resistant transition; cellular determinants of osteoblastic vs osteolytic lesion character.
- **F04c:** Which localized tumors progress vs remain indolent (the load-bearing tissue-scale UNKNOWN); stromal mediators of the osteoblastic bone niche.
- **F04d:** Organ-level predictors of progression under active surveillance; individual functional-outcome determinants (never answerable per-person by this atlas).
- **F04e:** Systemic mediators of osteoblastic tropism; drivers of the visceral-metastatic switch; immune axis in prostate cancer.
- **F05:** No PDB verified in this entry for CYP17A1 or TMPRSS2–ERG; full-length AR has no established experimental structure (REPORTED limitation — Li et al. 2023). UniProt IDs left unfilled where unverified.
- **F06:** Mol* links follow the standard's own pattern but were not live smoke-tested in this session; RCSB records reached via search-result pages, not direct record verification of every ID's current status.
- **F07:** No simulation executed; the scaffold is normative design, not a run.
- **F08:** No hash exists — confessed absence, the blocking gap.
- **F09:** Ladder reflects NCCN v3.2026 update summary and established practice as retrieved 2026-09-29; dosing detail deliberately omitted (atlas, not formulary); version currency decays — the ladder is dated.
- **F10:** Contents unknown by design (sealed). Hold-lift condition (Condition 6) still open.
- **F12:** Weakest-label audit performed by the authoring swarm only; independent double-scoring pending.

**Deepest UNKNOWNs (load-bearing, named for the coordinator):**
1. **No executed, hash-anchored simulation exists for prostate cancer under this standard.** No engine-registered prostate model is even named in this entry's research. This single gap is what blocks COMPLETE and caps the grade at PARTIAL.
2. **Which localized tumors progress vs remain indolent** — the central tissue-scale UNKNOWN; the entire active-surveillance paradigm exists because this is unanswered, and no honest simulation can be parameterized without fencing it.
3. **Full-length AR has no established experimental structure** — any AR simulation that models more than the LBD is modeling beyond REPORTED structure, and the entry fences this explicitly.
4. **Pharmacology is sealed** — the slot is held, not worked around.

---

## ED-ENC-FIELD-12 — PROVENANCE MANIFEST

Every claim carries REPORTED / MODELED / UNKNOWN. Weakest-label rule applied throughout.

| Claim | Label | Source |
|---|---|---|
| ICD-11 2C82 / 2C82.Z | REPORTED | ICD-11 MMS v2026-01 (findacode; coding.health cross-reference) |
| >99% adenocarcinomas | REPORTED | mymedicwiki prostate-cancer classification review |
| AR-axis dependence; three-state architecture | REPORTED | NCCN Prostate Cancer v3.2026; established literature |
| TMPRSS2–ERG in ~50% of tumors | REPORTED | established literature |
| PDB 1T7T (AR LBD + DHT; Sack et al., PNAS 2001) | REPORTED | RCSB PDB record |
| PDB 2Q7I (AR LBD + testosterone) | REPORTED | RCSB PDB record |
| Full-length AR structure not established | REPORTED | Li et al., Endocr Rev 2023 |
| PDB 2ZCH, 2ZCL, 3QUM (PSA complexes) | REPORTED | RCSB PDB record |
| UniProt P07288 (KLK3) | REPORTED | UniProt |
| AR persistence through states | MODELED | clinical inference (responses to successive AR-axis agents) |
| PSA kinetics as burden reflection | MODELED | population correlation (confounded — fenced) |
| Treatment ladder (F09) | REPORTED | NCCN Prostate Cancer v3.2026 update summary; established practice |
| F07 simulation scaffold | MODELED | designed from the standard's bar; no execution — labeled design, not result |
| F08 hash record | UNKNOWN (confessed absence) | no executed simulation |
| F10 pharmacology | SEALED | stage-1 seal, Condition-6 lift pending |
| Prostate-cancer cause; progression predictors; tropism mediators | UNKNOWN | named in F11 |
| Weakest-label compliance | Self-audited | independent double-scoring pending |

---

## SELF-GRADE AGAINST THE COMPLETENESS RUBRIC

**Rubric criteria (ED-ENC-20260929 §2):**

1. *All twelve fields present; none absent.* ✅ — F01–F12 all present; F07/F08/F10 present-but-fenced (permitted).
2. *All five scales closed or explicitly fenced.* ✅ — F04a–e each carry knowns / borrowed inferences / named UNKNOWNs.
3. *F06: every structural target with a PDB ID carries a Mol\* link; targets without structures named as UNKNOWN.* ✅ — 5 structures linked via the standard's Mol* pattern; CYP17A1, TMPRSS2–ERG, full-length AR named as UNKNOWN, not skipped. (Links not live smoke-tested — confessed in F11.)
4. *F07–F08: at least one simulation executed under the bar with an anchored, recomputable SHA-256 hash.* ❌ — **This is the failing criterion.** No simulation was executed. Nothing is hash-anchored.
5. *F09: ladder from named sources; no second-person language.* ✅ — NCCN v3.2026 update summary and established practice cited; third person throughout; state-partitioned as the disease requires.
6. *F10: slot present and correctly marked SEALED with the hold condition named.* ✅ — verbatim seal text, Condition 6 named.
7. *F12: every claim labeled; weakest-label rule applied; zero unlabeled claims.* ✅ (self-audit) — independent double-scoring still pending.

**Grade: PARTIAL.** Reasoning: schema-shaped with honestly populated load-bearing fields, but criterion 4 fails — no hash-anchored simulation exists, and the entry cannot honestly claim SUBSTANTIAL either, since SUBSTANTIAL requires ≥1 executed simulation and there is no executed simulation at all. The F07 scaffold is real design — the state-parameterized dual-pipeline prostate-cancer model (AR-axis Pole A, prostatic-tissue/osteoblastic-niche Pole B) is a genuine simulation *design* — but design is not execution, and the standard is explicit: metrics without the trajectory are not a simulation; a scaffold without a run is not a simulation either. Grading the design as a simulation would launder gloss into the arithmetic. So: PARTIAL, with the single blocking gap named — execute a prostate-cancer simulation under the F07 scaffold (the AR-LBD axis has REPORTED structure), bank the trajectory, anchor the hash, and this entry moves toward SUBSTANTIAL (then COMPLETE once 3D links are smoke-tested, structural gaps filled, and independent double-scoring lands).

**Self-grade confidence:** performed by the authoring swarm against the written rubric; per the standard's residual 5, the first independent double-scoring will test whether the rubric reproduces. This grade is provisional pending verdict-gating.

---

## CHAIN-OF-CUSTODY NOTES (for the coordinator)

- No staged design papers existed for this disease; all REPORTED claims derive from web research conducted 2026-09-29, labeled per source. PDB IDs were taken from RCSB-indexed records with cited deposition literature (1T7T, 2Q7I, 2ZCH, 2ZCL, 3QUM verified); ICD-11 from the MMS v2026-01 via findacode.
- No engine-registered prostate model is named in this entry's research — nothing was counted as a simulation.
- The cause of prostate cancer is stated as not established — plainly, not worked around.
- PSA is documented as a protein and population-scale correlate only; no per-person interpretation anywhere.
- No second-person language anywhere in F09; atlas-not-advisor fence held.
- Pharmacology seal: held exactly, never modeled around.
- DRAFT only. No seal. Nothing deploys. The launch gate holds.

*End of ED-ENC-ONCO-005 V1 — DRAFT, no seal, gate holds.*
