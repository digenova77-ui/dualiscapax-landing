## Claim-scope convention — confirmed standing (2026-09-29 ~00:21 EDT)

Collision question from Base 3D R3 resolved: when a claim hash collides with a
COMPLETED claim but the work is genuinely new (new rotation, new scope), the
worker claims under a rotation-differentiated scope (e.g.
`base-3d-website-r3`) rather than standing down. Rationale: the idempotency
law prevents duplicate work, not new work; a hard stand-down on any collision
would wrongly block genuine new rotations. The registry keeps one entry per
rotation scope; no entry is ever altered or duplicated. Near-duplicate scopes
still go to scope review per ED-SPEC-20260929-SWARM-CLAIMS-V1.

