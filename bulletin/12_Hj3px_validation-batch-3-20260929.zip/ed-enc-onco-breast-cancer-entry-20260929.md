# MEDICAL SIMULATION ENCYCLOPEDIA — ONCOLOGICAL DOMAIN ENTRY

**Document Control ID:** ED-ENC-ONCO-003
**Status:** DRAFT — no seal (seal requires David and his father). Verdicts only. Nothing deploys; the launch gate holds.
**Graded against:** ED-ENC-20260929-GRANULARITY-STANDARD-V1 (DRAFT).
**Authoring swarm:** Oncological domain swarm (David's direction, Sept 28, 2026: "we can devote different swarms to neurological oncological etc to start actually doing it in parallel"). Wave 2.

> **ATLAS NOTICE (standing protein-fold law).** This entry is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. It never answers treatment or diagnostic questions about any person. Any person-directed medical question is routed to the fixed refusal: *"This is an atlas of disease understanding, not a medical advisor. It documents what is known; it does not advise. Speak with your clinician."* Every claim below carries a provenance label (REPORTED / MODELED / UNKNOWN); the weakest label governs each composite.

**Source material for this disease:** No staged Google-Doc design papers exist for breast cancer in the encyclopedia program (Wave 2 = new diseases). All REPORTED claims below derive from web research conducted 2026-09-29 (RCSB PDB records, ICD-11 MMS via findacode/drlogy extracts, NCCN Breast Cancer update summaries v5.2025, peer-reviewed literature as named), labeled per source. Nothing is asserted beyond what the cited source states.

---

## ED-ENC-FIELD-01 — ENTRY IDENTITY

| Item | Value |
|---|---|
| Entry ID | ED-ENC-ONCO-003 |
| Canonical name | Breast cancer |
| ICD-11 | 2C6 block — Carcinoma of breast; 2C61 = Invasive carcinoma of breast; 2C61.0 = Invasive ductal carcinoma; 2C61.1 = Invasive lobular carcinoma; 2C6Z = Malignant neoplasm of breast, unspecified — REPORTED (ICD-11 MMS extracts via drlogy; also cross-referenced via findacode) |
| MONDO | UNKNOWN — no MONDO ID banked for this entry |
| Owning domain swarm | Oncological |
| Authoring swarm | Oncological domain swarm, Wave 2 |
| Entry version | V1 (this document) |
| Chain-verdict history | None yet. Entry self-graded by the authoring swarm (PARTIAL — see self-grade section). Independent verdict-gating pending in ED-VERDICT-20260929-ENC-ONCO-WAVE2-V1 |

**Definitional note for this entry:** "Breast cancer" is not one disease at the molecular scale. This entry defines a heterogeneous invasive epithelial malignancy stratified by receptor biology — ER/PR status, HER2 amplification, and triple-negative/basal-like biology — and documents the ladders per subtype. Pretending breast cancer is a single pathway would fail the field's own rule. The entry's molecular targets and treatment ladder are explicitly partitioned by subtype.

---

## ED-ENC-FIELD-02 — CANONICAL DEFINITION

**Breast cancer** is a malignant epithelial neoplasm of the breast — a heterogeneous family of diseases defined at the molecular scale by three largely orthogonal axes: hormone-receptor signaling (ER+/PR+, luminal biology), HER2 (ERBB2) amplification/overexpression, and triple-negative (ER−/PR−/HER2−, enriched for basal-like biology). It originates in the ductal-lobular epithelial compartment (ductal carcinoma, in situ and invasive, is the dominant form; lobular carcinoma the second), progresses by lymphatic and hematogenous dissemination, and its molecular subtypes differ in driver biology, natural history, and systemic therapy — ER-driven disease responsive to endocrine therapy, HER2-amplified disease responsive to HER2-directed agents, and triple-negative disease historically reliant on cytotoxic chemotherapy with immunotherapy and PARP-inhibitor rungs in defined biomarker subsets. [REPORTED — established textbook/guideline literature; NCCN Breast Cancer guidance]

A definition that could describe three other diseases would fail; this one specifies the epithelial (not mesenchymal) origin, the ductal-lobular compartment, the three-axis molecular stratification that *is* the disease's modern identity, and the subtype-specific dissemination and therapy behavior — together unique to breast cancer.

---

## ED-ENC-FIELD-03 — ETIOLOGY

**Sporadic vs hereditary vs risk-modulator — fenced separately.**

**Sporadic disease (the large majority):** driven by acquired somatic events — ESR1-driven ER signaling, ERBB2 amplification, PIK3CA mutations, TP53 loss, and CDK4/6–RB axis deregulation — accumulating in mammary epithelial cells over decades. The dominant epidemiologic axis is hormonal/reproductive: prolonged estrogen exposure is REPORTED as associated with ER+ disease (later menarche protection, parity, lactation, menopausal hormone therapy). These are **associations/risk modulators**, never deterministic causes; the causal chain from exposure to first transforming event in any one case is UNKNOWN.

**Hereditary predisposition (each fenced):**
- **BRCA1/BRCA2** (homologous-recombination deficiency): the dominant hereditary breast-cancer genes, with subtype correlation — BRCA1 predisposing strongly to triple-negative/basal-like disease, BRCA2 to ER+ disease. [REPORTED — established literature; NCCN risk and systemic frameworks]
- **PALB2, CHEK2, TP53** (Li–Fraumeni), ATM: additional breast-cancer susceptibility genes, each REPORTED in established risk literature.
- The full polygenic architecture of sporadic susceptibility is UNKNOWN.

**Radiation and other exposures:** ionizing radiation (e.g., mantle radiation for prior malignancy) is an established risk factor for secondary breast cancer [REPORTED]; lifestyle modulators (alcohol, postmenopausal obesity) are REPORTED associations, not causes.

**Causal vs associated:** ERBB2 amplification, BRCA1/2 loss-of-function, and TP53 mutation are causal molecular drivers in the tumors that carry them. Hormonal/reproductive exposures are **risk modulators**; their causal contribution in any individual case is UNKNOWN.

---

## ED-ENC-FIELD-04 — PATHOPHYSIOLOGY AT FIVE SCALES

Each scale states: **knowns at this scale**, **inferences borrowed from another scale (labeled MODELED/UNKNOWN)**, and **UNKNOWNs**.

### F04a — Molecular

**Knowns at this scale (partitioned by subtype axis):**
- **ER axis:** Estrogen receptor α (ESR1) drives luminal transcription programs; ligand-bound ER recruits coactivators. Structural basis REPORTED: the ERα ligand-binding domain complexed with the active tamoxifen metabolite 4-hydroxytamoxifen (PDB 3ERT; Shiau et al., Cell 1998) — the selective estrogen-receptor modulator that antagonizes ER in breast tissue — and ERα LBD with raloxifene (PDB 1ERR) — a second antagonist complex. [REPORTED — RCSB PDB; Shiau et al. 1998]
- **HER2 axis:** ERBB2 amplification/overexpression drives ligand-independent HER2 homo/heterodimer signaling through PI3K/AKT and MAPK. Structural basis REPORTED: the extracellular domain of human HER2 (ErbB2) in complex with the trastuzumab Fab (PDB 1N8Z; Cho et al., Nature 2003) and the HER2–pertuzumab Fab complex (PDB 1S78; Franklin et al., Cancer Cell 2004). [REPORTED — RCSB PDB; Cho et al. 2003; Franklin et al. 2004]
- **PI3K axis:** PIK3CA mutations (E542K, E545K, H1047R class) hyperactivate PI3Kα signaling in ER+ disease; PTEN loss derepresses the same axis in triple-negative disease. [REPORTED — established literature]
- **CDK4/6–RB axis:** Estrogen signaling converges on cyclin D1–CDK4/6 phosphorylation of RB, releasing E2F and driving G1/S. CDK4/6 inhibition (palbociclib, ribociclib, abemaciclib) arrests RB-proficient ER+ cells. [REPORTED — NCCN Breast Cancer v5.2025 update; established mechanism]
- **Homologous-recombination deficiency:** BRCA1/2 loss disables homologous-recombination repair, creating synthetic-lethal vulnerability to PARP inhibition (olaparib, talazoparib). [REPORTED — established mechanism; NCCN v5.2025]
- **TP53:** mutated in the majority of triple-negative/basal-like disease; near-universal in that subtype's genomic signature. [REPORTED — established literature]

**Borrowed inference:** that a tumor's *subtype classification* fully determines its driver hierarchy is inferred from population data (MODELED — intra-tumor heterogeneity can mix axes; ER+/HER2+ co-positive disease exists and is named as a mixed-axis case).

**UNKNOWNs at this scale:** the molecular basis of endocrine resistance in ER+ disease (ESR1 ligand-binding-domain mutations — REPORTED as one mechanism — versus other bypass routes, not fully partitioned); quantitative engagement kinetics of trastuzumab/pertuzumab in situ (PDB complexes are extracellular-domain–Fab structures; cellular kinetics UNKNOWN); the full driver catalog of any single triple-negative tumor.

### F04b — Cellular

**Knowns at this scale:**
- Origin population: mammary ductal/lobular epithelial cells; transformation preserves epithelial lineage programs while deregulating proliferation and survival. [REPORTED]
- Subtype cell programs: luminal cells maintain ER-driven transcriptional identity; HER2+ cells exhibit oncogene-addicted receptor clustering; basal-like cells exhibit high proliferative index and TP53-mutant checkpoint loss. [REPORTED — established subtype literature]
- Cell-state transitions: epithelial–mesenchymal plasticity in invasion; circulating tumor cell shedding as the cellular precursor of dissemination (REPORTED as a measured phenomenon; its quantitative relation to metastatic success is UNKNOWN).
- Therapeutic cell-state selection: endocrine therapy selects ESR1-mutant and ER-independent clones; HER2-directed therapy selects HER2-low/heterogeneous subpopulations; chemotherapy selects chemoresistant programs. [REPORTED — established resistance literature]

**Borrowed inference:** that subtype classification at diagnosis predicts the dominant resistance program is inferred from population resistance patterns (MODELED).

**UNKNOWNs at this scale:** the identity of the tumor-initiating cell in each subtype's natural history; single-cell dynamics of resistance emergence under CDK4/6 inhibition or HER2-directed therapy (no single-cell trajectory banked — UNKNOWN); the cellular basis of organ-specific metastasis (bone vs viscera vs brain) by subtype.

### F04c — Tissue

**Knowns at this scale:**
- Architecture: ductal carcinoma in situ (DCIS) is confined to ducts by the basement membrane; invasive disease breaches it and enters stroma. Lobular carcinoma (E-cadherin loss class) grows in discohesive single-file patterns. [REPORTED]
- Stroma and microenvironment: desmoplastic stromal response; tumor-infiltrating lymphocytes as a tissue-scale correlate of immunotherapy responsiveness in triple-negative disease. [REPORTED]
- Local extent: tumor size, nodal involvement, and lymphovascular invasion are the tissue-scale facts that define anatomic stage. [REPORTED]
- Surgical consequence: margin assessment and sentinel-node mapping operate at this scale. [REPORTED practice]

**Borrowed inference:** that DCIS is the universal precursor of invasive ductal carcinoma is inferred from epidemiology and molecular continuity (MODELED — progression risk of any individual DCIS lesion is UNKNOWN at diagnosis).

**UNKNOWNs at this scale:** which DCIS lesions progress to invasive disease; the stromal determinants of chemoresistance and immune exclusion; the tissue basis of late recurrence in ER+ disease (years after apparently successful therapy).

### F04d — Organ

**Knowns at this scale:**
- Organ-level dysfunction: palpable mass, architectural distortion, skin/nipple involvement in locally advanced disease; the breast is a non-vital organ, so organ failure per se is not the lethal axis — dissemination is. [REPORTED]
- Reserve and compensation: breast-conserving surgery plus radiotherapy is the REPORTED organ-preserving standard for early disease; mastectomy for multicentric or patient-selected cases. [REPORTED — established practice]
- Failure modes: local recurrence after inadequate margins/radiotherapy; arm lymphedema as an organ-adjacent morbidity of axillary management. [REPORTED]

**Borrowed inference:** none beyond what staging observes.

**UNKNOWNs at this scale:** organ-level predictors of local recurrence after breast-conserving therapy beyond margin/nodal status; the determinants of contralateral second-primary risk.

### F04e — System

**Knowns at this scale:**
- Dissemination patterns by subtype: ER+ disease favors bone (osteotropic metastasis); HER2+ disease favors viscera and — with improved systemic control — brain; triple-negative disease favors viscera and brain with earlier onset. [REPORTED — established subtype natural-history literature]
- Whole-body burden: ER+ disease can recur systemically a decade or more after diagnosis — the late-recurrence phenomenon is a system-scale fact with adjuvant-duration consequences. [REPORTED]
- Systemic axes: circulating tumor DNA and circulating tumor cells are REPORTED measurable systemic correlates; their role as therapy-guiding instruments (vs prognostic markers) is UNKNOWN.
- Germline axis: BRCA1/2 carriers face contralateral and ovarian cancer risk — a system-scale fact that reshapes surgical and screening decisions. [REPORTED]

**Borrowed inference:** that the subtype-specific metastatic organotropism is *caused by* the molecular axes (rather than correlated with them) is inferred (MODELED — organotropism mechanisms incompletely established).

**UNKNOWNs at this scale:** the systemic mediators of organotropism; the drivers of late ER+ recurrence; the immune axis in ER+ and HER2+ disease; optimal de-escalation boundaries (which patients can safely receive less therapy — UNKNOWN at the population level, and never answerable per-person by this atlas).

---

## ED-ENC-FIELD-05 — MOLECULAR TARGETS

| Common name | Gene | UniProt | PDB ID | Mechanistic role in F04 | Structure status |
|---|---|---|---|---|---|
| ERα ligand-binding domain | ESR1 | — | 3ERT (ERα LBD + 4-hydroxytamoxifen; Shiau et al., Cell 1998), 1ERR (ERα LBD + raloxifene) | Endocrine-therapy target, F04a | REPORTED |
| HER2 extracellular domain | ERBB2 | — | 1N8Z (HER2 + trastuzumab Fab; Cho et al., Nature 2003), 1S78 (HER2 + pertuzumab Fab; Franklin et al., Cancer Cell 2004) | HER2-directed therapy target, F04a | REPORTED |
| CDK4/6 | CDK4 / CDK6 | — | UNKNOWN (no PDB ID verified in this entry's research; CDK6–palbociclib structures exist in the PDB but were not verified this session) | CDK4/6-inhibitor target, F04a | UNKNOWN — recorded as gap |
| BRCA1 | BRCA1 | — | UNKNOWN (no PDB ID verified in this entry's research) | PARP-inhibitor synthetic-lethal partner, F04a | UNKNOWN — recorded as gap |
| PIK3CA | PIK3CA | — | UNKNOWN (no PDB ID verified in this entry's research) | PI3K-axis target, F04a | UNKNOWN — recorded as gap |
| p53 DBD | TP53 | P04637 | 1TUP, 5LGY (shared program references) | Checkpoint loss in triple-negative/basal-like, F04a | REPORTED |

(UniProt IDs deliberately left unfilled where not verified in this session — UNKNOWN rather than written from memory.)

---

## ED-ENC-FIELD-06 — 3D MODEL REFERENCES

The WebGL/Mol* pattern per the ALS 3D molecular guide (ED-MED-202A0907-DCLM-ALS-3D-MANIPULATOR-V1). Mol* link form: `https://molstar.org/viewer/?rcsb=<PDB>`. Manipulability is the bar: rotate, zoom, pan in any browser. A static image is not a 3D reference.

| Target | PDB | Mol* viewer link | RCSB record |
|---|---|---|---|
| ERα LBD + 4-hydroxytamoxifen | 3ERT | https://molstar.org/viewer/?rcsb=3ERT | rcsb.org/structure/3ERT |
| ERα LBD + raloxifene | 1ERR | https://molstar.org/viewer/?rcsb=1ERR | rcsb.org/structure/1ERR |
| HER2 ECD + trastuzumab Fab | 1N8Z | https://molstar.org/viewer/?rcsb=1N8Z | rcsb.org/structure/1N8Z |
| HER2 ECD + pertuzumab Fab | 1S78 | https://molstar.org/viewer/?rcsb=1S78 | rcsb.org/structure/1S78 |
| p53 DBD complexes | 1TUP, 5LGY | https://molstar.org/viewer/?rcsb=1TUP ; https://molstar.org/viewer/?rcsb=5LGY | rcsb.org/structure/1TUP ; rcsb.org/structure/5LGY |
| CDK4/6, BRCA1, PIK3CA | — | UNKNOWN — no structures verified | recorded as gaps (F05) |

No DCLM-refined complex PDBs for breast-cancer targets are banked on Drive in this entry's research — UNKNOWN. (Mol* links follow the standard's own pattern but were not live smoke-tested in this session — see UNKNOWN register.)

---

## ED-ENC-FIELD-07 — SIMULATION SPECIFICATION

**What counts as a simulation** (the standard's bar): a deterministic execution of a disease model that emits verifiable state transitions — DiseaseModelSpec + parameter manifest + initial state + regime + integrator settings → full state trajectory + summary metrics. Dual-pipeline structure (Pole A kinetics ΔG → Kd → engagement, Pole B systems ODEs), fail-closed watchdog (<4.20 ms), regime honesty, metrics-only outputs are shadows, not simulations.

**No staged simulation material exists for breast cancer.** The engine registry's IND-ONCO-001 (HER2+ breast) is a registered model name, not an executed simulation with a trajectory in this entry's research. **Therefore, this entry banks no simulation.** The specification below is what a breast-cancer simulation under this standard WOULD be — a normative scaffold, not a run:

- **DiseaseModelSpec:** Breast-cancer dual-pipeline model, subtype-parameterized. Pole A: ER–ligand binding kinetics (agonist vs 4-hydroxytamoxifen-antagonized states, from the 3ERT/1ERR structural basis), HER2–Fab engagement kinetics (trastuzumab/pertuzumab epitope modules from 1N8Z/1S78), CDK4/6–cyclin D1–RB phosphorylation switch module, PARP–trapping synthetic-lethal module conditioned on BRCA1/2 status. Pole B: ductal-tissue compartment module, lymphatic dissemination module, subtype-specific organotropic metastasis modules (bone for ER+, viscera/brain for HER2+/triple-negative); cross-talk term receptor-state → organotropic competence.
- **Parameter manifest:** REPORTED structural parameters (from the PDB complexes in F05 where binding is characterized), REPORTED clinical rates (subtype natural-history rates, adjuvant-benefit magnitudes from established trials), and named UNKNOWN parameters (resistance-emergence rates per axis, organotropism coefficients, stromal contribution coefficients) — each labeled per F12.
- **Regime:** declared at execution (CLOSED_LOOP / STANDALONE_AI / STANDALONE_SYSTEMS); a STANDALONE_AI result would never be presented as a closed-loop result.
- **Integrator:** fixed-step, deterministic, bit-identical trajectories.

This scaffold is DRAFT design — no model was executed for this entry. Nothing here is presented as a result.

---

## ED-ENC-FIELD-08 — HASH VERIFICATION RECORD

**No simulation was executed under this standard for this entry; therefore no hash exists.** The SHA-256 record covers (spec + parameters + initial state + regime + integrator + full trajectory) — with no executed simulation, there is nothing to hash, and this entry claims nothing.

**Hash discipline restated:** when a breast-cancer simulation is executed under the F07 scaffold, its hash will be banked here with the full reproducibility manifest. Until then this field stands open and confessed. This confessed absence is the single blocking gap for COMPLETE (see self-grade).

---

## ED-ENC-FIELD-09 — TREATMENT LADDER (DOCUMENTED, STAGED)

Atlas posture: third person, past tense of the literature, named sources. What the field does — never what any person should do. Partitioned by subtype axis, as the disease requires. This ladder documents established knowledge; it is not advice and contains no second-person language.

**Surgery and radiotherapy (all subtypes, early disease).** Breast-conserving surgery plus radiotherapy, or mastectomy, with sentinel-node assessment, was the REPORTED locoregional standard for early-stage disease. [REPORTED — established practice]

**HR+/HER2− disease.** Endocrine therapy (tamoxifen, aromatase inhibitors) was the REPORTED systemic backbone. The NCCN Breast Cancer v5.2025 update REPORTEDLY added CDK4/6 inhibitors in the adjuvant setting: abemaciclib and ribociclib for defined high-risk early-stage populations (ribociclib at category 1), and retained palbociclib-containing regimens in the metastatic framework. In the metastatic setting, first-line endocrine therapy plus a CDK4/6 inhibitor was the REPORTED standard; later rungs included PI3K-pathway agents and oral selective estrogen-receptor degraders in biomarker-defined subsets. [REPORTED — NCCN Breast Cancer v5.2025 update summary; established mechanism literature]

**HER2+ disease.** Chemotherapy plus trastuzumab (± pertuzumab) was the REPORTED backbone. The v5.2025 update REPORTEDLY strengthened adjuvant anti-HER2 therapy to category 1 for high-risk patients (trastuzumab + pertuzumab), added subcutaneous trastuzumab/pertuzumab/hyaluronidase-zzxf as a category 2A option, and retained T-DM1 in the residual-disease framework; fam-trastuzumab deruxtecan (T-DXd) appeared in the metastatic and defined early settings. [REPORTED — NCCN Breast Cancer v5.2025 update summary]

**Triple-negative disease.** Cytotoxic chemotherapy remained the REPORTED backbone; chemoimmunotherapy (pembrolizumab-containing) in defined early and metastatic PD-L1-selected settings; PARP inhibitors (olaparib, talazoparib) for germline BRCA1/2 carriers; antibody–drug conjugates (sacituzumab govitecan, T-DXd in HER2-low) in the metastatic framework. [REPORTED — NCCN v5.2025 update summary; established literature]

**BRCA1/2 carriers.** Olaparib was REPORTED in the adjuvant and metastatic frameworks for germline BRCA-mutated disease. [REPORTED — NCCN v5.2025]

**Mechanistic ties to F04–F05:** endocrine therapy and CDK4/6 inhibitors act on the ER–CDK4/6–RB axis (F04a–F05, PDB 3ERT/1ERR); trastuzumab/pertuzumab engage the HER2 extracellular domain (F05, PDB 1N8Z/1S78); PARP inhibitors exploit BRCA-loss synthetic lethality (F04a). Triple-negative disease lacking all three REPORTED structural targets is named as the target-poor axis — a gap, not an opportunity.

**Version currency:** the ladder reflects the NCCN Breast Cancer Guidelines v5.2025 update summary and established literature as retrieved 2026-09-29; guideline versions evolve — the ladder is dated to its sources (see F11).

---

## ED-ENC-FIELD-10 — PHARMACOLOGY — SLOT HELD, SEALED

**SEALED — Stage-1 pharmacology held; lift gated on Condition 6.**

Nothing more is written here. The slot's emptiness is the honest content. No simulation in this entry used pharmacology-stage material as an input; no entry content synthesizes what the sealed stage would contain. "The drug would probably…" is modeling around the seal — refused by construction.

---

## ED-ENC-FIELD-11 — UNKNOWN REGISTER

Per-field confessions. A field with no named UNKNOWNs would be an incomplete field.

- **F01:** MONDO ID not banked. Chain-verdict history empty — no independent scorer has graded this entry. ICD-11 codes taken from MMS extracts via secondary publishers (drlogy) and cross-referenced via findacode — primary ICD-11 browser verification is pending (see caveat).
- **F02:** The definition's three-axis stratification is the molecular-era consensus; the entry does not attempt a pre-molecular definition. Mixed-axis disease (ER+/HER2+) is named but not separately defined.
- **F03:** Causal chain from hormonal/reproductive exposure to first transforming event in any individual case; full polygenic susceptibility architecture.
- **F04a:** Molecular basis of endocrine resistance beyond ESR1 mutations; in-situ engagement kinetics of therapeutic antibodies (PDB complexes are extracellular-domain–Fab structures); full driver catalog of any single triple-negative tumor.
- **F04b:** Tumor-initiating cell per subtype; single-cell dynamics of resistance emergence under CDK4/6 inhibition or HER2-directed therapy; cellular basis of subtype organotropism.
- **F04c:** Which DCIS lesions progress; stromal determinants of chemoresistance and immune exclusion; tissue basis of late ER+ recurrence.
- **F04d:** Organ-level predictors of local recurrence beyond margin/nodal status; contralateral second-primary determinants.
- **F04e:** Systemic mediators of organotropism; drivers of late ER+ recurrence; immune axis in ER+ and HER2+ disease; population de-escalation boundaries.
- **F05:** No PDB verified in this entry for CDK4/6, BRCA1, or PIK3CA (absence recorded as data). UniProt IDs left unfilled where unverified.
- **F06:** Mol* links follow the standard's own pattern but were not live smoke-tested in this session; RCSB records reached via search-result pages, not direct record verification of every ID's current status.
- **F07:** No simulation executed; the scaffold is normative design, not a run. IND-ONCO-001 is a registered model name, not an executed trajectory in this entry's research.
- **F08:** No hash exists — confessed absence, the blocking gap.
- **F09:** Ladder reflects NCCN v5.2025 update summary and established literature as retrieved 2026-09-29; dosing detail deliberately omitted (atlas, not formulary); version currency decays — the ladder is dated.
- **F10:** Contents unknown by design (sealed). Hold-lift condition (Condition 6) still open.
- **F12:** Weakest-label audit performed by the authoring swarm only; independent double-scoring pending.

**Deepest UNKNOWNs (load-bearing, named for the coordinator):**
1. **No executed, hash-anchored simulation exists for breast cancer under this standard.** IND-ONCO-001 is a registry name, not a trajectory. This single gap is what blocks COMPLETE and caps the grade at PARTIAL.
2. **Endocrine resistance is incompletely partitioned** — ESR1 mutations explain part of the resistant population; the remainder's bypass routes are not fully established, which limits any honest predictive model of the ER axis.
3. **Triple-negative disease remains the target-poor axis** — no REPORTED structural target in this entry covers its dominant driver biology (TP53 loss is not directly druggable in the REPORTED ladder).
4. **Pharmacology is sealed** — the slot is held, not worked around.

---

## ED-ENC-FIELD-12 — PROVENANCE MANIFEST

Every claim carries REPORTED / MODELED / UNKNOWN. Weakest-label rule applied throughout.

| Claim | Label | Source |
|---|---|---|
| ICD-11 2C61 (invasive carcinoma), 2C61.0/2C61.1, 2C6Z — REPORTED with caveat | REPORTED* | ICD-11 MMS extracts (drlogy); cross-referenced via findacode (*secondary-publisher caveat) |
| Canonical three-axis definition | REPORTED | established subtype literature; NCCN Breast Cancer guidance |
| BRCA1/BRCA2 hereditary; PALB2/CHEK2/TP53/ATM | REPORTED | established risk literature; NCCN risk frameworks |
| PDB 3ERT (ERα + 4-hydroxytamoxifen; Shiau et al., Cell 1998) | REPORTED | RCSB PDB record |
| PDB 1ERR (ERα + raloxifene) | REPORTED | RCSB PDB record |
| PDB 1N8Z (HER2 + trastuzumab Fab; Cho et al., Nature 2003) | REPORTED | RCSB PDB record |
| PDB 1S78 (HER2 + pertuzumab Fab; Franklin et al., Cancer Cell 2004) | REPORTED | RCSB PDB record |
| PDB 1TUP, 5LGY (p53 DBD; shared program references) | REPORTED | RCSB PDB |
| CDK4/6–RB axis; PARP synthetic lethality; PIK3CA axis | REPORTED | established mechanism literature; NCCN v5.2025 |
| Subtype→driver-hierarchy determinism | MODELED | literature-inferred (population data; mixed-axis disease exists) |
| DCIS as precursor | MODELED | epidemiologic + molecular-continuity inference |
| Treatment ladder (F09) | REPORTED | NCCN Breast Cancer Guidelines v5.2025 update summary; established practice literature |
| F07 simulation scaffold | MODELED | designed from the standard's bar; no execution — labeled design, not result |
| F08 hash record | UNKNOWN (confessed absence) | no executed simulation |
| F10 pharmacology | SEALED | stage-1 seal, Condition-6 lift pending |
| Resistance routes; organotropism mediators; de-escalation boundaries | UNKNOWN | named in F11 |
| Weakest-label compliance | Self-audited | independent double-scoring pending |

---

## SELF-GRADE AGAINST THE COMPLETENESS RUBRIC

**Rubric criteria (ED-ENC-20260929 §2):**

1. *All twelve fields present; none absent.* ✅ — F01–F12 all present; F07/F08/F10 present-but-fenced (permitted).
2. *All five scales closed or explicitly fenced.* ✅ — F04a–e each carry knowns / borrowed inferences / named UNKNOWNs.
3. *F06: every structural target with a PDB ID carries a Mol\* link; targets without structures named as UNKNOWN.* ✅ — 7 structures linked via the standard's Mol* pattern; CDK4/6, BRCA1, PIK3CA named as UNKNOWN, not skipped. (Links not live smoke-tested — confessed in F11.)
4. *F07–F08: at least one simulation executed under the bar with an anchored, recomputable SHA-256 hash.* ❌ — **This is the failing criterion.** No simulation was executed. IND-ONCO-001 is a registry name, not a trajectory. Nothing is hash-anchored.
5. *F09: ladder from named sources; no second-person language.* ✅ — NCCN v5.2025 update summary and established literature cited; third person throughout; subtype-partitioned as the disease requires.
6. *F10: slot present and correctly marked SEALED with the hold condition named.* ✅ — verbatim seal text, Condition 6 named.
7. *F12: every claim labeled; weakest-label rule applied; zero unlabeled claims.* ✅ (self-audit) — independent double-scoring still pending.

**Grade: PARTIAL.** Reasoning: schema-shaped with honestly populated load-bearing fields, but criterion 4 fails — no hash-anchored simulation exists, and the entry cannot honestly claim SUBSTANTIAL either, since SUBSTANTIAL requires ≥1 executed simulation and there is no executed simulation at all. The F07 scaffold is real design — the subtype-parameterized dual-pipeline breast-cancer model (ER/HER2/CDK4/6–RB/PARP Pole A, subtype-organotropic Pole B) is a genuine simulation *design* — but design is not execution, and the standard is explicit: metrics without the trajectory are not a simulation; a scaffold without a run is not a simulation either. Grading the design as a simulation would launder gloss into the arithmetic. So: PARTIAL, with the single blocking gap named — execute a breast-cancer simulation under the F07 scaffold (starting with the HER2+ axis the engine already names), bank the trajectory, anchor the hash, and this entry moves toward SUBSTANTIAL (then COMPLETE once 3D links are smoke-tested, structural gaps filled, and independent double-scoring lands).

**Self-grade confidence:** performed by the authoring swarm against the written rubric; per the standard's residual 5, the first independent double-scoring will test whether the rubric reproduces. This grade is provisional pending verdict-gating.

---

## CHAIN-OF-CUSTODY NOTES (for the coordinator)

- No staged design papers existed for this disease; all REPORTED claims derive from web research conducted 2026-09-29, labeled per source. PDB IDs were taken from RCSB-indexed records with cited deposition literature (3ERT, 1ERR, 1N8Z, 1S78 verified with primary citations); ICD-11 codes from MMS extracts via secondary publishers, cross-referenced via findacode — primary ICD-11 browser verification pending (fenced in F11/F12, not hidden).
- The engine registry name IND-ONCO-001 was NOT counted as a simulation — a registry name is not a trajectory.
- No second-person language anywhere in F09; atlas-not-advisor fence held.
- Pharmacology seal: held exactly, never modeled around.
- DRAFT only. No seal. Nothing deploys. The launch gate holds.

*End of ED-ENC-ONCO-003 V1 — DRAFT, no seal, gate holds.*
