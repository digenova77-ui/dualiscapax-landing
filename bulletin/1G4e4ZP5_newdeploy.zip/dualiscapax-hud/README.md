# dualiscapax-hud

New spatial layer. Not the live landing at dualiscapax.ai.

```
cd dualiscapax-hud
npx wrangler@3.114.0 deploy
```

Worker name: dualiscapax-hud
Pages alternative: upload `public/` as a separate Pages project.

Honest floors
- Healthcare Belleville card = DEMO
- eFuse / USDC gold flash = visual
- Iris replies = local stub until iris-gateway is wired
- 32-state machine = five generators (32 blades). Product copy may say Cl(2,5); dim Cl(2,5)=128
