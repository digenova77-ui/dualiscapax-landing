export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/api/v2/sleeve-ingest") {
      if (request.method !== "POST") {
        return json({ error: "METHOD_NOT_ALLOWED" }, 405);
      }
      try {
        const payload = await request.json();
        return json({
          status: "ACCEPTED",
          rail: "hud-demo",
          unity_id: payload.unity_id || "3F7A...9C2",
          mode: payload.mode || "unknown",
          det_m: null,
          note: "HUD worker stub. Not a settlement. Not a clinic.",
          pii_retained: "0.00%"
        });
      } catch {
        return json({ error: "INVALID_SLEEVE_PAYLOAD" }, 400);
      }
    }
    if (url.pathname === "/api/v1/sleeve-ingest") {
      return Response.redirect(new URL("/api/v2/sleeve-ingest", url.origin), 308);
    }
    if (url.pathname === "/api/v1/chat") {
      return Response.redirect(new URL("/api/v2/chat", url.origin), 308);
    }
    if (url.pathname === "/api/v2/chat") {
      if (request.method === "GET") return json({ agent: "Iris", status: "UP", layer: "hud-demo" });
      if (request.method !== "POST") return json({ error: "METHOD_NOT_ALLOWED" }, 405);
      return json({
        agent: "Iris",
        status: "SUCCESS",
        output: "I'm here. This desk is a model. Not a clinic. Not a wallet. Ask what the room is doing.",
        rail: "hud-stub"
      });
    }
    if (url.pathname === "/health" || url.pathname === "/api/v2/health") {
      return json({ ok: true, layer: "dualiscapax-hud", rte: "HUD" });
    }
    if (env && env.ASSETS) return env.ASSETS.fetch(request);
    return new Response("HUD worker has no ASSETS binding.", { status: 404 });
  }
};

function json(body, status) {
  return new Response(JSON.stringify(body), {
    status: status || 200,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
  });
}
