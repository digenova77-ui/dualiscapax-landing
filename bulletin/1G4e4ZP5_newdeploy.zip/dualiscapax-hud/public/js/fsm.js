/* DualisCapax HUD — 32-state FSM
 * Encoding: bit0=e1 observe, e2 place, e3 model, e4 proof, e5 settle
 * Transitions: flip exactly one bit.
 * SETTLE flash requires both pipes saw a valid event this session.
 */
(function (w) {
  const GENS = [
    { id: "e1", axis: "observe", pipe: "A" },
    { id: "e2", axis: "place", pipe: "A" },
    { id: "e3", axis: "model", pipe: "B" },
    { id: "e4", axis: "proof", pipe: "B" },
    { id: "e5", axis: "settle", pipe: "B" }
  ];
  const GRADE = {
    0: { name: "UNITY", layer: "idle" },
    1: { name: "OBSERVE", layer: "observation" },
    2: { name: "BIND", layer: "abstract" },
    3: { name: "ROOM", layer: "dclm" },
    4: { name: "PROOF", layer: "twain" },
    5: { name: "SETTLE", layer: "receipt" }
  };

  function grade(mask) {
    let n = 0, m = mask & 31;
    while (m) { n += m & 1; m >>= 1; }
    return n;
  }
  function blade(mask) {
    if (!mask) return "1";
    const bits = [];
    for (let i = 0; i < 5; i++) if (mask & (1 << i)) bits.push(String(i + 1));
    return bits.length === 1 ? "e" + bits[0] : "e" + bits.join("");
  }

  function create(initial) {
    let mask = (initial | 0) & 31;
    let pipeA = false, pipeB = false;
    const listeners = [];
    function emit() {
      const g = grade(mask);
      const st = {
        id: mask,
        bin: mask.toString(2).padStart(5, "0"),
        blade: blade(mask),
        grade: g,
        name: GRADE[g].name,
        layer: GRADE[g].layer,
        pipeA, pipeB,
        canSettle: pipeA && pipeB && g === 5
      };
      listeners.forEach((fn) => fn(st));
      return st;
    }
    return {
      get: emit,
      on(fn) { listeners.push(fn); emit(); },
      flip(i) {
        if (i < 0 || i > 4) return emit();
        mask ^= (1 << i);
        if (GENS[i].pipe === "A") pipeA = true;
        if (GENS[i].pipe === "B") pipeB = true;
        return emit();
      },
      setPipe(which, on) {
        if (which === "A") pipeA = !!on;
        if (which === "B") pipeB = !!on;
        return emit();
      },
      reset() { mask = 0; pipeA = false; pipeB = false; return emit(); },
      neighbors() {
        return [0,1,2,3,4].map((i) => ({ flip: GENS[i].id, to: mask ^ (1 << i), pipe: GENS[i].pipe }));
      },
      gens: GENS
    };
  }

  w.DCLM32 = { create, grade, blade, GENS, GRADE };
})(window);
