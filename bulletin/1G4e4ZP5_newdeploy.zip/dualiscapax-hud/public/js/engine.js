/* DualisCapax HUD engine — WebGL spatial layer. WebGPU optional later. */
(function () {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];

  const views = {
    home: { k: "01 / HOME — IRIS IN THE CENTER", h: "Meet <span>Iris</span>", p: "Your spatial companion. Observe. Explore. Build. A card is not a contract. This is not a clinic." },
    hall: { k: "02 / HALL — THE NEXUS", h: "Walk the <span>Hall</span>", p: "Rooms hang in one nave. Pick a desk. Looking is free." },
    spatial: { k: "03 / SPATIAL — INSIDE A ROOM", h: "Healthcare <span>sector</span>", p: "Demo stream only. Belleville card is a spatial model, not live hospital telemetry." },
    research: { k: "04 / RESEARCH — EVIDENCE", h: "Class, then <span>study</span>", p: "Observed, derived, modeled, proposed, validated stay distinct. Simulation is not treatment." },
    sectors: { k: "05 / SECTORS — APPLICATIONS", h: "Open a <span>sector</span>", p: "Healthcare, transit, factory. Same engine. Different pane color." },
    rte: { k: "06 / RTE — RUNTIME", h: "See the <span>engine</span>", p: "Observation → abstract → DCLM → Twain → execution → receipt." },
    engine: { k: "07 / ENGINE — DATA & TRUTH", h: "32-state <span>machine</span>", p: "Five generators. Hamming-1 flips. eFuse flash is visual. No live USDC." },
    manifold: { k: "08 / MANIFOLD — DUAL PIPE", h: "Pipe A × <span>Pipe B</span>", p: "Ingress vs constraint. Gold when both sit at 100 in this session — simulation." }
  };

  function toast(t) {
    const el = $("#toast");
    if (!el) return;
    el.textContent = t;
    el.classList.add("show");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.classList.remove("show"), 2200);
  }

  function setView(v) {
    const d = views[v] || views.home;
    document.body.className = "view-" + v;
    const k = $("#kicker"), h = $("#headline"), p = $("#subhead");
    if (k) k.textContent = d.k;
    if (h) h.innerHTML = d.h;
    if (p) p.textContent = d.p;
    $$(".nav button").forEach((b) => b.classList.toggle("active", b.dataset.view === v));
    $$(".node").forEach((n) => n.classList.toggle("selected", n.dataset.node === v));
    toast("VIEW · " + v.toUpperCase());
    location.hash = v;
  }

  window.HUD = { setView, toast, views };

  $$(".nav button").forEach((b) => b.onclick = () => setView(b.dataset.view));
  $$(".node").forEach((n) => n.onclick = () => setView(n.dataset.node));
  const enter = $("#enterBtn"); if (enter) enter.onclick = () => setView("spatial");
  const talk = $("#talkBtn");
  if (talk) talk.onclick = () => talkIris();

  $$(".tool").forEach((t) => t.onclick = () => {
    t.classList.toggle("on");
    const name = t.dataset.tool;
    if (name === "dclm") setView("engine");
    if (name === "spatial") setView("spatial");
    if (name === "unity") toast("UNITY ID · 3F7A…9C2");
    if (name === "mic") talkIris();
    if (name === "camera") toast("CAMERA · local only. Nothing leaves this device from the HUD stub.");
  });

  $$(".modes button").forEach((b) => b.onclick = () => {
    $$(".modes button").forEach((x) => x.classList.remove("on"));
    b.classList.add("on");
    toast("MODE · " + b.textContent.trim());
  });

  async function talkIris() {
    const irisState = $("#irisState");
    if (irisState) irisState.textContent = "THINKING";
    toast("IRIS · listening");
    const q = ($("#omnibox") && $("#omnibox").value) || "hello";
    try {
      const r = await fetch("/api/v2/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: q })
      });
      const j = await r.json();
      const bubble = $("#irisBubble");
      if (bubble) bubble.textContent = j.reply || j.note || "I'm here.";
      toast("IRIS · reply");
    } catch {
      const bubble = $("#irisBubble");
      if (bubble) bubble.textContent = "I'm here. This HUD stub cannot reach the live gateway yet. Ask for a room.";
      toast("IRIS · local stub");
    }
    if (irisState) irisState.textContent = "LISTENING";
  }

  const run = $("#runBtn");
  if (run) run.onclick = talkIris;
  const box = $("#omnibox");
  if (box) box.addEventListener("keydown", (e) => { if (e.key === "Enter") talkIris(); });

  // FSM panel
  const fsm = window.DCLM32 ? DCLM32.create(0) : null;
  const grid = $("#fsmGrid");
  if (fsm && grid) {
    for (let i = 0; i < 32; i++) {
      const c = document.createElement("button");
      c.className = "cell";
      c.dataset.id = String(i);
      c.innerHTML = "<b>" + i.toString(2).padStart(5, "0") + "</b><span>" + (DCLM32.blade(i)) + "</span>";
      c.onclick = () => {
        const cur = fsm.get().id;
        const dist = (cur ^ i).toString(2).replace(/0/g, "").length;
        if (dist === 1) {
          const bit = Math.log2(cur ^ i);
          fsm.flip(bit);
        } else if (i === 0) {
          fsm.reset();
        } else {
          toast("ILLEGAL · Hamming-1 only");
        }
      };
      grid.appendChild(c);
    }
    fsm.on((st) => {
      $$("#fsmGrid .cell").forEach((c) => {
        const id = +c.dataset.id;
        c.classList.toggle("on", id === st.id);
        c.classList.toggle("settle", st.canSettle && id === 31);
      });
      const name = $("#fsmName"); if (name) name.textContent = st.name + "  ·  " + st.blade + "  ·  g" + st.grade;
      const a = $("#pipeAVal"); if (a) a.textContent = st.pipeA ? "INGRESS SEEN" : "WAIT";
      const b = $("#pipeBVal"); if (b) b.textContent = st.pipeB ? "CONSTRAINT SEEN" : "WAIT";
      const fuse = $("#efuse");
      if (fuse) {
        fuse.classList.toggle("flash", !!st.canSettle);
        fuse.textContent = st.canSettle ? "eFUSE · VISUAL SETTLED (SIM)" : "eFUSE · HOLD";
      }
      const det = $("#detM"); if (det) det.textContent = "1.000000";
    });
  }

  $$("[data-flip]").forEach((b) => b.onclick = () => fsm && fsm.flip(+b.dataset.flip));

  const pa = $("#pipeA");
  const pb = $("#pipeB");
  function syncPipes() {
    if (!fsm) return;
    const av = pa ? +pa.value : 0;
    const bv = pb ? +pb.value : 0;
    fsm.setPipe("A", av >= 100);
    fsm.setPipe("B", bv >= 100);
    const al = $("#pipeARead"); if (al) al.textContent = String(av);
    const bl = $("#pipeBRead"); if (bl) bl.textContent = String(bv);
    if (av >= 100 && bv >= 100) {
      // walk to grade 5 if needed for the flash demo
      let st = fsm.get();
      if (st.id !== 31) {
        fsm.reset();
        [0,1,2,3,4].forEach((i) => fsm.flip(i));
      }
    }
  }
  if (pa) pa.oninput = syncPipes;
  if (pb) pb.oninput = syncPipes;

  // Three.js orb
  if (!window.THREE) return bootHash();
  const host = $("#world");
  if (!host) return bootHash();
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(54, innerWidth / innerHeight, 0.1, 100);
  camera.position.set(0, 0.25, 8.6);
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
  renderer.setSize(innerWidth, innerHeight);
  host.appendChild(renderer.domElement);
  scene.add(new THREE.AmbientLight(0x9edfff, 1.1));
  const key = new THREE.PointLight(0x38e8ff, 5, 25); key.position.set(0, 2.5, 5); scene.add(key);
  const fill = new THREE.PointLight(0xa66cff, 3, 18); fill.position.set(-4, -1, 1); scene.add(fill);

  const iris = new THREE.Group(); scene.add(iris);
  const core = new THREE.Mesh(
    new THREE.SphereGeometry(1.05, 48, 48),
    new THREE.MeshPhysicalMaterial({ color: 0x38e8ff, emissive: 0x062b45, emissiveIntensity: 1.6, roughness: 0.08, metalness: 0.08, transparent: true, opacity: 0.78, transmission: 0.5, thickness: 1.2 })
  );
  iris.add(core);
  const shell = new THREE.Mesh(
    new THREE.SphereGeometry(1.34, 36, 36),
    new THREE.MeshBasicMaterial({ color: 0x6beaff, wireframe: true, transparent: true, opacity: 0.13 })
  );
  iris.add(shell);
  [[1.45, 0, 0.28, 0.68, 0xa66cff], [1.35, 2.1, -0.2, 0.82, 0x38e8ff]].forEach((d, i) => {
    const g = new THREE.Group();
    const m = new THREE.Mesh(
      new THREE.SphereGeometry(d[3], 28, 28),
      new THREE.MeshPhysicalMaterial({ color: d[4], emissive: d[4], emissiveIntensity: 1.2, roughness: 0.12, transparent: true, opacity: 0.55 })
    );
    g.add(m);
    g.userData = { r: d[0], a: d[1], y: d[2], speed: 0.25 + i * 0.06 };
    iris.add(g);
  });
  const ring = new THREE.Mesh(new THREE.TorusGeometry(2.05, 0.025, 8, 140), new THREE.MeshBasicMaterial({ color: 0x38e8ff, transparent: true, opacity: 0.5 }));
  ring.rotation.x = Math.PI / 2; iris.add(ring);

  const count = 700, pos = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const a = Math.random() * Math.PI * 2, r = 4 + Math.random() * 8, y = (Math.random() - 0.5) * 6;
    pos[i * 3] = Math.cos(a) * r; pos[i * 3 + 1] = y; pos[i * 3 + 2] = Math.sin(a) * r - 2;
  }
  const pg = new THREE.BufferGeometry(); pg.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  scene.add(new THREE.Points(pg, new THREE.PointsMaterial({ color: 0x48cfff, size: 0.018, transparent: true, opacity: 0.5 })));

  let t = 0, targetY = 0, targetX = 0;
  addEventListener("pointermove", (e) => {
    targetY = (e.clientX / innerWidth - 0.5) * 0.5;
    targetX = (e.clientY / innerHeight - 0.5) * 0.2;
  }, { passive: true });
  addEventListener("resize", () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });
  function animate() {
    requestAnimationFrame(animate);
    t += 0.008;
    core.scale.setScalar(1 + Math.sin(t * 1.7) * 0.035);
    shell.rotation.y += 0.002;
    iris.children.forEach((g) => {
      if (!g.userData.r) return;
      g.userData.a += 0.003 * g.userData.speed;
      g.position.set(Math.cos(g.userData.a) * g.userData.r, g.userData.y + Math.sin(t) * 0.1, Math.sin(g.userData.a) * g.userData.r);
    });
    ring.rotation.z += 0.0015;
    iris.rotation.y += (targetY - iris.rotation.y) * 0.03;
    iris.rotation.x += (targetX - iris.rotation.x) * 0.03;
    const z = ({ home: 8.6, hall: 9.2, spatial: 7.8, engine: 7.2, rte: 7.2, manifold: 9.4 }[document.body.className.replace("view-", "")] || 8.6);
    camera.position.z += (z - camera.position.z) * 0.05;
    renderer.render(scene, camera);
  }
  animate();

  function bootHash() {
    const v = (location.hash || "#home").replace("#", "");
    if (views[v]) setView(v);
  }
  bootHash();
  addEventListener("hashchange", bootHash);
})();
