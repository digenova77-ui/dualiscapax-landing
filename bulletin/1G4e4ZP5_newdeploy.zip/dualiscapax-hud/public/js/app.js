/* DualisCapax HUD app — rooms + Iris house replies. No invented hospital telemetry. */
(function () {
  const $ = (s) => document.querySelector(s);
  const views = ["home","hall","spatial","research","sectors","rte","engine","manifold"];
  const fsm = DCLM32.create(0);
  let pipeA = 34, pipeB = 0;

  const HOUSE = [
    { re: /who|iris|you/i, a: "I'm Iris. This hall is DualisCapax. Look is free. I don't diagnose and I don't sell a coin." },
    { re: /unity/i, a: "Unity ID is the person in the seat. Yours is 3F7A…9C2 on this demo HUD." },
    { re: /look|hall/i, a: "The hall is the center. Rooms branch from here: Healthcare, Research, RTE, Engine." },
    { re: /hockey|rink|ice/i, a: "Hockey is a desk on the other site. This layer is the spatial HUD. Different box." },
    { re: /hospital|belleville|quinte|icu/i, a: "Healthcare is a sector room. The Belleville card is a DEMO overlay, not a live feed from Quinte Health." },
    { re: /usdc|settle|efuse|coin/i, a: "The gold flash is a visual eFuse. No wallet is connected. No USDC moved." },
    { re: /32|clifford|dclm|fsm/i, a: "Thirty-two states, five generators. Flip one bit at a time. Settle needs both pipes in this session." },
    { re: /help|what can/i, a: "Talk, open a room, drag the pipes on Manifold. Ask what a word means." }
  ];

  function toast(msg) {
    const t = $("#toast");
    t.textContent = msg;
    t.classList.add("show");
    setTimeout(() => t.classList.remove("show"), 2200);
  }

  function show(name) {
    views.forEach((v) => {
      const el = document.getElementById("view-" + v);
      if (el) el.hidden = v !== name;
    });
    document.querySelectorAll(".nav button").forEach((b) => b.classList.toggle("active", b.dataset.view === name));
    if (window.HudEngine) HudEngine.setMode(name === "spatial" ? "spatial" : name === "engine" || name === "manifold" ? name : "home");
    location.hash = name;
  }

  function renderState(st) {
    const el = document.getElementById("fsm-readout");
    if (el) el.innerHTML = "<b>" + st.bin + "</b>  " + st.blade + "  ·  " + st.name + "  ·  grade " + st.grade;
    const live = document.getElementById("live-layer");
    if (live) live.textContent = st.layer;
    document.getElementById("mask-id").textContent = String(st.id);
    document.getElementById("can-settle").textContent = st.canSettle ? "ARMED (visual)" : "waiting";
    if (st.canSettle) {
      document.getElementById("manifold-state").textContent = "USDC SETTLED (visual)";
      if (window.HudEngine) HudEngine.flash();
      document.getElementById("flash").classList.add("on");
      setTimeout(() => document.getElementById("flash").classList.remove("on"), 400);
    } else {
      document.getElementById("manifold-state").textContent = "Fluid";
    }
  }

  function setPipe(which, val) {
    val = Math.max(0, Math.min(100, val|0));
    if (which === "A") pipeA = val;
    else pipeB = val;
    fsm.setPipe(which, val > 50);
    if (window.HudEngine) HudEngine.setPipes(pipeA, pipeB);
    const a = document.getElementById("pipeA");
    const b = document.getElementById("pipeB");
    if (a) a.value = pipeA;
    if (b) b.value = pipeB;
    document.getElementById("pipeA-n").textContent = pipeA;
    document.getElementById("pipeB-n").textContent = pipeB;
    if (pipeA === 100 && pipeB === 100) {
      // climb to grade 5 by flipping unset bits
      const st = fsm.get();
      for (let i = 0; i < 5; i++) if (((st.id >> i) & 1) === 0) fsm.flip(i);
    }
  }

  function ask(text) {
    text = String(text || "").trim();
    if (!text) return;
    let ans = "I don't have that on this HUD. Ask about Iris, Unity ID, rooms, or the 32-state map.";
    for (const h of HOUSE) if (h.re.test(text)) { ans = h.a; break; }
    document.getElementById("iris-bubble").textContent = ans;
    fetch("/api/v2/sleeve-ingest", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ unity_id: "3F7A...9C2", mode: "ask", text: text.slice(0, 240) })
    }).catch(() => {});
    fsm.flip(0);
  }

  function wire() {
    document.querySelectorAll(".nav button").forEach((b) => b.addEventListener("click", () => show(b.dataset.view)));
    document.querySelectorAll("[data-goto]").forEach((b) => b.addEventListener("click", () => show(b.dataset.goto)));
    document.getElementById("talk-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const inp = document.getElementById("omni");
      ask(inp.value);
      inp.value = "";
    });
    document.getElementById("talk-iris").addEventListener("click", () => {
      ask("who are you");
      document.getElementById("omni").focus();
    });
    document.querySelectorAll(".gen").forEach((b) => b.addEventListener("click", () => fsm.flip(+b.dataset.bit)));
    document.getElementById("pipeA").addEventListener("input", (e) => setPipe("A", e.target.value));
    document.getElementById("pipeB").addEventListener("input", (e) => setPipe("B", e.target.value));
    document.getElementById("reset-fsm").addEventListener("click", () => { fsm.reset(); setPipe("A", 34); setPipe("B", 0); });
    document.querySelectorAll(".modes button").forEach((b) => b.addEventListener("click", () => {
      document.querySelectorAll(".modes button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
      toast("Viewport: " + b.textContent + " (visual)");
    }));
    document.getElementById("run-analysis").addEventListener("click", () => {
      toast("Analysis is DEMO. No hospital feed is attached.");
      fsm.flip(2);
    });
    fsm.on(renderState);
    setPipe("A", 34); setPipe("B", 0);
    const hash = (location.hash || "#home").slice(1);
    show(views.includes(hash) ? hash : "home");
    fetch("/api/v2/sleeve-ingest", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ unity_id: "3F7A...9C2", mode: "boot" })
    }).catch(() => {});
  }

  w.HudApp = { show, ask, fsm };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", wire);
  else wire();
})();
